# Pertinho (Android nativo)

App nativo em Kotlin + Jetpack Compose: feed vertical de vídeos de comércios perto de você, explorar com busca/raio/categoria, perfil da loja, comentários, salvar/seguir e postar comércio. Sem WebView, sem PWA, sem APIs pagas, sem chaves secretas e sem permissão de internet.

## Compilar
O GitHub Actions faz tudo (`.github/workflows/build-apk.yml`): roda os testes e gera `app/build/outputs/apk/debug/app-debug.apk`, publicado como artefato `app-debug-apk`.
Localmente (JDK 17, Android SDK 34 e Gradle 8.7): `gradle :app:testDebugUnitTest :app:assembleDebug`.

## Estrutura
- `app/src/main/java/br/com/pertinho/` — `MainActivity`, `PertinhoViewModel`, `data/` (modelos e comércios de exemplo), `logic/` (distância, filtro, formatação), `ui/` (telas Compose)
- `app/src/main/res/raw` — vídeos (.mp4) e músicas (.mp3); `res/drawable-nodpi` — fotos
- `app/src/test/` — testes unitários da lógica

## Limitações desta versão
Posição fixa de demonstração (Centro do Rio de Janeiro); sem mapa, sem login e sem buscar comércios reais por API; curtidas, comentários e posts ficam só no aparelho.
