package br.com.pertinho

import br.com.pertinho.data.SampleData
import br.com.pertinho.logic.Geo
import br.com.pertinho.logic.StoreFilter
import br.com.pertinho.logic.formatDistance
import br.com.pertinho.logic.formatPrice
import br.com.pertinho.logic.parseMenu
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {

    private val origin = SampleData.origin

    @Test
    fun distanceToSamePointIsZero() {
        assertEquals(0.0, Geo.distanceKm(-22.9, -43.1, -22.9, -43.1), 1e-9)
    }

    @Test
    fun distanceRioToSaoPauloIsAbout360Km() {
        val d = Geo.distanceKm(-22.9068, -43.1729, -23.5505, -46.6333)
        assertEquals(360.7, d, 2.0)
    }

    @Test
    fun radiusFiltersFarStoreAndKeepsNearOnes() {
        val within5 = StoreFilter.filter(SampleData.stores, origin, null, 5.0, "")
        assertFalse(within5.any { it.store.id == "d7" })
        assertEquals(18, within5.size)

        val within25 = StoreFilter.filter(SampleData.stores, origin, null, 25.0, "")
        assertTrue(within25.any { it.store.id == "d7" })
        assertEquals(19, within25.size)
    }

    @Test
    fun noRadiusMeansNoLimit() {
        val all = StoreFilter.filter(SampleData.stores, origin, null, null, "")
        assertEquals(SampleData.stores.size, all.size)
    }

    @Test
    fun resultsAreSortedByDistance() {
        val result = StoreFilter.filter(SampleData.stores, origin, null, null, "")
        val kms = result.map { it.km }
        assertEquals(kms.sorted(), kms)
        assertEquals("d7", result.last().store.id)
    }

    @Test
    fun categoryFilterKeepsOnlyThatCategory() {
        val pizzas = StoreFilter.filter(SampleData.stores, origin, "Pizza", null, "")
        assertEquals(2, pizzas.size)
        assertTrue(pizzas.all { it.store.category == "Pizza" })
    }

    @Test
    fun searchIgnoresAccentsAndCase() {
        val cafe = StoreFilter.filter(SampleData.stores, origin, null, null, "CAFE")
        assertTrue(cafe.any { it.store.id == "d5" })
        val burger = StoreFilter.filter(SampleData.stores, origin, null, null, "hamburguer")
        assertTrue(burger.any { it.store.id == "d4" })
    }

    @Test
    fun searchFindsMenuItems() {
        val result = StoreFilter.filter(SampleData.stores, origin, null, null, "temaki")
        assertEquals(listOf("d2"), result.map { it.store.id })
    }

    @Test
    fun blankSearchMatchesEverything() {
        assertTrue(StoreFilter.matches(SampleData.stores.first(), "   "))
    }

    @Test
    fun formatPriceHandlesNullFreeAndValues() {
        assertEquals("Sob consulta", formatPrice(null))
        assertEquals("Grátis", formatPrice(0.0))
        assertEquals("R\$ 49,90", formatPrice(49.9))
    }

    @Test
    fun formatDistanceUsesMetersBelowOneKm() {
        assertEquals("450 m", formatDistance(0.45))
        assertEquals("2,5 km", formatDistance(2.5))
    }

    @Test
    fun parseMenuReadsNamesAndPrices() {
        val items = parseMenu("Pizza grande - 54,90\n\nSuco 10 - 8,5\nCombo 2")
        assertEquals(3, items.size)
        assertEquals("Pizza grande", items[0].name)
        assertEquals(54.9, items[0].price!!, 1e-9)
        assertEquals("Suco 10", items[1].name)
        assertEquals(8.5, items[1].price!!, 1e-9)
        assertEquals("Combo 2", items[2].name)
        assertNull(items[2].price)
    }

    @Test
    fun sampleDataIsConsistent() {
        val ids = SampleData.stores.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        val names = SampleData.categories.map { it.name }.toSet()
        assertTrue(SampleData.stores.all { it.category in names })
        assertTrue(SampleData.stores.all { it.videoIndex == 1 || it.videoIndex == 2 })
    }

    @Test
    fun mediaKeysFallBackToOutros() {
        assertEquals("pizza", SampleData.mediaKeyFor("Pizza"))
        assertEquals("cafe", SampleData.mediaKeyFor("Café"))
        assertEquals("outros", SampleData.mediaKeyFor("Barbearia"))
        assertEquals("outros", SampleData.mediaKeyFor("Categoria inexistente"))
    }
}
