package br.com.pertinho.ui

import android.content.Context
import android.media.MediaPlayer
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.pertinho.FeedTab
import br.com.pertinho.PertinhoViewModel
import br.com.pertinho.R
import br.com.pertinho.RADII
import br.com.pertinho.data.SampleData
import br.com.pertinho.data.StoreDistance
import br.com.pertinho.logic.formatDistance

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeedScreen(vm: PertinhoViewModel) {
    val posts = vm.feedPosts()
    val pagerState = rememberPagerState(pageCount = { posts.size })
    val feedVisible = vm.openStoreId == null

    // Ao trocar de aba ou filtro, volta para o primeiro vídeo.
    LaunchedEffect(vm.category, vm.feedTab, vm.radiusKm) {
        if (pagerState.pageCount > 0) pagerState.scrollToPage(0)
    }

    val current = posts.getOrNull(pagerState.currentPage)
    MusicEffect(
        enabled = vm.soundOn && feedVisible && current != null,
        resId = if (current != null) Media.music(current.store.category) else 0
    )

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (posts.isEmpty()) {
            EmptyFeed(vm.feedTab)
        } else {
            VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                val post = posts.getOrNull(page)
                if (post != null) {
                    PostPage(vm, post, feedVisible && pagerState.currentPage == page)
                }
            }
        }
        FeedTopBar(vm, Modifier.align(Alignment.TopCenter))
    }
}

@Composable
private fun EmptyFeed(tab: FeedTab) {
    val text = when (tab) {
        FeedTab.FOLLOWING -> "Você ainda não segue nenhum comércio.\nAbra um perfil e toque em Seguir."
        else -> "Nenhum comércio encontrado neste filtro.\nAumente o raio ou escolha outra categoria."
    }
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Brand.Muted, fontSize = 16.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun FeedTopBar(vm: PertinhoViewModel, modifier: Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
            .padding(top = 4.dp, bottom = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FeedTab.values().forEach { tab ->
                TabLabel(tab.label, vm.feedTab == tab) { vm.feedTab = tab }
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                PillChip(
                    label = "Raio " + vm.radiusKm.toInt() + " km",
                    selected = false,
                    onClick = {
                        val next = RADII[(RADII.indexOf(vm.radiusKm) + 1) % RADII.size]
                        vm.radiusKm = next
                    },
                    container = Color(0x99000000)
                )
            }
            item {
                PillChip(
                    label = if (vm.soundOn) "Música: ligada" else "Música: off",
                    selected = vm.soundOn,
                    onClick = { vm.soundOn = !vm.soundOn },
                    container = Color(0x99000000)
                )
            }
            item {
                PillChip("Todos", vm.category == null, { vm.category = null }, Color(0x99000000))
            }
            items(SampleData.categories) { c ->
                PillChip(c.name, vm.category == c.name, { vm.category = c.name }, Color(0x99000000))
            }
        }
    }
}

@Composable
private fun TabLabel(label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .defaultMinSize(minHeight = 44.dp)
            .padding(horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xB3FFFFFF),
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
        Box(
            Modifier
                .padding(top = 4.dp)
                .width(24.dp)
                .height(3.dp)
                .background(if (selected) Color.White else Color.Transparent, RoundedCornerShape(2.dp))
        )
    }
}

@Composable
private fun PostPage(vm: PertinhoViewModel, post: StoreDistance, active: Boolean) {
    val context: Context = LocalContext.current
    val s = post.store
    val isLiked = s.id in vm.liked
    val isSaved = s.id in vm.saved

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        LoopingVideo(
            resId = Media.video(s.category, s.videoIndex),
            playing = active,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(300.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, end = 88.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = s.name,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .clickable { vm.openStoreId = s.id }
                    .defaultMinSize(minHeight = 44.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Brand.Gradient)
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                    Text(s.category, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text(formatDistance(post.km), color = Color.White, fontSize = 13.sp)
            }
            Text(
                text = s.description,
                color = Color.White,
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 8.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionButton(label = vm.likeCount(s.id).toString(), onClick = { vm.toggleLike(s.id) }) {
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = "Curtir",
                    tint = if (isLiked) Brand.Pink else Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            ActionButton(label = vm.commentCount(s.id).toString(), onClick = { vm.commentsFor = s.id }) {
                Icon(
                    painter = painterResource(R.drawable.ic_comment),
                    contentDescription = "Comentar",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
            ActionButton(label = if (isSaved) "Salvo" else "Salvar", onClick = { vm.toggleSave(s.id) }) {
                Icon(
                    painter = painterResource(R.drawable.ic_bookmark),
                    contentDescription = "Salvar",
                    tint = if (isSaved) Brand.Star else Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
            ActionButton(label = "Enviar", onClick = { shareStore(context, s) }) {
                Icon(
                    imageVector = Icons.Filled.Share,
                    contentDescription = "Compartilhar",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .defaultMinSize(minWidth = 52.dp, minHeight = 52.dp)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

/** Toca a música da categoria enquanto [enabled]; solta o player ao desligar ou sair da tela. */
@Composable
private fun MusicEffect(enabled: Boolean, resId: Int) {
    val context = LocalContext.current
    DisposableEffect(enabled, resId) {
        var player: MediaPlayer? = null
        if (enabled && resId != 0) {
            player = MediaPlayer.create(context, resId)
            player?.isLooping = true
            player?.setVolume(0.6f, 0.6f)
            player?.start()
        }
        onDispose {
            player?.release()
        }
    }
}
