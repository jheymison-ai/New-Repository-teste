package br.com.pertinho.ui

import br.com.pertinho.R
import br.com.pertinho.data.SampleData

/** Liga a categoria de um comércio aos arquivos de vídeo, foto e música incluídos em res/. */
object Media {
    private val VIDEOS: Map<String, Int> = mapOf(
        "brasileira_1" to R.raw.brasileira_1,
        "brasileira_2" to R.raw.brasileira_2,
        "cafe_1" to R.raw.cafe_1,
        "cafe_2" to R.raw.cafe_2,
        "doces_1" to R.raw.doces_1,
        "doces_2" to R.raw.doces_2,
        "hamburguer_1" to R.raw.hamburguer_1,
        "hamburguer_2" to R.raw.hamburguer_2,
        "japonesa_1" to R.raw.japonesa_1,
        "japonesa_2" to R.raw.japonesa_2,
        "outros_1" to R.raw.outros_1,
        "outros_2" to R.raw.outros_2,
        "pizza_1" to R.raw.pizza_1,
        "pizza_2" to R.raw.pizza_2
    )

    private val IMAGES: Map<String, Int> = mapOf(
        "brasileira_1" to R.drawable.brasileira_1,
        "brasileira_2" to R.drawable.brasileira_2,
        "cafe_1" to R.drawable.cafe_1,
        "cafe_2" to R.drawable.cafe_2,
        "doces_1" to R.drawable.doces_1,
        "doces_2" to R.drawable.doces_2,
        "hamburguer_1" to R.drawable.hamburguer_1,
        "hamburguer_2" to R.drawable.hamburguer_2,
        "japonesa_1" to R.drawable.japonesa_1,
        "japonesa_2" to R.drawable.japonesa_2,
        "outros_1" to R.drawable.outros_1,
        "outros_2" to R.drawable.outros_2,
        "pizza_1" to R.drawable.pizza_1,
        "pizza_2" to R.drawable.pizza_2
    )

    private val MUSIC: Map<String, Int> = mapOf(
        "brasileira" to R.raw.brasileira,
        "cafe" to R.raw.cafe,
        "doces" to R.raw.doces,
        "hamburguer" to R.raw.hamburguer,
        "japonesa" to R.raw.japonesa,
        "outros" to R.raw.outros,
        "pizza" to R.raw.pizza
    )

    private fun clampIndex(index: Int): Int = if (index == 2) 2 else 1

    fun video(category: String, index: Int): Int =
        VIDEOS[SampleData.mediaKeyFor(category) + "_" + clampIndex(index)] ?: R.raw.outros_1

    fun image(category: String, index: Int): Int =
        IMAGES[SampleData.mediaKeyFor(category) + "_" + clampIndex(index)] ?: R.drawable.outros_1

    fun music(category: String): Int =
        MUSIC[SampleData.mediaKeyFor(category)] ?: R.raw.outros
}
