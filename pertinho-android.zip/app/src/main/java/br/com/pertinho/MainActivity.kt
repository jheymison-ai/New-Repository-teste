package br.com.pertinho

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import br.com.pertinho.ui.PertinhoApp
import br.com.pertinho.ui.theme.PertinhoTheme

class MainActivity : ComponentActivity() {

    private val vm: PertinhoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.attach(getSharedPreferences("pertinho", MODE_PRIVATE))
        setContent {
            PertinhoTheme {
                PertinhoApp(vm)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Não deixa a música tocando com o app em segundo plano.
        vm.soundOn = false
    }
}
