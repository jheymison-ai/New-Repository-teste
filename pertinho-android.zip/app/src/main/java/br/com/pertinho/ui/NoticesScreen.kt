package br.com.pertinho.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.pertinho.PertinhoViewModel
import br.com.pertinho.logic.StoreFilter

/** Avisos de demonstração: novidades dos comércios mais próximos (os que você segue vêm primeiro). */
@Composable
fun NoticesScreen(vm: PertinhoViewModel) {
    val near = StoreFilter.filter(vm.allStores, vm.origin, null, 5.0, "")
    val items = near.sortedByDescending { it.store.id in vm.following }.take(8)

    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Avisos",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        if (items.isEmpty()) {
            Text("Sem avisos por enquanto.", color = Brand.Muted, modifier = Modifier.padding(horizontal = 16.dp))
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items) { item ->
                    StoreRow(item) { vm.openStoreId = item.store.id }
                }
            }
        }
    }
}
