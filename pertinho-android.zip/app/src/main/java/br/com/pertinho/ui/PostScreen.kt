package br.com.pertinho.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.pertinho.AppTab
import br.com.pertinho.PertinhoViewModel
import br.com.pertinho.data.SampleData

@Composable
fun PostScreen(vm: PertinhoViewModel) {
    val context = LocalContext.current
    var nome by rememberSaveable { mutableStateOf("") }
    var categoria by rememberSaveable { mutableStateOf("Pizza") }
    var legenda by rememberSaveable { mutableStateOf("") }
    var whatsapp by rememberSaveable { mutableStateOf("") }
    var instagram by rememberSaveable { mutableStateOf("") }
    var endereco by rememberSaveable { mutableStateOf("") }
    var cardapio by rememberSaveable { mutableStateOf("") }
    var distancia by rememberSaveable { mutableStateOf("1") }
    var erro by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Postar meu comércio", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "O vídeo de exemplo da categoria escolhida é usado na publicação.",
            color = Brand.Muted,
            fontSize = 13.sp
        )
        Image(
            painter = painterResource(Media.image(categoria, 1)),
            contentDescription = "Prévia da categoria " + categoria,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(16.dp))
        )
        Text("Categoria", color = Brand.Muted, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(0.dp)) {
            items(SampleData.categories) { c ->
                PillChip(c.name, categoria == c.name, { categoria = c.name })
            }
        }
        OutlinedTextField(
            value = nome,
            onValueChange = { nome = it },
            label = { Text("Nome do comércio") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = legenda,
            onValueChange = { legenda = it.take(120) },
            label = { Text("Legenda do vídeo") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = instagram,
            onValueChange = { instagram = it.take(60) },
            label = { Text("Instagram (@usuário)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = whatsapp,
            onValueChange = { whatsapp = it.take(20) },
            label = { Text("WhatsApp (com DDD)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = endereco,
            onValueChange = { endereco = it },
            label = { Text("Endereço") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = cardapio,
            onValueChange = { cardapio = it },
            label = { Text("Cardápio (um item por linha: Nome - preço)") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = distancia,
            onValueChange = { distancia = it.take(5) },
            label = { Text("Distância de você (km)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        if (erro.isNotEmpty()) {
            Text(erro, color = MaterialColorError, fontSize = 14.sp)
        }
        Button(
            onClick = {
                if (nome.isBlank()) {
                    erro = "Informe o nome do comércio."
                } else if (endereco.isBlank()) {
                    erro = "Informe o endereço."
                } else {
                    val km = distancia.replace(',', '.').toDoubleOrNull() ?: 1.0
                    vm.addStore(nome, categoria, legenda, whatsapp, instagram, endereco, cardapio, km)
                    nome = ""
                    legenda = ""
                    whatsapp = ""
                    instagram = ""
                    endereco = ""
                    cardapio = ""
                    distancia = "1"
                    erro = ""
                    toast(context, "Publicado! Veja em Perto de você.")
                    vm.category = null
                    vm.tab = AppTab.HOME
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Brand.Bg),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("Publicar", fontWeight = FontWeight.Bold)
        }
    }
}

private val MaterialColorError = Color(0xFFFF6B8A)
