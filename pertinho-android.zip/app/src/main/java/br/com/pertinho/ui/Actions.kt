package br.com.pertinho.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import br.com.pertinho.data.Store

private fun safeStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Nenhum app disponível para esta ação.", Toast.LENGTH_SHORT).show()
    }
}

fun shareStore(context: Context, store: Store) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "Olha o " + store.name + " no Pertinho! " + store.address)
    }
    safeStart(context, Intent.createChooser(send, "Compartilhar"))
}

fun openWhatsApp(context: Context, number: String) {
    val digits = number.filter { it.isDigit() }
    if (digits.isEmpty()) return
    val full = if (digits.length <= 11) "55" + digits else digits
    safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + full)))
}

fun openDirections(context: Context, store: Store) {
    val url = "https://www.google.com/maps/search/?api=1&query=" + store.lat + "," + store.lng
    safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

fun toast(context: Context, text: String) {
    Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
}
