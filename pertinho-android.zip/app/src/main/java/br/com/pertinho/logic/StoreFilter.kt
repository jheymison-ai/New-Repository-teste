package br.com.pertinho.logic

import br.com.pertinho.data.LatLng
import br.com.pertinho.data.Store
import br.com.pertinho.data.StoreDistance
import java.text.Normalizer
import java.util.Locale

object StoreFilter {
    private val ACCENTS = Regex("\\p{InCombiningDiacriticalMarks}+")

    /** Minúsculas e sem acentos, para buscar "cafe" e achar "Café". */
    fun normalize(text: String): String =
        Normalizer.normalize(text.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(ACCENTS, "")

    fun matches(store: Store, query: String): Boolean {
        val q = normalize(query.trim())
        if (q.isEmpty()) return true
        val menuNames = store.menu.joinToString(" ") { it.name }
        val haystack = normalize(
            store.name + " " + store.category + " " + store.description + " " + store.address + " " + menuNames
        )
        return haystack.contains(q)
    }

    /**
     * Filtra por categoria, raio (null = sem limite) e texto, e ordena do mais perto para o mais longe.
     */
    fun filter(
        stores: List<Store>,
        origin: LatLng,
        category: String?,
        radiusKm: Double?,
        query: String
    ): List<StoreDistance> =
        stores
            .map { StoreDistance(it, Geo.distanceKm(origin.lat, origin.lng, it.lat, it.lng)) }
            .filter { category == null || it.store.category == category }
            .filter { radiusKm == null || it.km <= radiusKm }
            .filter { matches(it.store, query) }
            .sortedBy { it.km }
}
