package br.com.pertinho.ui

import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import br.com.pertinho.data.StoreDistance
import br.com.pertinho.logic.formatDistance

/** Cores do design system do Pertinho (mesmos valores de css/tokens.css). */
object Brand {
    val Pink = Color(0xFFFF3D77)
    val PinkText = Color(0xFFFF5C8D)
    val PinkStrong = Color(0xFFD4144F)
    val Orange = Color(0xFFFF8A3D)
    val Cyan = Color(0xFF25C2E8)
    val Star = Color(0xFFFFC53D)
    val Bg = Color(0xFF0B0B0F)
    val Card = Color(0xFF17171D)
    val Line = Color(0xFF2A2A33)
    val Muted = Color(0xFF9A9AA8)
    val Gradient = Brush.linearGradient(listOf(Orange, Pink))
}

/** Botão de opção/filtro. Selecionado = rosa forte; texto branco com contraste AA. */
@Composable
fun PillChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    container: Color = Brand.Card
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Brand.PinkStrong else container)
            .clickable(onClick = onClick)
            .defaultMinSize(minHeight = 40.dp)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp)
    )
}

/** Linha de comércio usada na busca, no perfil e nos avisos. */
@Composable
fun StoreRow(item: StoreDistance, onClick: () -> Unit) {
    val s = item.store
    val meta = buildString {
        append(s.category)
        append(" · ")
        append(formatDistance(item.km))
        if (s.priceRange.isNotBlank()) {
            append(" · ")
            append(s.priceRange)
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brand.Card)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(Media.image(s.category, s.videoIndex)),
            contentDescription = s.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = s.name,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(text = meta, color = Brand.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                text = s.description,
                color = Color.White,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Vídeo curto do app (res/raw) em loop e sem som. Só toca quando [playing] é verdadeiro. */
@Composable
fun LoopingVideo(resId: Int, playing: Boolean, modifier: Modifier = Modifier) {
    val holder = remember { arrayOfNulls<VideoView>(1) }
    DisposableEffect(Unit) {
        onDispose { holder[0]?.stopPlayback() }
    }
    key(resId) {
        AndroidView(
            modifier = modifier,
            factory = { ctx ->
                VideoView(ctx).apply {
                    holder[0] = this
                    setVideoURI(Uri.parse("android.resource://" + ctx.packageName + "/" + resId))
                    setOnPreparedListener { mp ->
                        mp.isLooping = true
                        mp.setVolume(0f, 0f)
                        seekTo(1) // mostra o primeiro quadro enquanto não está tocando
                    }
                }
            },
            update = { view ->
                if (playing) {
                    if (!view.isPlaying) view.start()
                } else if (view.isPlaying) {
                    view.pause()
                }
            }
        )
    }
}
