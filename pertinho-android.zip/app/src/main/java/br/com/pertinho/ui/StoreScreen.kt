package br.com.pertinho.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.pertinho.PertinhoViewModel
import br.com.pertinho.data.Store
import br.com.pertinho.logic.Geo
import br.com.pertinho.logic.formatDistance
import br.com.pertinho.logic.formatPrice

@Composable
fun StoreScreen(vm: PertinhoViewModel, store: Store) {
    val context = LocalContext.current
    val km = Geo.distanceKm(vm.origin.lat, vm.origin.lng, store.lat, store.lng)
    val isFollowing = store.id in vm.following
    val isSaved = store.id in vm.saved
    val outline = BorderStroke(1.dp, Brand.Line)

    Column(
        Modifier
            .fillMaxSize()
            .background(Brand.Bg)
            .verticalScroll(rememberScrollState())
    ) {
        Box(Modifier.fillMaxWidth().height(260.dp)) {
            Image(
                painter = painterResource(Media.image(store.category, store.videoIndex)),
                contentDescription = store.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color(0xCC000000))))
            )
            IconButton(
                onClick = { vm.openStoreId = null },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color(0x66000000), CircleShape)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                Text(store.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                val meta = store.category + " · " + formatDistance(km) +
                    (if (store.priceRange.isNotBlank()) " · " + store.priceRange else "")
                Text(meta, color = Color.White, fontSize = 14.sp)
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { vm.toggleFollow(store.id) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFollowing) Brand.Card else Color.White,
                        contentColor = if (isFollowing) Color.White else Brand.Bg
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text(if (isFollowing) "Seguindo" else "Seguir", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { vm.toggleSave(store.id) },
                    border = outline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = if (isSaved) Brand.Star else Color.White),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text(if (isSaved) "Salvo" else "Salvar")
                }
                OutlinedButton(
                    onClick = { shareStore(context, store) },
                    border = outline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Enviar")
                }
            }

            if (store.description.isNotBlank()) {
                Text(store.description, color = Color.White, fontSize = 15.sp)
            }
            InfoLine("Endereço", store.address)
            if (store.hours.isNotBlank()) InfoLine("Horário", store.hours)
            if (store.instagram.isNotBlank()) InfoLine("Instagram", store.instagram)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { openDirections(context, store) },
                    border = outline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Como chegar")
                }
                if (store.whatsapp.isNotBlank()) {
                    OutlinedButton(
                        onClick = { openWhatsApp(context, store.whatsapp) },
                        border = outline,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text("WhatsApp")
                    }
                }
            }

            SectionTitle("Fotos")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (n in 1..2) {
                    Image(
                        painter = painterResource(Media.image(store.category, n)),
                        contentDescription = "Foto " + n + " de " + store.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                    )
                }
            }

            SectionTitle("Cardápio e serviços")
            if (store.menu.isEmpty()) {
                Text("Nenhum item cadastrado.", color = Brand.Muted)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    store.menu.forEach { item ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brand.Card)
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.name, color = Color.White, modifier = Modifier.weight(1f))
                            Text(formatPrice(item.price), color = Brand.PinkText, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = Brand.Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 15.sp)
    }
}
