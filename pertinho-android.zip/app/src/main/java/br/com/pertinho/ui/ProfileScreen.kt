package br.com.pertinho.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.pertinho.PertinhoViewModel
import br.com.pertinho.logic.Geo
import br.com.pertinho.data.Store
import br.com.pertinho.data.StoreDistance

private fun PertinhoViewModel.withDistance(stores: List<Store>): List<StoreDistance> =
    stores.map { StoreDistance(it, Geo.distanceKm(origin.lat, origin.lng, it.lat, it.lng)) }

@Composable
fun ProfileScreen(vm: PertinhoViewModel) {
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    val savedStores = vm.withDistance(vm.allStores.filter { it.id in vm.saved })
    val myStores = vm.withDistance(vm.userStores)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(Brand.Gradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
            Column {
                Text("Você", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Perfil local, guardado só neste aparelho", color = Brand.Muted, fontSize = 13.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Curtidas", vm.liked.size, Modifier.weight(1f))
            Stat("Salvos", vm.saved.size, Modifier.weight(1f))
            Stat("Seguindo", vm.following.size, Modifier.weight(1f))
            Stat("Posts", vm.userStores.size, Modifier.weight(1f))
        }

        SectionTitle("Salvos")
        if (savedStores.isEmpty()) {
            Text("Toque em Salvar no feed para guardar comércios aqui.", color = Brand.Muted, fontSize = 14.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                savedStores.forEach { item -> StoreRow(item) { vm.openStoreId = item.store.id } }
            }
        }

        SectionTitle("Meus comércios")
        if (myStores.isEmpty()) {
            Text("Você ainda não postou nenhum comércio.", color = Brand.Muted, fontSize = 14.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                myStores.forEach { item -> StoreRow(item) { vm.openStoreId = item.store.id } }
            }
        }

        OutlinedButton(
            onClick = { confirmClear = true },
            border = BorderStroke(1.dp, Brand.Line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("Limpar meus dados")
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Brand.Card,
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("Limpar dados?") },
            text = { Text("Curtidas, salvos, seguidos, comentários e comércios postados serão apagados deste aparelho.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearAll()
                    confirmClear = false
                }) { Text("Limpar", color = Brand.PinkText) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancelar", color = Color.White) }
            }
        )
    }
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brand.Card)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value.toString(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Brand.Muted, fontSize = 12.sp)
    }
}
