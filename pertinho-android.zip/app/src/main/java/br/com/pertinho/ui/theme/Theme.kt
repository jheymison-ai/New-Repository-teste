package br.com.pertinho.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PertinhoDark = darkColorScheme(
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF0B0B0F),
    secondary = Color(0xFFFF5C8D),
    onSecondary = Color(0xFF0B0B0F),
    tertiary = Color(0xFF25C2E8),
    background = Color(0xFF0B0B0F),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF0B0B0F),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF17171D),
    onSurfaceVariant = Color(0xFF9A9AA8),
    outline = Color(0xFF3A3A46),
    error = Color(0xFFFF6B8A)
)

/** Tema escuro do Pertinho (base neutra + destaque rosa/laranja), igual ao design system do protótipo. */
@Composable
fun PertinhoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PertinhoDark, content = content)
}
