package br.com.pertinho.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import br.com.pertinho.AppTab
import br.com.pertinho.PertinhoViewModel

private data class NavEntry(val tab: AppTab, val label: String, val icon: ImageVector)

private val NAV_ENTRIES: List<NavEntry> = listOf(
    NavEntry(AppTab.HOME, "Início", Icons.Filled.Home),
    NavEntry(AppTab.EXPLORE, "Explorar", Icons.Filled.Search),
    NavEntry(AppTab.POST, "Postar", Icons.Filled.Add),
    NavEntry(AppTab.NOTICES, "Avisos", Icons.Filled.Notifications),
    NavEntry(AppTab.PROFILE, "Perfil", Icons.Filled.Person)
)

@Composable
fun PertinhoApp(vm: PertinhoViewModel) {
    val openId = vm.openStoreId
    val openStore = if (openId != null) vm.storeById(openId) else null

    BackHandler(enabled = vm.commentsFor != null || openStore != null) {
        if (vm.commentsFor != null) vm.commentsFor = null else vm.openStoreId = null
    }

    Scaffold(
        containerColor = Brand.Bg,
        contentColor = Color.White,
        bottomBar = { BottomBar(vm) }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (vm.tab) {
                AppTab.HOME -> FeedScreen(vm)
                AppTab.EXPLORE -> ExploreScreen(vm)
                AppTab.POST -> PostScreen(vm)
                AppTab.NOTICES -> NoticesScreen(vm)
                AppTab.PROFILE -> ProfileScreen(vm)
            }
            if (openStore != null) {
                StoreScreen(vm, openStore)
            }
        }
    }

    val commentsId = vm.commentsFor
    if (commentsId != null) {
        CommentsDialog(vm, commentsId)
    }
}

@Composable
private fun BottomBar(vm: PertinhoViewModel) {
    NavigationBar(containerColor = Brand.Bg, contentColor = Color.White) {
        NAV_ENTRIES.forEach { entry ->
            NavigationBarItem(
                selected = vm.tab == entry.tab,
                onClick = {
                    vm.openStoreId = null
                    vm.tab = entry.tab
                },
                icon = { Icon(entry.icon, contentDescription = entry.label) },
                label = { Text(entry.label, fontSize = 11.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = Color.White,
                    indicatorColor = Brand.PinkStrong,
                    unselectedIconColor = Brand.Muted,
                    unselectedTextColor = Brand.Muted
                )
            )
        }
    }
}
