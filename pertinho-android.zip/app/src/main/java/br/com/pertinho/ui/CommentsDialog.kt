package br.com.pertinho.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.pertinho.PertinhoViewModel

@Composable
fun CommentsDialog(vm: PertinhoViewModel, storeId: String) {
    var text by rememberSaveable { mutableStateOf("") }
    val list = vm.comments[storeId] ?: emptyList()
    val storeName = vm.storeById(storeId)?.name ?: "Comentários"

    AlertDialog(
        onDismissRequest = { vm.commentsFor = null },
        containerColor = Brand.Card,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text(storeName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (list.isEmpty()) {
                    Text("Seja o primeiro a comentar.", color = Brand.Muted)
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list) { c -> Text(c, color = Color.White) }
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(300) },
                        placeholder = { Text("Escreva um comentário") },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        vm.addComment(storeId, text)
                        text = ""
                    }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar", tint = Color.White)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.commentsFor = null }) { Text("Fechar", color = Color.White) }
        }
    )
}
