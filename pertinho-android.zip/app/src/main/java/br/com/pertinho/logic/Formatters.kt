package br.com.pertinho.logic

import br.com.pertinho.data.MenuItem
import java.util.Locale
import kotlin.math.roundToInt

private val PT_BR: Locale = Locale.forLanguageTag("pt-BR")

fun formatPrice(price: Double?): String = when {
    price == null -> "Sob consulta"
    price <= 0.0 -> "Grátis"
    else -> String.format(PT_BR, "R\$ %.2f", price)
}

fun formatDistance(km: Double): String =
    if (km < 1.0) "${(km * 1000).roundToInt()} m" else String.format(PT_BR, "%.1f km", km)

private val MENU_LINE = Regex("""(.*\S)\s*[-–:;]\s*(\d+(?:[.,]\d{1,2})?)\s*""")

/** Converte um texto "um item por linha" (ex.: "Pizza grande - 54,90") em itens de cardápio. */
fun parseMenu(text: String): List<MenuItem> =
    text.lines()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { line ->
            val match = MENU_LINE.matchEntire(line)
            if (match != null) {
                MenuItem(
                    match.groupValues[1].trim(),
                    match.groupValues[2].replace(',', '.').toDoubleOrNull()
                )
            } else {
                MenuItem(line, null)
            }
        }
