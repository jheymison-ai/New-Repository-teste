package br.com.pertinho.data

data class LatLng(val lat: Double, val lng: Double)

data class MenuItem(val name: String, val price: Double?)

data class Category(val name: String, val group: String, val mediaKey: String)

data class Store(
    val id: String,
    val name: String,
    val category: String,
    val priceRange: String,
    val description: String,
    val address: String,
    val hours: String,
    val lat: Double,
    val lng: Double,
    val menu: List<MenuItem>,
    val videoIndex: Int = 1,
    val whatsapp: String = "",
    val instagram: String = "",
    val userCreated: Boolean = false
)

data class StoreDistance(val store: Store, val km: Double)
