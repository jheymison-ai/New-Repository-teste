package br.com.pertinho

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import br.com.pertinho.data.MenuItem
import br.com.pertinho.data.SampleData
import br.com.pertinho.data.Store
import br.com.pertinho.data.StoreDistance
import br.com.pertinho.logic.StoreFilter
import br.com.pertinho.logic.parseMenu
import org.json.JSONArray
import org.json.JSONObject

enum class AppTab { HOME, EXPLORE, POST, NOTICES, PROFILE }

enum class FeedTab(val label: String) {
    FOLLOWING("Seguindo"),
    NEARBY("Perto de você"),
    FOR_YOU("Para você")
}

val RADII: List<Double> = listOf(1.0, 3.0, 5.0, 10.0, 25.0)

class PertinhoViewModel : ViewModel() {

    private var prefs: SharedPreferences? = null

    // — navegação e filtros —
    var tab by mutableStateOf(AppTab.HOME)
    var feedTab by mutableStateOf(FeedTab.NEARBY)
    var category by mutableStateOf<String?>(null)
    var radiusKm by mutableStateOf(5.0)
    var openStoreId by mutableStateOf<String?>(null)
    var commentsFor by mutableStateOf<String?>(null)
    var soundOn by mutableStateOf(false)

    // — dados do usuário (salvos no aparelho) —
    var liked by mutableStateOf<Set<String>>(emptySet())
        private set
    var saved by mutableStateOf<Set<String>>(emptySet())
        private set
    var following by mutableStateOf<Set<String>>(emptySet())
        private set
    var comments by mutableStateOf<Map<String, List<String>>>(emptyMap())
        private set
    var userStores by mutableStateOf<List<Store>>(emptyList())
        private set

    val origin = SampleData.origin

    val allStores: List<Store>
        get() = SampleData.stores + userStores

    fun storeById(id: String): Store? = allStores.firstOrNull { it.id == id }

    fun feedPosts(): List<StoreDistance> {
        val all = allStores
        return when (feedTab) {
            FeedTab.FOLLOWING ->
                StoreFilter.filter(all.filter { it.id in following }, origin, category, null, "")
            FeedTab.NEARBY ->
                StoreFilter.filter(all, origin, category, radiusKm, "")
            FeedTab.FOR_YOU ->
                StoreFilter.filter(all, origin, category, null, "").sortedBy { it.store.id.hashCode() }
        }
    }

    fun likeCount(id: String): Int =
        120 + (id.hashCode() and 0x7fffffff) % 880 + (if (id in liked) 1 else 0)

    fun commentCount(id: String): Int = comments[id]?.size ?: 0

    fun toggleLike(id: String) {
        liked = if (id in liked) liked - id else liked + id
        persist()
    }

    fun toggleSave(id: String) {
        saved = if (id in saved) saved - id else saved + id
        persist()
    }

    fun toggleFollow(id: String) {
        following = if (id in following) following - id else following + id
        persist()
    }

    fun addComment(id: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val current = comments[id] ?: emptyList()
        comments = comments + (id to (current + clean.take(300)))
        persist()
    }

    fun addStore(
        name: String,
        category: String,
        description: String,
        whatsapp: String,
        instagram: String,
        address: String,
        menuText: String,
        distanceKm: Double
    ) {
        val km = distanceKm.coerceIn(0.1, 25.0)
        val index = (userStores.size % 2) + 1
        val store = Store(
            id = "u" + System.currentTimeMillis(),
            name = name.trim(),
            category = category,
            priceRange = "",
            description = description.trim(),
            address = address.trim(),
            hours = "",
            lat = origin.lat + km / 111.0,
            lng = origin.lng,
            menu = parseMenu(menuText),
            videoIndex = index,
            whatsapp = whatsapp.trim(),
            instagram = instagram.trim(),
            userCreated = true
        )
        userStores = userStores + store
        persist()
    }

    fun clearAll() {
        liked = emptySet()
        saved = emptySet()
        following = emptySet()
        comments = emptyMap()
        userStores = emptyList()
        persist()
    }

    // — persistência simples em SharedPreferences —

    fun attach(preferences: SharedPreferences) {
        if (prefs != null) return
        prefs = preferences
        liked = preferences.getStringSet("liked", emptySet())?.toSet() ?: emptySet()
        saved = preferences.getStringSet("saved", emptySet())?.toSet() ?: emptySet()
        following = preferences.getStringSet("following", emptySet())?.toSet() ?: emptySet()
        comments = readComments(preferences.getString("comments", null))
        userStores = readStores(preferences.getString("stores", null))
    }

    private fun persist() {
        val p = prefs ?: return
        val commentsJson = JSONObject()
        for ((key, list) in comments) {
            commentsJson.put(key, JSONArray(list))
        }
        val storesJson = JSONArray()
        for (s in userStores) {
            storesJson.put(storeToJson(s))
        }
        p.edit()
            .putStringSet("liked", liked)
            .putStringSet("saved", saved)
            .putStringSet("following", following)
            .putString("comments", commentsJson.toString())
            .putString("stores", storesJson.toString())
            .apply()
    }

    private fun readComments(raw: String?): Map<String, List<String>> {
        if (raw == null) return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val result = HashMap<String, List<String>>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val arr = obj.getJSONArray(key)
                result[key] = List(arr.length()) { i -> arr.getString(i) }
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun readStores(raw: String?): List<Store> {
        if (raw == null) return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i -> storeFromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun storeToJson(s: Store): JSONObject {
        val menu = JSONArray()
        for (item in s.menu) {
            val o = JSONObject()
            o.put("n", item.name)
            val price = item.price
            if (price != null) o.put("p", price)
            menu.put(o)
        }
        val o = JSONObject()
        o.put("id", s.id)
        o.put("name", s.name)
        o.put("category", s.category)
        o.put("priceRange", s.priceRange)
        o.put("description", s.description)
        o.put("address", s.address)
        o.put("hours", s.hours)
        o.put("lat", s.lat)
        o.put("lng", s.lng)
        o.put("menu", menu)
        o.put("videoIndex", s.videoIndex)
        o.put("whatsapp", s.whatsapp)
        o.put("instagram", s.instagram)
        return o
    }

    private fun storeFromJson(o: JSONObject): Store {
        val menuArr = o.optJSONArray("menu")
        val menu = ArrayList<MenuItem>()
        if (menuArr != null) {
            for (i in 0 until menuArr.length()) {
                val mi = menuArr.getJSONObject(i)
                menu.add(MenuItem(mi.getString("n"), if (mi.has("p")) mi.getDouble("p") else null))
            }
        }
        return Store(
            id = o.getString("id"),
            name = o.getString("name"),
            category = o.getString("category"),
            priceRange = o.optString("priceRange", ""),
            description = o.optString("description", ""),
            address = o.optString("address", ""),
            hours = o.optString("hours", ""),
            lat = o.getDouble("lat"),
            lng = o.getDouble("lng"),
            menu = menu,
            videoIndex = o.optInt("videoIndex", 1),
            whatsapp = o.optString("whatsapp", ""),
            instagram = o.optString("instagram", ""),
            userCreated = true
        )
    }
}
