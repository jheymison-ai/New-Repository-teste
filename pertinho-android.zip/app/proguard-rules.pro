# Sem regras extras: o build de depuração não usa minificação.
