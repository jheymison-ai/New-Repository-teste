# Relatório de conversão — Pertinho v23 → APK Android

## 1. Resumo honesto
- **Projeto Android completo criado** (Kotlin + Gradle + WebView com os arquivos originais empacotados) e **workflow de nuvem pronto**.
- **O APK NÃO foi compilado neste ambiente**: não há Android SDK, Gradle nem rede aqui (só JDK 21). Portanto **o código Kotlin e os arquivos Gradle nunca foram compilados nem executados**; as versões escolhidas (AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, compileSdk/targetSdk 35, JDK 17, webkit 1.12.1, appcompat 1.7.0, core-ktx 1.15.0) são combinações conhecidas, mas **não verificadas aqui**. A primeira execução do workflow pode exigir pequenos ajustes de compilação.
- Testes **executados de verdade**: camada web (Playwright/Chromium). Testes Android (unitários e de emulador) **foram escritos mas não executados**.

## 2. Inventário e auditoria (fases 1–2)
61 arquivos (3,5 MB): `index.html`, `css/{tokens,style}.css`, `js/{boot,icons,data,api,app}.js`, `sw.js`, `manifest.webmanifest`, 14 vídeos, 14 fotos, 7 músicas, ícones, 6 testes e2e e 7 documentos. Sem build, sem npm. Dependências externas (todas HTTPS, sem chave): iTunes Search, Audius, Overpass, Nominatim, Open-Meteo, ViaCEP, Google Identity (opcional), Mixkit (vídeos/fotos remotos com fallback local).
Não havia identificador de pacote: escolhido `br.com.pertinho.app`.

## 3. O que mudou no web (diff exato, verificado)
1. `index.html`: removida a linha `<link rel="manifest">`; adicionado `<script src="js/android-bridge.js">`.
2. `js/app.js`: removido o registro do service worker (linha 340).
3. Não copiados para o APK: `sw.js`, `manifest.webmanifest`, `tests/`, `*.md` (mantidos em `original/`).
CSS, tokens, HTML das telas, dados, APIs e lógica: **idênticos** ao v23.
`android-bridge.js` (novo): `window.__pertinhoBack` (botão Voltar) e `navigator.share` (o WebView não tem Web Share; sem isso o app copiaria o endereço interno do APK).

## 4. Adaptações Android
| Item | Como foi tratado |
|---|---|
| Carregamento local | `WebViewAssetLoader` em `https://appassets.androidplatform.net/assets/www/` (origem https segura; geolocalização e IndexedDB funcionam; CSP original continua válido) |
| Sem navegador externo | Navegação interna fica no WebView; só links https externos (WhatsApp, Instagram, TikTok, Google Maps, OSM), `mailto:`, `tel:`, `geo:` abrem fora; `http`, `file`, `content`, `intent`, `javascript` são bloqueados |
| Voltar | `OnBackPressedCallback` → `__pertinhoBack`: fecha painel/prévia/busca, volta da loja, volta ao Início; no Início sai do app |
| Barras / recortes / teclado | Tela inteira com *insets* de barras do sistema, recorte e teclado aplicados no contêiner; o WebView não recebe `env(safe-area-*)` (fica 0), então não há margem dupla |
| Arquivos / vídeo | `onShowFileChooser` com seletor + gravação pelo app de câmera do sistema (sem permissão CAMERA no manifesto) |
| Localização | Permissão em tempo de execução, só para a origem do app, quando o JS chama `navigator.geolocation` |
| Mídia | Pedidos `Range` de mp4/mp3 atendidos com 206 direto do APK (arquivos sem compressão); pausa de áudio/vídeo em `onPause` |
| Falhas | Queda do processo do WebView recria a tela; `boot.js` original mostra "Tentar de novo" se um script não carregar |
| Segurança | Sem `addJavascriptInterface`; sem acesso a arquivos; sem conteúdo misto; `usesCleartextTraffic=false`; `allowBackup=false`; câmera/mic via `getUserMedia` negados |
| Ícone/nome | "Pertinho"; ícones gerados do `icon-512.png` original (legado, redondo e adaptativo com fundo preto) |

## 5. Testes executados (resultados reais)
**Originais v23 sobre o pacote do APK** (`scripts/run_web_tests.sh`, log em `docs/web-tests-originais.log`):
- e2e_lugar, e2e_responsive, e2e_explorar, e2e_design, e2e_auditoria: **TUDO OK**.
- e2e_smoke: **35 verificações OK e 1 falha esperada** no último passo ("recarregar offline"), que depende do service worker removido de propósito. Na versão original o mesmo teste passa (confirmado). A cobertura equivalente para o APK está no teste abaixo.

**Origem real do APK, sem rede** (`scripts/e2e_apk_origin.py`): **32/32 OK**. Cobre abertura offline, ausência de manifest/service worker, sem erros JS, sem violação de CSP, sem arquivos locais faltando, navegação entre Início/Explorar/Avisos/Perfil, Voltar (painel, loja, busca, Perfil, Início), compartilhar (gera `pertinho-share://`), curtida persistida após recarregar offline, sem rolagem horizontal em 320×568, 360×640, 390×844, 412×915, 844×390 e 768×1024.
**Comparação visual** original × pacote do APK (390×844, feed/Explorar/Avisos/Perfil): diferença de pixels **0,000%** nas 4 telas (`docs/capturas/`). Atenção: isso compara o **conteúdo web**; **não** compara o app dentro de um WebView Android real.

## 6. Não executado / pendente
- Compilação do APK, `testDebugUnitTest` (UrlPolicyTest) e `connectedDebugAndroidTest` (MainActivityTest): escritos, **não executados**; rodam no workflow.
- Em dispositivo real, a verificar: resposta 206 de vídeo (seek), seletor/gravação de vídeo, permissão de localização, barras do sistema, teclado, rotação (travado em retrato como no manifesto original), reprodução de áudio.
- Comparação visual no WebView do Android (não feita).
- Tema claro: barra de status/navegação ficam pretas (fundo do contêiner); o feed e a barra inferior já eram sempre escuros. Pode haver faixa preta acima de telas claras — verificar no aparelho.
- Funcionalidades que dependem de rede (iTunes/Audius, Overpass, Nominatim, Open-Meteo, ViaCEP, Mixkit): **não testadas com rede real** (sem rede aqui); a revisão foi estática. O código e a CSP originais não foram alterados.
- Login Google: `CFG.GOOGLE_CLIENT_ID` está vazio, então continua **login de demonstração**. Um login real exigiria registrar a origem `https://appassets.androidplatform.net` e validar o token em servidor; o Google costuma bloquear OAuth em WebView embutido, e o caminho recomendado seria Credential Manager nativo. Não implementado.
- Sem backend: curtidas, comentários, avaliações, seguidores, lojas e vídeos postados ficam **só no aparelho** (localStorage/IndexedDB). Não há sincronização entre dispositivos (ver `original/pertinho/API-BACKEND.md`).
- Limitações herdadas da v23 (não alteradas): comércios do OpenStreetMap em raio fixo de 3 km; prévias de 30 s do iTunes; notas das lojas de exemplo fictícias.
- "Compartilhar" envia só texto (não há site público para linkar).
- Sem `gradlew`/wrapper no pacote.
