#!/usr/bin/env bash
# Compila localmente (precisa de JDK 17, Android SDK com platform 35 e Gradle 8.9+; ANDROID_HOME definido).
set -e
cd "$(dirname "$0")"
python3 scripts/prepare_web.py
gradle :app:testDebugUnitTest :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
