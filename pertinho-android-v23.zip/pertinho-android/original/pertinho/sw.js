/* Pertinho — service worker. Guarda o "casco" do app para abrir offline.
   Só cuida de arquivos do próprio site (GET). Vídeo/áudio (Range) e APIs externas passam direto pela rede.
   Ao mudar qualquer arquivo do app, aumente VERSION para renovar o cache. */
const VERSION="pertinho-v23";
const SHELL=["./","index.html","css/tokens.css","css/style.css","js/boot.js","js/icons.js","js/data.js","js/api.js","js/app.js","manifest.webmanifest","assets/logo.svg","assets/icon-192.png","assets/icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==VERSION).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=="GET"||u.origin!==location.origin||r.headers.has("range")||/\.(mp4|mp3)$/i.test(u.pathname))return;
  // páginas: rede primeiro (pega versão nova), cache como reserva offline
  if(r.mode==="navigate"){e.respondWith(fetch(r).then(x=>{const c=x.clone();caches.open(VERSION).then(k=>k.put("index.html",c));return x}).catch(()=>caches.match("index.html").then(x=>x||caches.match("./"))));return}
  // demais arquivos locais: cache primeiro, atualiza em segundo plano
  e.respondWith(caches.match(r).then(hit=>{const net=fetch(r).then(x=>{if(x.ok){const c=x.clone();caches.open(VERSION).then(k=>k.put(r,c))}return x}).catch(()=>hit);return hit||net}))
});
