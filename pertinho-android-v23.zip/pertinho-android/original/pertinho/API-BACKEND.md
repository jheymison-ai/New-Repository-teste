# Contrato de API sugerido para o backend do Pertinho

Inspirado na organização das rotas do **Loops** (servidor de vídeos curtos open source). Só o *desenho* das rotas foi aproveitado: o Loops é AGPL-3.0, então nenhum código dele foi copiado para o Pertinho. Se um dia você usar o código do Loops no seu servidor, o seu servidor também precisa ser AGPL.

| Ação no app | Rota sugerida |
|---|---|
| Feed por proximidade | `GET /v1/feed?lat=&lng=&raio=&cat=&q=` |
| Curtir / descurtir vídeo | `POST /v1/video/like/{id}` · `POST /v1/video/unlike/{id}` |
| Comentários | `GET/POST /v1/video/comments/{id}` |
| Busca | `GET /v1/search?q=` (limite de requisições por usuário) |
| Perfil da loja + vídeos | `GET /v1/store/{id}` · `GET /v1/store/{id}/videos` |
| **Avaliar loja (novo)** | `POST /v1/store/{id}/rating` `{stars:1-5, text?}` · `GET /v1/store/{id}/ratings` |
| Postar vídeo | `POST /v1/studio/videos` (valida tipo, tamanho e duração no servidor) |

Regras: uma avaliação por usuário e loja (a nova substitui a anterior); só usuário logado avalia; nota média calculada no servidor; `throttle` em busca, comentários e avaliação.
Na v6 as avaliações ficam no `localStorage`; as notas das lojas de exemplo são fictícias e comércios reais (OpenStreetMap) começam sem nota.
