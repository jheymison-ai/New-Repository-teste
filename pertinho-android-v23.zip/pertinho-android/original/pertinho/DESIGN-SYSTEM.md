# Pertinho — Design System (v23)

Base **neutra** (preto, branco e cinzas, como a Uber) + **um** destaque de marca (rosa→laranja) + ciano de apoio (como o TikTok). O destaque aparece com intenção: curtir, aba/filtro ativo, selos e o botão central. A ação principal de cada tela é sólida e neutra.

Tudo vem de `css/tokens.css`. `css/style.css` não define valores novos: só consome as variáveis. Para mudar a identidade, edite apenas `tokens.css`.

## Tokens
| Grupo | Variáveis |
|---|---|
| Marca | `--r` rosa · `--o` laranja · `--cy` ciano · `--grad` degradê · `--brand-strong` (fundo de selo com texto branco, 5,2:1) · `--brand-text` (texto de marca, AA nos dois temas) · `--star` |
| Superfícies/texto | `--bg` `--card` `--line` `--tx` `--mut` · `--ink`/`--on-ink` (botão primário) · `--scrim` `--glass` |
| Semânticas | `--ok` `--warn` `--err` `--info` (valores diferentes no tema claro, todos ≥ 4,5:1 sobre o fundo) |
| Foco | `--focus` (anel de 2 px) · `--focus-a` (halo em campos) |
| Espaçamento (grade de 4 px) | `--sp-1`=4 · `--sp-2`=8 · `--sp-3`=12 · `--sp-4`=16 · `--sp-5`=20 · `--sp-6`=24 · `--sp-8`=32 |
| Raios | `--rad-sm`=10 · `--rad-md`=14 · `--rad-lg`=22 · `--rad-pill` |
| Elevação | `--sh-1` `--sh-2` `--sh-3` |
| Tipografia | `--font` · `--fs-xs/sm/md/lg/xl` · `--fw-m` 600 · `--fw-b` 700 |
| Interação | `--tap`=44 px (alvo mínimo) · `--ease` · `--dur-1` `--dur-2` · `--sat` `--sab` (áreas seguras) |

Temas: escuro por padrão; `@media (prefers-color-scheme: light)` troca superfícies, tinta, cores semânticas e de foco. O feed de vídeo e a barra inferior são sempre escuros (conteúdo sobre mídia).

## Componentes compartilhados
- **Botões**: `.btn` (primário, sólido neutro) · `.btn.w` (secundário) · `.pill` (opção/filtro; `.on` = selecionado) · `.back.cta` (ação principal sobre o cabeçalho da loja). Estados: `:active`, `:disabled`, `.is-loading` (spinner; com movimento reduzido mostra o texto esmaecido).
- **Campos**: `input/select/textarea` (inclui `tel`, `email`, `url`), altura ≥ 44 px; `aria-invalid="true"` pinta a borda de erro.
- **Feedback**: `toast(texto, "ok"|"err")` (ponto colorido, quebra de linha, tempo proporcional ao texto) · `.ld` (carregando, use com `role="status"`) · `.note` (nota/erro explicativo) · `#fErr` (`role="alert"`).
- **Abas**: `.tabs` rola de lado em vez de espremer rótulos; `#top .tb` (abas do feed) idem.
- **Utilitários** (substituem estilos inline): `.lbl`, `.lbl.s`, `.note`, `.mut`, `.sub`.
- **Foco**: anel azul de 2 px com halo da cor do fundo (visível em fundo claro e escuro).

## Regras
1. Uma ação principal por tela, sólida; ações secundárias em superfície/contorno.
2. Cor de marca só em destaque (nunca em todos os botões). Texto de marca sobre superfície usa `--brand-text`; fundo com texto branco usa `--brand-strong`.
3. Alvos de toque ≥ 44 px; espaçamentos só da escala `--sp-*`.
4. Erro: diga o problema e como resolver; marque o campo, leve o foco a ele.
5. Movimento: respeitar `prefers-reduced-motion`.
