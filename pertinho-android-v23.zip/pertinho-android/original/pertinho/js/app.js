/* Lógica do Pertinho: feed, gavetas, página do comércio, perfil e cadastro. */
const S={rate:{},rev:{},only:null,likes:{},seg:{},save:{},com:{},cat:"Todos",tab:"perto",raio:5,q:"",user:null,nt:[],ns:{vid:true,promo:true},nd:{},ptab:"lk",nw:0,me:{},place:null};
const $=id=>document.getElementById(id),rad=x=>x*Math.PI/180;
const dist=(a,b)=>{const h=Math.sin(rad(b.lat-a.lat)/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(rad(b.lng-a.lng)/2)**2;return 12742*Math.asin(Math.sqrt(h))};
const fk=n=>(n<10?n.toFixed(1):Math.round(n)+"").replace(".",",")+" km";
const brl=n=>n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const norm=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const hash=s=>[...s].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,7);
const slug=c=>norm(c).replace(/\W+/g,"")||"outros";
// caminhos de mídia: assets/media/<tipo>/<categoria>[-N].<ext>  (k = 1 ou 2; sem k = música)
const ms=c=>{const k=slug(c);return typeof MEDIA!=="undefined"&&MEDIA[k]?k:"outros"};
const rm=(t,c,k)=>{const m=typeof MEDIA!=="undefined"&&MEDIA[ms(c)];if(!m)return"";return t==="music"?(m.m||""):((t==="video"?m.v:m.i)||[])[k-1]||""};
const mu=(t,c,k,e)=>`assets/media/${t}/${ms(c)}${k?"-"+k:""}.${e}`;
function fb(i){if(i.dataset.alt&&i.src.indexOf(i.dataset.alt)<0){i.src=i.dataset.alt}else i.remove()}
const aud=new Audio();aud.loop=true;aud.volume=.6;aud.preload="auto";let SOM=false,audErr=0;
aud.addEventListener("error",()=>{const l=aud._l||[];if(aud._i<l.length-1){aud.src=l[++aud._i];SOM&&aud.play().catch(()=>{});return}if(SOM&&Date.now()-audErr>4000){audErr=Date.now();toast("Sem música para esta categoria")}});
function tocar(s){if(!s||!SOM||document.hidden||s.classList.contains("pz"))return aud.pause();const k=s.dataset.p;if(aud.dataset.s===k){aud.play().catch(()=>{});return}aud.dataset.s=k;aud.pause();
API.musica(s.dataset.c,k).then(t=>{if(aud.dataset.s!==k)return;aud._l=[t&&t.u,s.dataset.mr,s.dataset.mu].filter(Boolean);aud._i=0;aud.src=aud._l[0];aud.play().catch(()=>{});
if(t){const m=s.querySelector(".mu span"),d=s.querySelector(".disc");m.innerHTML=ic("music",13)+" "+esc(t.t+" – "+t.a);if(t.img&&/^https:\/\/[^"'()\s\\]+$/.test(t.img))d.style.backgroundImage=`url("${t.img}")`}})}
const rb=n=>n.id[0]==="d"?3.8+hash(n.id)%12/10:0,rc=n=>n.id[0]==="d"?12+hash(n.id)%230:0,fa=a=>a.toFixed(1).replace(".",",");
function rt(n){const m=S.rate[n.id]||0,b=rb(n),c=rc(n),t=c+(m?1:0);return{c:t,a:t?(b*c+m)/t:0}}
const stars=(a,s=14)=>[1,2,3,4,5].map(i=>ic("star",s,a>=i-.5?"fill st":"st")).join("");
const fmt=n=>n>=1000?(n/1000).toFixed(1).replace(".",",")+" mil":n;
const handle=n=>"@"+norm(n.nome).replace(/\W+/g,"").slice(0,16);
let tt0;function toast(t,k){const e=$("toast");e.textContent=t;if(k)e.dataset.k=k;else delete e.dataset.k;e.classList.add("on");clearTimeout(tt0);tt0=setTimeout(()=>e.classList.remove("on"),Math.max(1700,String(t).length*55))}
let XQ="",negPrev="vFeed"; // XQ = busca feita na tela Explorar (não mexe no feed até tocar em "Buscar feeds")
function go(id){if(!["vExp","vBus","vNeg"].includes(id))XQ="";$("app").classList.toggle("sr",id==="vBus");if(id!=="vFeed")aud.pause();if(id!=="vNeg")pvClose();document.querySelectorAll(".v").forEach(v=>v.classList.toggle("on",v.id===id));document.querySelectorAll("nav [data-go]").forEach(b=>b.classList.toggle("on",b.dataset.go===id));if(id==="vFeed")feed();if(id==="vPer")perfil();if(id==="vExp")explorar();if(id==="vNot")avisos()}
// validação do que vem do localStorage (formato antigo, adulterado ou corrompido não derruba o app)
const CAT_OK=new Set(CATS.map(c=>c[0])),isS=x=>typeof x==="string",isNum=x=>typeof x==="number"&&Number.isFinite(x),pl=x=>!!x&&typeof x==="object"&&!Array.isArray(x);
const limpaN=n=>{if(!pl(n)||!isS(n.id)||!/^[\w-]{1,40}$/.test(n.id)||!isS(n.nome)||!isNum(n.lat)||!isNum(n.lng))return null;const t=(v,m)=>isS(v)?v.slice(0,m):"";
return{...n,nome:n.nome.slice(0,60),categoria:CAT_OK.has(n.categoria)?n.categoria:"Outros",faixa:/^\${0,3}$/.test(n.faixa||"")?(n.faixa||""):"",descricao:t(n.descricao,200),endereco:t(n.endereco,120),horario:t(n.horario,60),
cardapio:Array.isArray(n.cardapio)?n.cardapio.filter(i=>Array.isArray(i)&&isS(i[0])).map(i=>[i[0].slice(0,80),isNum(i[1])?i[1]:null]):[],fotos:Array.isArray(n.fotos)?n.fotos.filter(isS).map(f=>f.replace(/[<>&"']/g,"").slice(0,8)):[]}};
const lerS=s=>{if(!pl(s))return;for(const k of["rate","rev","likes","seg","save","com","nd","ns"])if(pl(s[k]))S[k]=s[k];
S.rev=Object.fromEntries(Object.entries(S.rev).map(([k,v])=>[k,Array.isArray(v)?v.filter(x=>pl(x)&&isS(x.t)&&isNum(x.s)).slice(0,100):[]]));
S.com=Object.fromEntries(Object.entries(S.com).map(([k,v])=>[k,Array.isArray(v)?v.filter(isS).slice(0,100):[]]));
S.rate=Object.fromEntries(Object.entries(S.rate).filter(([k,v])=>isNum(v)&&v>=1&&v<=5));
if(Array.isArray(s.nt))S.nt=s.nt.filter(x=>pl(x)&&isS(x.t)).map(x=>({i:String(x.i||Math.random()),k:isS(x.k)?x.k:"sys",t:x.t.slice(0,200),n:isS(x.n)?x.n:"",ts:isNum(x.ts)?x.ts:Date.now(),r:x.r?1:0})).slice(0,40);
if(["seg","perto","pv","map"].includes(s.tab))S.tab=s.tab;if(["lk","sv","sg","me"].includes(s.ptab))S.ptab=s.ptab;if(isS(s.cat))S.cat=s.cat.slice(0,40);if(isS(s.q))S.q=s.q.slice(0,80);
if(isNum(s.raio)&&s.raio>0&&s.raio<=100)S.raio=s.raio;if(isNum(s.nw))S.nw=s.nw;
if(pl(s.user)&&isS(s.user.nome))S.user={nome:s.user.nome.slice(0,60),email:isS(s.user.email)?s.user.email.slice(0,120):""};
if(pl(s.me)&&isS(s.me.nome))S.me={nome:s.me.nome.slice(0,60)};
if(pl(s.place)&&isS(s.place.n)&&isNum(s.place.lat)&&isNum(s.place.lng))S.place={n:s.place.n.slice(0,60),lat:s.place.lat,lng:s.place.lng}};
const D0=N.slice();try{const s=JSON.parse(localStorage.getItem("pertinho-v2")||"null");if(pl(s)){if(Array.isArray(s.N))N=s.N.map(limpaN).filter(Boolean);lerS(s.S)}}catch(e){}D0.forEach(d=>{if(!N.some(n=>n.id===d.id))N.push(d)});S.only=null;
if(S.place&&Number.isFinite(S.place.lat)&&Number.isFinite(S.place.lng)){POS.lat=S.place.lat;POS.lng=S.place.lng}else S.place=null;
// ao explorar outro lugar, os comércios de exemplo (fictícios, do Rio) ficam ocultos
const vis=n=>!(S.place&&/^d\d/.test(n.id));
let svW=0;const save=()=>{try{localStorage.setItem("pertinho-v2",JSON.stringify({N:N.filter(n=>!/^osm/.test(n.id)),S}))}catch(e){if(!svW){svW=1;toast("Sem espaço para salvar neste aparelho. Exclua comércios em Perfil › Meus comércios.","err")}}};
// copiar link só avisa "copiado" quando realmente copiou
const copiar=t=>navigator.clipboard?navigator.clipboard.writeText(t).then(()=>toast("Link copiado","ok"),()=>toast("Não foi possível copiar o link","err")):toast("Copie o link pela barra do navegador");
// busca: todas as palavras precisam aparecer (em qualquer ordem), sem acento e sem diferenciar maiúsculas
const bate=(hay,q)=>{const h=norm(hay);return norm(q).split(/\s+/).filter(Boolean).every(w=>h.includes(w))};
// preço no formato brasileiro: "1.234,50", "R$ 12,90", "7,5", "12.90"; inválido vira "sem preço"
const preco=s=>{s=String(s).replace(/[^\d,.]/g,"");if(!s)return NaN;if(s.includes(",")){const p=s.split(",");if(p.length>2)return NaN;s=p[0].replace(/\./g,"")+"."+p[1]}else if(/^\d{1,3}(\.\d{3})+$/.test(s))s=s.replace(/\./g,"");const v=parseFloat(s);return v>=0&&v<1e7?v:NaN};
// ao excluir uma loja, apaga também o que o usuário guardou dela
const limpaRastro=id=>{for(const m of[S.likes,S.save,S.com])for(const k of Object.keys(m))if(k.startsWith(id+"-"))delete m[k];for(const m of[S.seg,S.rate,S.rev,S.nd])delete m[id];delete S.nd["v"+id];S.nt=S.nt.filter(x=>x.n!==id)};
let lh=0;
document.addEventListener("click",e=>{const g=e.target.closest("[data-go]");if(g){if(g.closest("nav")&&g.dataset.go==="vFeed"){const t=Date.now();if(t-lh<500){lh=0;S.only=null;save();go("vFeed");$("feed").scrollTop=0;feed(true);API.recarregar().then(()=>feed(true));toast("Feed atualizado");return}lh=t;S.only=null}go(g.dataset.go)}});

// grupos: Comer (cardápio) · Compras (catálogo) · Saúde (serviços, sem preço) · demais (serviços)
const gi=n=>cat(n.categoria)[4],LB=n=>gi(n)===0?"Cardápio":gi(n)===1?"Catálogo":"Serviços",price=(n,i)=>i[1]==null||gi(n)===2?"":brl(i[1]);
const catOk=n=>S.cat==="Todos"||n.categoria===S.cat||(S.cat[0]==="@"&&grp(n.categoria)===S.cat.slice(1));
const catLbl=()=>S.cat[0]==="@"?((GRP.find(g=>g[0]===S.cat.slice(1))||["","📍"])[1]+" "+S.cat.slice(1)):cat(S.cat)[1]+" "+S.cat;
// posts: cada comércio publica 2 vídeos
function posts(all){return (all?N:N.filter(vis)).flatMap(n=>[{id:n.id+"-0",n,txt:n.descricao,tag:"#"+norm(n.categoria).replace(/\W+/g,"")},{id:n.id+"-1",n,txt:n.cardapio[0]?(price(n,n.cardapio[0])?`🔥 ${n.cardapio[0][0]} por ${price(n,n.cardapio[0])}`:n.cardapio[0][0]):"Venha conhecer!",tag:"#pertinho"}])}
const baseL=id=>(hash(id)%90+10)*13;
function lista(){const q=norm(S.q);return posts().map(p=>({...p,d:dist(POS,p.n)})).filter(p=>S.only?p.n.id===S.only:(S.tab==="pv"?p.d<=Math.max(S.raio,25):(S.tab==="seg"?!!S.seg[p.n.id]:p.d<=S.raio))&&catOk(p.n)&&(!q||bate([p.n.nome,p.n.categoria,p.txt,...p.n.cardapio.map(i=>i[0])].join(" "),q))).sort(S.tab==="pv"&&!S.only?(()=>{const A=affin(),dy=new Date().toISOString().slice(0,10),sc=p=>(A[p.n.categoria]||0)*3-p.d*.6+(hash(p.id+dy)%100)/40;return(a,b)=>sc(b)-sc(a)||(a.id>b.id?1:-1)})():(a,b)=>a.d-b.d||(a.id>b.id?1:-1))}
function affin(){const a={},add=(id,w)=>{const n=N.find(x=>x.id===pid(id));if(n)a[n.categoria]=(a[n.categoria]||0)+w};Object.keys(S.likes).forEach(k=>S.likes[k]&&add(k,2));Object.keys(S.save).forEach(k=>S.save[k]&&add(k,3));Object.keys(S.seg).forEach(k=>S.seg[k]&&add(k+"-",4));return a}
let io;
function rail(p){const n=p.n,c=cat(n.categoria),L=!!S.likes[p.id],nc=3+(S.com[p.id]||[]).length;return `<div><div class="av" data-act="neg" role="button" tabindex="0" aria-label="Abrir perfil da loja">${c[1]}<b data-act="seg" role="button" tabindex="0" aria-label="Seguir">${ic(S.seg[n.id]?"check":"plus",12)}</b></div></div>
<div><button data-act="like" aria-label="Curtir">${ic("heart",34,L?"fill liked":"")}<small>${fmt(baseL(p.id)+(L?1:0))}</small></button></div>
<div><button data-act="com" aria-label="Comentários">${ic("comment",34)}<small>${nc}</small></button></div>
<div><button data-act="sav" aria-label="Salvar">${ic("bookmark",32,S.save[p.id]?"fill saved":"")}<small>${fmt(hash(p.id+"s")%40+(S.save[p.id]?1:0))}</small></button></div>
<div><button data-act="sha" aria-label="Enviar">${ic("share",32)}<small>${hash(p.id+"h")%30+2}</small></button></div><div><button data-act="snd" aria-label="Som">${ic(SOM?"volume":"mute",26)}</button></div><div class="disc">${ic("music",16)}</div>`}
function refresh(nid){document.querySelectorAll(`.p[data-n="${nid}"]`).forEach(x=>{const p=posts().find(q=>q.id===x.dataset.p);if(p)x.querySelector(".rail").innerHTML=rail(p)})}
// sem faixa de chips no feed: o botão Filtro do rodapé muda de cor quando há filtro ativo
const filtroAtivo=()=>S.cat!=="Todos"||S.raio!==5||!!S.q||!!S.only||!!S.place;
function chips(){const a=filtroAtivo(),b=$("nDesc");b.classList.toggle("fa",a);b.setAttribute("aria-label",a?"Filtro (filtros ativos)":"Filtro");$("chips").innerHTML="";$("chips").style.display="none"}
function topOn(t){document.querySelectorAll("#top [data-t]").forEach(b=>{const on=b.dataset.t===t;b.classList.toggle("on",on);b.setAttribute("aria-pressed",on)})}
function feed(force){chips();const mp=S.tab==="map";$("feed").style.display=mp?"none":"";$("map").hidden=!mp;if(mp){if($("map").parentNode!==$("vFeed"))$("vFeed").appendChild($("map"));topOn("map");aud.pause();mapOpen();return}const l=lista(),f=$("feed"),st=f.scrollTop,sig=l.map(p=>p.id).join();
topOn(S.tab);
if(!l.length){f.dataset.sig="vazio";f.innerHTML=`<div class="empty"><div><h3>${S.tab==="seg"?"Você ainda não segue ninguém":"Nada por perto com esses filtros"}</h3><p>${S.tab==="seg"?"Toque no + do avatar para seguir um comércio.":"Aumente o raio ou limpe a busca."}</p><button class="btn" id="bL">${S.tab==="seg"?"Ver perto de você":"Limpar filtros"}</button></div></div>`;
$("bL").onclick=()=>{S.tab="perto";S.cat="Todos";S.q="";S.raio=25;feed()};return}
if(!force&&f.dataset.sig===sig&&f.querySelector(".p"))return;
f.innerHTML=l.map(postHTML).join("");io=mount(f,io);if(f.dataset.sig===sig)f.scrollTop=st;f.dataset.sig=sig}
function postHTML(p){const n=p.n,c=cat(n.categoria),h=hash(p.id),k=+p.id.slice(-1)+1;
const ps=[0,1,2,3,4,5].map(i=>`<i style="--l:${(h*(i+3)%90)}%;--s:${24+(h>>i)%30}px;--d:${6+(h+i)%6}s;--dl:-${i*1.7}s">${c[1]}</i>`).join("");
return `<section class="p" data-p="${p.id}" data-n="${n.id}" data-c="${n.categoria}" data-mu="${mu("music",n.categoria,0,"mp3")}" data-mr="${rm("music",n.categoria,0)}"><div class="sc" style="--a:${c[2]};--b:${c[3]}">${ps}<div class="big">${c[1]}</div><img class="ft" src="${rm("img",n.categoria,k)||mu("img",n.categoria,k,"jpg")}" data-alt="${mu("img",n.categoria,k,"jpg")}" alt="" decoding="async" loading="lazy"><video class="vd" muted loop playsinline preload="none">${p.id.endsWith("-0")&&VURL[n.id]?`<source src="${VURL[n.id]}">`:""}${rm("video",n.categoria,k)?`<source src="${rm("video",n.categoria,k)}" type="video/mp4">`:""}<source src="${mu("video",n.categoria,k,"mp4")}" type="video/mp4"></video></div><div class="pl">${ic("play",72,"fill")}</div>
<div class="rail">${rail(p)}</div>
<div class="cap"><b data-act="neg" role="button" tabindex="0">${handle(n)}</b> <span class="chip">${ic("pin",12)}${fk(p.d)}</span><p>${esc(p.txt)} <b class="hl-b">${p.tag}</b></p><div class="mu"><span>${ic("music",13)} som original – ${esc(n.nome)}</span></div></div>
<div class="bar"><u></u></div></section>`}
function mount(f,prev){f.querySelectorAll("video").forEach(v=>{v.muted=true;v.addEventListener("timeupdate",()=>{const x=v.closest(".p");if(!x)return;const u=x.querySelector(".bar u");u.style.animation="none";u.style.width=(v.currentTime/(v.duration||1)*100)+"%"});v.addEventListener("loadeddata",()=>v.classList.add("ok"));v.querySelector("source:last-child").addEventListener("error",()=>v.remove())});
prev&&prev.disconnect();const o=new IntersectionObserver(es=>es.forEach(e=>{const x=e.target,v=x.querySelector("video");x.classList.toggle("act",e.isIntersecting);
if(e.isIntersecting){x.classList.remove("pz");if(v){v.preload="auto";v.play().catch(()=>{})}const nx=x.nextElementSibling&&x.nextElementSibling.querySelector("video");if(nx&&nx.preload==="none")nx.preload="metadata";tocar(x)}
else if(v){v.pause();try{v.currentTime=0}catch(_){}}}),{root:f,threshold:.6});
f.querySelectorAll(".p").forEach(s=>o.observe(s));return o}

let lt=0,tm;
const pclick=e=>{const s=e.target.closest(".p");if(!s)return;const cp=e.target.closest(".cap p");if(cp){cp.classList.toggle("ex");return}const id=s.dataset.p,nid=s.dataset.n,a=e.target.closest("[data-act]")?.dataset.act;
if(a==="snd"){som();return}if(a==="like"){tog(S.likes,id);save();refresh(nid);return}
if(a==="seg"){e.stopPropagation();tog(S.seg,nid);S.seg[nid]&&notify("sys","Você começou a seguir "+(N.find(n=>n.id===nid)||{}).nome,nid);toast(S.seg[nid]?"Seguindo!":"Deixou de seguir");save();S.tab==="seg"?feed():refresh(nid);return}
if(a==="neg"){if(s.closest("#pf")){const c=pvCtx;pvClose();if(c!==nid)abre(nid)}else abre(nid);return}if(a==="com"){coment(id);return}
if(a==="sav"){tog(S.save,id);toast(S.save[id]?"Salvo nos favoritos":"Removido");save();refresh(nid);return}
if(a==="sha"){const t=posts().find(p=>p.id===id).n.nome;if(navigator.share)navigator.share({title:t,text:"Olha esse lugar no Pertinho: "+t}).catch(()=>{});else{copiar(location.href)};return}
const now=Date.now();if(now-lt<300){clearTimeout(tm);lt=0;if(!S.likes[id]){S.likes[id]=true;save()}const r=s.getBoundingClientRect(),h=document.createElement("div");h.className="hr";h.innerHTML=ic("heart",96,"fill");h.style.left=e.clientX-r.left+"px";h.style.top=e.clientY-r.top+"px";s.appendChild(h);setTimeout(()=>{h.remove();refresh(nid)},700)}
else{lt=now;tm=setTimeout(()=>{s.classList.toggle("pz");const v=s.querySelector("video");if(v){if(s.classList.contains("pz"))v.pause();else v.play().catch(()=>{})}tocar(s);lt=0},300)}};$("feed").addEventListener("click",pclick);
function tog(o,k){o[k]=!o[k]}
document.querySelectorAll("#top [data-t]").forEach(b=>b.onclick=()=>{S.tab=b.dataset.t;feed()});

document.addEventListener("visibilitychange",()=>{const x=document.querySelector(".v.on .p.act"),v=x&&x.querySelector("video");if(document.hidden){aud.pause();v&&v.pause()}else if(x){if(v&&!x.classList.contains("pz"))v.play().catch(()=>{});tocar(x)}});

// gavetas
const sh=h=>{$("sh").innerHTML="<div>"+h+"</div>";$("sh").classList.add("on")};$("sh").onclick=e=>{if(e.target.id==="sh")$("sh").classList.remove("on")};
const SEED=["Que fome! 😍","Já estive aí, recomendo","Qual o horário hoje?","Melhor da região","Vou passar aí amanhã"];
function coment(id){const h=hash(id),cs=[...[0,1,2].map(i=>["@"+["ana","joao","bia","leo"][(h+i)%4],SEED[(h+i)%5]]),...(S.com[id]||[]).map(t=>["@você",t])];
sh(`<b>${cs.length} comentários</b>`+cs.map(c=>`<div class="cm"><b>${c[0]}</b>${esc(c[1])}</div>`).join("")+`<input type="text" id="cI" maxlength="200" placeholder="Adicionar comentário..."><button class="btn" id="cB">Enviar</button>`);
$("cB").onclick=()=>{const v=$("cI").value.trim();if(!v)return;(S.com[id]=S.com[id]||[]).push(v);save();coment(id);refresh(posts().find(q=>q.id===id).n.id)}}
function catsHTML(){const cnt={};N.filter(vis).forEach(n=>{if(dist(POS,n)<=S.raio)cnt[n.categoria]=(cnt[n.categoria]||0)+1});
return `<button class="pill ${S.cat==="Todos"?"on":""}" data-c="Todos">Todos</button>`+GRP.map((g,i)=>{const cs=CATS.filter(c=>c[4]===i);if(!cs.length)return"";const tot=cs.reduce((x,c)=>x+(cnt[c[0]]||0),0);
return `<div class="gr"><div class="gh"><span>${g[1]} ${g[0]}</span><button class="pill ${S.cat==="@"+g[0]?"on":""} ${tot?"":"z"}" data-c="@${g[0]}" ${tot?"":"data-z"}>Tudo · ${tot}</button></div>${cs.map(c=>`<button class="pill ${S.cat===c[0]?"on":""} ${cnt[c[0]]?"":"z"}" data-c="${c[0]}" ${cnt[c[0]]?"":"data-z"}>${c[1]} ${c[0]} <small>${cnt[c[0]]||0}</small></button>`).join("")}</div>`}).join("")}
function filtro(){const lb=t=>`<b class="lbl s">${t}</b>`;
sh(`<b>Filtro</b>${WX?` <span class="wxc in-sheet">${WX}</span>`:""}${lb("Local")}<button class="pill" id="fLoc">${ic("pin",14)} ${S.place?esc(S.place.n):"Perto de você"} · alterar</button>${lb("Raio")}<div id="rP">${[1,2,5,10,25].map(r=>`<button class="pill ${r===S.raio?"on":""}" data-r="${r}">${r} km</button>`).join("")}</div>${lb("Categoria")}<div id="cP">${catsHTML()}</div><button class="btn" id="aB">Ver resultados</button>${filtroAtivo()?'<button class="btn w" id="fLimpa">Limpar filtros</button>':""}`);
const up=()=>{const t=S.tab;if(t==="map"||t==="seg")S.tab="perto";const n=lista().length;S.tab=t;$("aB").textContent="Ver "+n+" resultado(s)"},pick=(id,k,v)=>{S[k]=v;save();$(id).querySelectorAll("[data-r],[data-c]").forEach(x=>x.classList.toggle("on",x.dataset.r==v||x.dataset.c==v));up();feed()};
$("rP").onclick=e=>{const b=e.target.closest("[data-r]");if(b){pick("rP","raio",+b.dataset.r);$("cP").innerHTML=catsHTML()}};$("cP").onclick=e=>{const b=e.target.closest("[data-c]");if(!b)return;if("z" in b.dataset)return toast("Nenhum por aqui ainda");pick("cP","cat",b.dataset.c)};
$("fLoc").onclick=lugar;const fl=$("fLimpa");if(fl)fl.onclick=()=>{S.cat="Todos";S.raio=5;S.q="";S.only=null;const pl=!!S.place;save();if(pl){$("sh").classList.remove("on");voltaLocal();return}feed(true);filtro();toast("Filtros limpos")};up();
$("aB").onclick=()=>{$("sh").classList.remove("on");go("vFeed")}}


// explorar outro lugar: escolha o estado e a cidade e veja o que há lá antes de chegar
const UFS=UFS_N;
let plT,plU="",plL=[];
function irPara(p,dest){MP.init=0;MP.fq=null;MP.sel=null;S.place={n:String(p.n).slice(0,60),lat:p.lat,lng:p.lng};POS.lat=p.lat;POS.lng=p.lng;S.only=null;S.tab="perto";S.cat="Todos";S.q="";S.raio=Math.max(S.raio,5);save();$("sh").classList.remove("on");go(dest||"vFeed");toast("Buscando em "+S.place.n+"…");API.osm().then(n=>{feed(true);if(dest==="vExp"&&$("vExp").classList.contains("on"))explorar();if(!n)toast("Nenhum comércio encontrado aqui no mapa")})}
function voltaLocal(){MP.init=0;MP.sel=null;S.place=null;save();const h=API.home||RIO;POS.lat=h.lat;POS.lng=h.lng;toast("Voltando para perto de você…");feed(true);API.recarregar().then(()=>feed(true))}
function lugar(){plL=[];sh(`<b>Explorar um lugar</b><p class="note">Escolha o estado e digite a cidade para ver o que existe lá antes de chegar.</p>
<label class="lbl">Estado<select id="plU"><option value="">Todos os estados</option>${Object.entries(UFS).map(([k,v])=>`<option value="${k}" ${k===plU?"selected":""}>${v} (${k})</option>`).join("")}</select></label>
<label class="lbl">Cidade<input type="search" id="plC" placeholder="Ex.: Niterói, Salvador, Curitiba…" autocomplete="off" enterkeyhint="search"></label>
<div id="plR" role="listbox" aria-label="Cidades encontradas"></div>${S.place?'<button class="btn w" id="plH">📍 Voltar para minha localização</button>':""}`);
const run=async()=>{const q=$("plC").value.trim(),r=$("plR");plU=$("plU").value;if(q.length<2){r.innerHTML="";return}r.innerHTML='<p class="ld" role="status">Buscando cidades…</p>';
const l=await API.cidades(q,plU);if($("plC").value.trim()!==q)return;plL=l;r.innerHTML=l.length?l.map((x,k)=>`<div class="sg2" role="option" tabindex="0" data-k="${k}"><span class="hc">📍</span><span>${esc(x.n)}</span></div>`).join(""):'<p class="note">Nenhuma cidade encontrada. Confira o nome, troque o estado ou verifique sua conexão.</p>'};
$("plC").oninput=()=>{clearTimeout(plT);plT=setTimeout(run,400)};$("plU").onchange=run;
$("plC").onkeydown=e=>{if(e.key==="Enter"){clearTimeout(plT);run()}};
$("plR").onclick=e=>{const d=e.target.closest("[data-k]");if(d)irPara(plL[+d.dataset.k])};
$("plR").onkeydown=e=>{if(e.key==="Enter"||e.key===" "){const d=e.target.closest("[data-k]");if(d){e.preventDefault();irPara(plL[+d.dataset.k])}}};
const h=$("plH");if(h)h.onclick=()=>{$("sh").classList.remove("on");voltaLocal()};
setTimeout(()=>$("plC").focus(),80)}

// busca estilo TikTok: histórico, "você pode gostar", populares perto
const HK="pertinho-h",hist=()=>{try{const l=JSON.parse(localStorage.getItem(HK)||"[]");return Array.isArray(l)?l.filter(isS):[]}catch(e){return[]}},setH=l=>{try{localStorage.setItem(HK,JSON.stringify(l.slice(0,20)))}catch(e){}};
let bsAll=false,bsOff=0,bsL=[],bsT;
$("vBus").innerHTML=`<div class="bh"><button class="bk" id="bsB" aria-label="Voltar">${ic("back",24)}</button><label class="bi">${ic("search",20)}<input id="qI" type="search" placeholder="Buscar no Pertinho" autocomplete="off" enterkeyhint="search"><button class="bx" id="bsX" aria-label="Limpar" hidden>×</button></label><button class="bgo" id="bsGo">Procurar</button></div><div class="bc" id="bsC"></div>`;
let bsPrev="vFeed";
function buscaOpen(){const c=document.querySelector(".v.on");if(c&&c.id!=="vBus")bsPrev=c.id;go("vBus");$("qI").value=(bsPrev==="vExp"?XQ:S.q)||"";bsAll=false;bsDraw();setTimeout(()=>$("qI").focus(),60)}
function bsRun(q,dest){q=(q||"").trim();dest=dest||(bsPrev==="vExp"?"vExp":"vFeed");if(q)setH([q,...hist().filter(x=>x!==q)]);$("qI").blur();
if(dest==="vExp"){XQ=q;go("vExp");toast(q?"Mostrando “"+q+"” no mapa":"Busca limpa");return}
S.q=q;S.only=null;save();go("vFeed");toast(q?"Buscando “"+q+"”":"Busca limpa")}
function sugs(){const A=affin(),H=new Set(hist().map(norm)),c=[];N.filter(n=>n.id[0]!=="o"&&vis(n)).forEach(n=>n.cardapio.slice(0,2).forEach(i=>c.push([i[0],(A[n.categoria]||0)+1])));CATS.forEach(k=>c.push([k[0],(A[k[0]]||0)+.5]));
const u=[...new Map(c.filter(x=>!H.has(norm(x[0]))).sort((x,y)=>y[1]-x[1]||(x[0]>y[0]?1:-1)).map(x=>[x[0],x[0]])).values()],pg=Math.max(1,Math.ceil(u.length/4)),k=bsOff%pg;return u.slice(k*4,k*4+4)}
async function bsDraw(){const q=$("qI").value.trim(),nq=norm(q),g=$("bsC");$("bsX").hidden=!q;
if(!q){const h=hist(),hs=bsAll?h:h.slice(0,6),pop=N.filter(n=>n.id[0]!=="o"&&n.cardapio.length&&vis(n)).map(n=>({n,d:dist(POS,n)})).sort((a,b)=>a.d-b.d).slice(0,6);
g.innerHTML=hs.map(x=>`<div class="hr3" data-q="${esc(x)}"><span class="hc">${ic("clock",14)}</span><span class="ht">${esc(x)}</span><button class="hx" data-rm="${esc(x)}" aria-label="Remover do histórico">×</button></div>`).join("")+(h.length>6&&!bsAll?'<button class="mais" data-more>Ver mais ⌄</button>':"")
+`<div class="sg2 plc" data-pl><span class="hc">📍</span><span><b>Explorar outra cidade ou estado</b></span></div>`+`<div class="sec"><b>Você pode gostar</b><button class="at" data-ref>↻ Atualizar</button></div>`+sugs().map((t,i)=>`<div class="sg2" data-q="${esc(t)}"><i class="${i<2?"hot":""}"></i><span class="${i<2?"hot":""}">${esc(t)}</span></div>`).join("")
+`<div class="sec"><b>Populares perto de você</b></div>`+pop.map((x,i)=>`<div class="pp2 ${i<3?"hl":""}" data-q="${esc(x.n.cardapio[0][0])}"><i class="${i<3?"hot":""}"></i><div><span>${esc(x.n.cardapio[0][0])}</span><small>Populares localmente · ${esc(x.n.nome)} · ${fk(x.d)}</small></div></div>`).join("");return}
const loc=N.filter(n=>vis(n)&&bate([n.nome,n.categoria,n.descricao,...n.cardapio.map(c=>c[0])].join(" "),nq)).slice(0,6).map(n=>`<div class="sg2" data-n="${esc(n.id)}"><span class="hc">${cat(n.categoria)[1]}</span><span>${esc(n.nome)}</span><small>${fk(dist(POS,n))}</small></div>`).join("");
const top=`<div class="sg2" data-q="${esc(q)}"><span class="hc">${ic("search",14)}</span><span>Buscar por “<b>${esc(q)}</b>”</span></div>`;g.innerHTML=top+loc;
if(q.length<3)return;bsL=await API.lugares(q);if($("qI").value.trim()!==q)return;g.innerHTML=top+loc+bsL.map((l,k)=>`<div class="sg2" data-l="${k}"><span class="hc">📍</span><span>${esc(l.n.slice(0,60))}</span></div>`).join("")}
$("qI").oninput=()=>{clearTimeout(bsT);bsT=setTimeout(bsDraw,250)};$("qI").onkeydown=e=>{if(e.key==="Enter")bsRun($("qI").value)};
$("bsB").onclick=()=>{$("qI").blur();go(bsPrev||"vFeed")};$("bsGo").onclick=()=>bsRun($("qI").value);$("bsX").onclick=()=>{$("qI").value="";bsDraw();$("qI").focus()};
$("bsC").onclick=e=>{const d=e.target.closest("[data-rm],[data-q],[data-n],[data-l],[data-more],[data-ref]");if(!d)return;const o=d.dataset;
if("pl" in o)return lugar();if("rm" in o){setH(hist().filter(x=>x!==o.rm));bsDraw();return}if("more" in o){bsAll=true;bsDraw();return}if("ref" in o){bsOff++;bsDraw();return}
if("q" in o)return bsRun(o.q);if("n" in o)return abre(o.n);
const l=bsL[+o.l];if(l)irPara({n:l.n.split(",").slice(0,2).join(",").trim(),lat:l.lat,lng:l.lng},bsPrev==="vExp"?"vExp":undefined)};

// mapa (OpenStreetMap): pins por categoria, arrastar, zoom, cartão da loja
const MP={z:15,x:0,y:0,sel:null,t:{},raf:0,init:0,fq:""};
const wp=(la,lo,z)=>{const n=256*2**z,s=Math.sin(rad(la));return[(lo+180)/360*n,(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*n]};
function mapOpen(){const m=$("map");if(!m.dataset.b){m.dataset.b=1;m.innerHTML=`<div id="mt"></div><div id="mpn"></div><div class="mz"><button id="mzi" aria-label="Aproximar">+</button><button id="mzo" aria-label="Afastar">−</button><button id="mzl" aria-label="Minha posição">${ic("pin",20)}</button></div><a class="mat" href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© OpenStreetMap</a><div id="mc"></div>`;mapBind()}
if(!MP.init){MP.init=1;[MP.x,MP.y]=wp(POS.lat,POS.lng,MP.z)}mapDraw()}
const mapRaf=()=>{if(!MP.raf)MP.raf=requestAnimationFrame(()=>{MP.raf=0;mapDraw()})};
function mapDraw(){const m=$("map"),w=m.clientWidth,h=m.clientHeight,z=MP.z,T=256,x0=MP.x-w/2,y0=MP.y-h/2,n=2**z,mt=$("mt"),need=new Set();
for(let tx=Math.floor(x0/T);tx<=Math.floor((x0+w)/T);tx++)for(let ty=Math.floor(y0/T);ty<=Math.floor((y0+h)/T);ty++){if(ty<0||ty>=n)continue;const X=((tx%n)+n)%n,k=z+"/"+tx+"/"+ty;need.add(k);let e=MP.t[k];if(!e){e=MP.t[k]=new Image();e.className="tl";e.alt="";e.draggable=false;e.onerror=()=>{e.style.visibility="hidden"};e.src=`https://tile.openstreetmap.org/${z}/${X}/${ty}.png`;mt.appendChild(e)}e.style.transform=`translate(${Math.round(tx*T-x0)}px,${Math.round(ty*T-y0)}px)`}
for(const k in MP.t)if(!need.has(k)){MP.t[k].remove();delete MP.t[k]}
const q=norm($("vExp").classList.contains("on")?XQ:S.q),pins=N.filter(n=>vis(n)&&catOk(n)&&(!q||bate([n.nome,n.categoria,n.descricao,...n.cardapio.map(i=>i[0])].join(" "),q))).map(n=>{const[px,py]=wp(n.lat,n.lng,z);return{n,x:px-x0,y:py-y0}}).filter(p=>p.x>-50&&p.x<w+50&&p.y>-50&&p.y<h+50);
const[mx,my]=wp(POS.lat,POS.lng,z);
$("mpn").innerHTML=`<span class="me" style="transform:translate(${mx-x0}px,${my-y0}px)"></span>`+pins.map(p=>{const c=cat(p.n.categoria);return`<button class="pin${MP.sel===p.n.id?" on":""}" data-id="${esc(p.n.id)}" style="transform:translate(${p.x}px,${p.y}px)" aria-label="${esc(p.n.nome)}"><i style="background:linear-gradient(135deg,${c[2]},${c[3]})">${c[1]}</i></button>`}).join("")}
function mapSel(id){MP.sel=id;const n=id&&N.find(x=>x.id===id),c=$("mc");if(!n){c.innerHTML="";mapRaf();return}const k=cat(n.categoria);
c.innerHTML=`<div class="mcc"><b>${k[1]} ${esc(n.nome)}</b><span>${n.categoria} · ${fk(dist(POS,n))} ${n.faixa?" · "+n.faixa:""}</span><div class="mbt"><button class="pill on" id="mcP">Ver perfil</button><button class="pill" id="mcV">Ver vídeos</button><a class="pill" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${n.lat},${n.lng}">Como chegar</a></div></div>`;
$("mcP").onclick=()=>abre(n.id);$("mcV").onclick=()=>{S.only=n.id;S.tab="perto";save();go("vFeed");feed(true)};mapRaf()}
// enquadra todas as lojas da lista no mapa (zoom máximo 16)
function mapFit(l){const m=$("map"),w=m.clientWidth||340,h=m.clientHeight||260,P=z=>l.map(n=>wp(n.lat,n.lng,z)),B=p=>{const x=p.map(a=>a[0]),y=p.map(a=>a[1]);return[Math.min(...x),Math.max(...x),Math.min(...y),Math.max(...y)]};let z=16;
for(;z>11;z--){const b=B(P(z));if(b[1]-b[0]<=w-90&&b[3]-b[2]<=h-130)break}const b=B(P(z));MP.z=z;MP.x=(b[0]+b[1])/2;MP.y=(b[2]+b[3])/2;mapRaf()}
function mapZoom(d){const z=Math.max(11,Math.min(18,MP.z+d));if(z===MP.z)return;const f=2**(z-MP.z);MP.x*=f;MP.y*=f;MP.z=z;mapRaf()}
function mapBind(){const m=$("map");let dr=null;
m.addEventListener("pointerdown",e=>{if(e.target.closest(".mz,#mc,.mat"))return;dr={x:e.clientX,y:e.clientY,mx:MP.x,my:MP.y,mv:0,pin:e.target.closest(".pin")};try{m.setPointerCapture(e.pointerId)}catch(_){}});
m.addEventListener("pointermove",e=>{if(!dr)return;const dx=e.clientX-dr.x,dy=e.clientY-dr.y;if(Math.abs(dx)+Math.abs(dy)>6)dr.mv=1;if(!dr.mv)return;MP.x=dr.mx-dx;MP.y=dr.my-dy;mapRaf()});
m.addEventListener("pointerup",()=>{if(dr&&!dr.mv)mapSel(dr.pin?dr.pin.dataset.id:null);dr=null});m.addEventListener("pointercancel",()=>{dr=null});m.addEventListener("click",e=>{const p=e.detail===0&&e.target.closest(".pin");if(p)mapSel(p.dataset.id)});
m.addEventListener("wheel",e=>{e.preventDefault();mapZoom(e.deltaY<0?1:-1)},{passive:false});m.addEventListener("dblclick",()=>mapZoom(1));
$("mzi").onclick=()=>mapZoom(1);$("mzo").onclick=()=>mapZoom(-1);$("mzl").onclick=()=>{MP.z=15;[MP.x,MP.y]=wp(POS.lat,POS.lng,15);mapRaf()}}

// tela Explorar (botão central): mapa com as lojas, busca e recomendadas na região
// lojas que combinam com a busca do Explorar (respeita a categoria do Filtro), da mais perto para a mais longe
const xRes=q=>N.filter(n=>vis(n)&&catOk(n)&&(!q||bate([n.nome,n.categoria,n.descricao,...n.cardapio.map(i=>i[0])].join(" "),q))).map(n=>({n,d:dist(POS,n)})).sort((a,b)=>a.d-b.d);
// raio do feed que cobre os resultados (5, 10 ou 25 km) e quantos vídeos aparecem com ele
const xRaio=l=>{const m=l.length?l[l.length-1].d:0;return Math.max(S.raio,[5,10,25].find(r=>r>=m)||25)};
function xFeedN(l){const o=[S.q,S.only,S.tab,S.raio];S.q=XQ;S.only=null;S.tab="perto";S.raio=xRaio(l);const n=lista().length;[S.q,S.only,S.tab,S.raio]=o;return n}
function explorar(){const v=$("vExp"),m=$("map");if(v.contains(m))$("vFeed").appendChild(m);
const nome=eu().split(" ")[0],h=hist().slice(0,3),res=xRes(XQ),rec=XQ?res.slice(0,20):res.slice(0,10),nf=XQ&&res.length?xFeedN(res):0;
v.innerHTML=`<div class="xh"><button class="xav" id="xAv" aria-label="Meu perfil">${ic("user",26)}</button><h2>Olá, ${esc(nome)}!</h2><button class="xpl" id="xPl" aria-label="Escolher cidade e estado">${ic("pin",14)} <span>${S.place?esc(S.place.n):"Perto de você"}</span> ▾</button></div>
<div class="xmap" id="xMap"></div>
<div class="xs"><div class="xqw"><button class="xq" id="xQ">${ic("search",24)}<span>${XQ?esc(XQ):"O que você procura?"}</span></button>${XQ?'<button class="xx" id="xClr" aria-label="Limpar busca">×</button>':""}</div>${nf?`<button class="btn xf" id="xFeed">Buscar feeds · ${nf} vídeo${nf===1?"":"s"}</button>`:""}${h.map(q=>`<button class="xr" data-q="${esc(q)}"><span class="hc">${ic("clock",14)}</span><span>${esc(q)}</span></button>`).join("")}<button class="xr xc2" id="xCid"><span class="hc">${ic("pin",14)}</span><span>Ver outra cidade ou estado</span></button></div>
<div class="xt"><b>${XQ?"Resultados · "+res.length:"Lojas recomendadas na região"}</b><button id="xMais">Filtro ›</button></div>
<div class="xc">${rec.length?rec.map(({n,d})=>{const c=cat(n.categoria);return`<button class="xk" data-n="${esc(n.id)}" style="background:linear-gradient(135deg,${c[2]},${c[3]})"><span class="xe">${c[1]}</span><b>${esc(n.nome)}</b><small>${n.categoria} · ${fk(d)}</small></button>`}).join(""):'<p class="xz">${XQ?"Nenhuma loja encontrada para “"+esc(XQ)+"”.":"Nenhuma loja encontrada por aqui ainda."}</p>'}</div>`;
$("xMap").appendChild(m);m.hidden=false;mapOpen();
if(MP.fq!==XQ&&(res.length||!XQ)){MP.fq=XQ;MP.sel=null;if(XQ)mapFit(res.map(r=>r.n));else{MP.z=15;[MP.x,MP.y]=wp(POS.lat,POS.lng,15);mapRaf()}}
$("xAv").onclick=()=>go("vPer");$("xPl").onclick=$("xCid").onclick=lugar;$("xQ").onclick=buscaOpen;$("xMais").onclick=filtro;
v.querySelectorAll(".xr[data-q]").forEach(x=>x.onclick=()=>bsRun(x.dataset.q,"vExp"));
const xc=$("xClr");if(xc)xc.onclick=()=>{XQ="";explorar()};
const xf=$("xFeed");if(xf)xf.onclick=()=>{S.q=XQ;S.only=null;S.tab="perto";S.raio=xRaio(res);save();go("vFeed");toast("Feeds de “"+S.q+"”")};v.querySelectorAll(".xk").forEach(x=>x.onclick=()=>abre(x.dataset.n))}

function som(){SOM=!SOM;document.querySelectorAll(".rail [data-act=snd]").forEach(b=>b.innerHTML=ic(SOM?"volume":"mute",26));tocar(document.querySelector(".p.act"));toast(SOM?"Som ligado":"Som desligado")}
$("bBusca").onclick=buscaOpen;$("nDesc").onclick=filtro;

// redes sociais do comércio (n.redes = {ig,tt,wa}); aceita @usuario, link ou número
const SOC={ig:["Instagram",'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r=".6" fill="currentColor"/></svg>'],
tt:["TikTok",'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3v11.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 3c.3 2.6 2 4.3 5 4.5"/></svg>'],
wa:["WhatsApp",'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.3z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/></svg>']};
function socUrl(k,v){v=String(v||"").trim();if(!v)return"";if(k==="wa"){const d=v.replace(/\D/g,"");return d.length>=10?"https://wa.me/"+(d.length<=11?"55"+d:d):""}
const u=v.replace(/^https?:\/\/(www\.)?(instagram|tiktok)\.com\/?/i,"").replace(/^@/,"").split(/[/?#]/)[0].replace(/[^\w.]/g,"");if(!u)return"";return k==="ig"?"https://www.instagram.com/"+u:"https://www.tiktok.com/@"+u}
const redes=n=>{const r=n.redes||(n.id[0]==="d"?{ig:handle(n),tt:handle(n)}:{});return["ig","tt","wa"].map(k=>[k,socUrl(k,r[k])])};
// página do comércio
let pvIO=null,pvCtx=null;
function pvClose(){const had=!!$("pv");aud.pause();pvIO&&pvIO.disconnect();pvIO=null;const e=$("pv");e&&e.remove();if(had&&$("vPer").classList.contains("on"))perfil()}
function pvOpen(ps,i,ctx){pvClose();pvCtx=ctx||null;const v=document.createElement("div");v.id="pv";v.innerHTML=`<button class="back" id="pvX" aria-label="Fechar vídeo">${ic("back",16)} Voltar</button><div id="pf"></div>`;$("vs").appendChild(v);
const pf=$("pf");pf.innerHTML=ps.map(postHTML).join("");pf.addEventListener("click",pclick);$("pvX").onclick=pvClose;pvIO=mount(pf,null);pf.scrollTop=i*pf.clientHeight}
let aba="Cardápio",cur=null;
function abre(id){cur=N.find(n=>n.id===id);aba="Vídeos";const c=document.querySelector(".v.on");if(c&&c.id!=="vNeg")negPrev=c.id;neg();go("vNeg")}
function neg(){const n=cur,c=cat(n.categoria),st=$("vNeg").scrollTop;
$("vNeg").innerHTML=`<div class="hd" style="background:linear-gradient(160deg,${c[2]},${c[3]})"><div class="hrow"><button class="back" data-go="${negPrev}">${ic("back",16)} Voltar</button><button class="back${S.seg[n.id]?"":" cta"}" id="bS" aria-pressed="${!!S.seg[n.id]}">${S.seg[n.id]?"✓ Seguindo":"+ Seguir"}</button></div><h1>${c[1]} ${esc(n.nome)}</h1><div><b>${n.categoria}</b> · ${fk(dist(POS,n))}${n.faixa?" · "+n.faixa:""}</div><div class="hr2" id="hr2">${rt(n).c?`${ic("star",12,"fill st")}<b>${fa(rt(n).a)}</b><span>· ${rt(n).c} avaliações</span>`:"<span>Novo · sem avaliações</span>"}</div><div class="sub">${esc(n.descricao)}</div><div class="soc">${redes(n).map(([k,u])=>u?`<a class="sb ${k}" href="${u}" target="_blank" rel="noopener noreferrer" aria-label="${SOC[k][0]}">${SOC[k][1]}<span>${SOC[k][0]}</span></a>`:`<button class="sb off" data-soc="${k}" aria-label="${SOC[k][0]} não informado">${SOC[k][1]}<span>${SOC[k][0]}</span></button>`).join("")}</div></div>
<div class="tabs">${["Vídeos","Cardápio","Fotos","Avaliações","Local"].map(a=>`<button class="${a===aba?"on":""}" data-a="${a}">${a==="Cardápio"?LB(n):a}</button>`).join("")}</div><div class="body" id="nb"></div>`;$("vNeg").scrollTop=st;
$("vNeg").querySelectorAll("[data-soc]").forEach(x=>x.onclick=()=>toast(SOC[x.dataset.soc][0]+" não informado por este comércio"));$("hr2").onclick=()=>{aba="Avaliações";neg()};$("bS").onclick=()=>{tog(S.seg,n.id);S.seg[n.id]&&notify("sys","Você começou a seguir "+n.nome,n.id);save();neg()};
$("vNeg").querySelector(".tabs").onclick=e=>{if(e.target.dataset.a){aba=e.target.dataset.a;neg()}};const b=$("nb");
if(aba==="Vídeos"){b.innerHTML=`<div class="vg">${[0,1].map(i=>{const k=i+1,id=n.id+"-"+i;return`<div class="vt" data-v="${id}" style="background:linear-gradient(135deg,${c[2]},${c[3]})"><span class="em">${c[1]}</span>${i===0&&VURL[n.id]?`<video src="${VURL[n.id]}#t=0.1" preload="metadata" muted playsinline></video>`:`<img src="${rm("img",n.categoria,k)||mu("img",n.categoria,k,"jpg")}" data-alt="${mu("img",n.categoria,k,"jpg")}" alt="" loading="lazy">`}<em>${ic("play",12,"fill")} ${fmt(baseL(id)*7)}</em></div>`}).join("")}</div><p class="note">Toque em um vídeo para assistir.</p>`;
b.querySelectorAll("[data-v]").forEach(x=>x.onclick=()=>pvOpen(posts().filter(p=>p.n.id===n.id).map(p=>({...p,d:dist(POS,n)})),+x.dataset.v.slice(-1),n.id))}
if(aba==="Avaliações"){const r=rt(n),rv=S.rev[n.id]||[],my=S.rate[n.id]||0,dd=[5,4,3,2,1].map(i=>Math.max(.05,1-Math.abs(i-r.a)/2)),sm=dd.reduce((x,y)=>x+y,0);
b.innerHTML=`<div class="rv"><div class="big2"><b>${r.c?fa(r.a):"–"}</b><div>${stars(r.a,18)}</div><small>${r.c?r.c+" avaliações":"Seja o primeiro a avaliar"}</small></div><div class="bars">${r.c?dd.map((w,k)=>`<div><span>${5-k}</span><i><u style="width:${w/sm*100|0}%"></u></i></div>`).join(""):""}</div></div><b>Sua avaliação</b><div class="mine">${[1,2,3,4,5].map(i=>`<button data-s="${i}" aria-label="${i} estrelas">${ic("star",34,my>=i?"fill st":"st")}</button>`).join("")}</div><textarea id="rT" rows="2" maxlength="200" placeholder="Conte como foi (opcional)"></textarea><button class="btn" id="rB">Publicar comentário</button>${rv.map(x=>`<div class="cm"><b>@você · ${stars(x.s,11)}</b>${esc(x.t)}</div>`).join("")}`;
b.querySelectorAll("[data-s]").forEach(x=>x.onclick=()=>{S.rate[n.id]=+x.dataset.s;save();toast("Obrigado pela avaliação!","ok");neg()});
$("rB").onclick=()=>{const t=$("rT").value.trim();if(!S.rate[n.id])return toast("Toque nas estrelas primeiro","err");if(!t)return toast("Escreva um comentário","err");(S.rev[n.id]=S.rev[n.id]||[]).unshift({s:S.rate[n.id],t});save();neg()}}
if(aba==="Cardápio")b.innerHTML=n.cardapio.length?n.cardapio.map(i=>`<div class="item"><span>${esc(i[0])}</span>${price(n,i)?`<b>${price(n,i)}</b>`:""}</div>`).join("")+(gi(n)===2?'<p class="note">Valores sob consulta, conforme as regras de publicidade da área da saúde.</p>':""):"<p>Sem "+LB(n).toLowerCase()+".</p>";
if(aba==="Fotos"){const lk=(id,L)=>ic("heart",26,L?"fill liked":"")+`<small>${fmt(baseL(id)+(L?1:0))}</small>`;
b.innerHTML=[1,2].map(i=>{const id=n.id+"-f"+i,it=n.cardapio[i-1],cp=it?(price(n,it)?`${it[0]} · ${price(n,it)}`:it[0]):(i===1?n.descricao:"Ambiente do "+n.nome);
return `<figure class="fp"><div class="ph" data-f="${id}" style="background:linear-gradient(135deg,${c[2]},${c[3]})">${n.fotos[i-1]||c[1]}<img src="${rm("img",n.categoria,i)||mu("img",n.categoria,i,"jpg")}" data-alt="${mu("img",n.categoria,i,"jpg")}" alt="${esc(cp)}" loading="lazy"></div><figcaption><span>${esc(cp)}</span><button class="lk" data-f="${id}" aria-label="Curtir foto" aria-pressed="${!!S.likes[id]}">${lk(id,!!S.likes[id])}</button></figcaption></figure>`}).join("");
const flip=id=>{tog(S.likes,id);save();const x=b.querySelector("button[data-f=\""+id+"\"]");x.innerHTML=lk(id,!!S.likes[id]);x.setAttribute("aria-pressed",!!S.likes[id])};
b.querySelectorAll("button[data-f]").forEach(x=>x.onclick=()=>flip(x.dataset.f));
b.querySelectorAll(".ph").forEach(x=>x.ondblclick=()=>{if(!S.likes[x.dataset.f])flip(x.dataset.f)})}
if(aba==="Local")b.innerHTML=`<div class="row">${ic("pin",18)}${esc(n.endereco)}</div><div class="row">${ic("clock",18)}${esc(n.horario||"Horário não informado")}</div><a class="btn" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${n.lat},${n.lng}">Abrir no Maps</a>`}

// perfil
// notificações (guardadas no aparelho; trocar por push/API quando houver backend)
const ago=t=>{const m=Math.max(0,(Date.now()-t)/6e4);return m<1?"agora":m<60?"há "+(m|0)+" min":m<1440?"há "+(m/60|0)+" h":"há "+(m/1440|0)+" d"};
const unread=()=>S.nt.filter(x=>!x.r).length;
function badge(){const u=unread(),b=document.querySelector("nav [data-go=vNot]");if(!b)return;let d=b.querySelector(".nd");if(u){if(!d){d=document.createElement("span");d.className="nd";b.appendChild(d)}d.textContent=u>9?"9+":u}else if(d)d.remove()}
function notify(k,t,n,ts){if((k==="vid"&&S.ns.vid===false)||(k==="promo"&&S.ns.promo===false))return;S.nt.unshift({i:Date.now()+Math.random().toString(36).slice(2,6),k,t,n:n||"",ts:ts||Date.now(),r:0});S.nt=S.nt.slice(0,40);save();badge()}
function demoNot(){const d=new Date().toISOString().slice(0,10);
if(!S.nw){S.nw=1;notify("sys","Bem-vindo ao Pertinho! Curta, salve e siga comércios perto de você.")}
N.filter(n=>S.seg[n.id]&&S.nd["v"+n.id]!==d).forEach(n=>{S.nd["v"+n.id]=d;notify("vid",n.nome+" postou um novo vídeo",n.id,Date.now()-(hash(n.id+d)%180+5)*6e4)});
if(S.nd.p!==d){const c=N.filter(n=>vis(n)&&!S.seg[n.id]&&n.cardapio.length&&n.id[0]!=="o").map(n=>({n,d:dist(POS,n)})).sort((a,b)=>a.d-b.d)[0];if(c){S.nd.p=d;notify("promo",`Perto de você (${fk(c.d)}): ${c.n.nome} — ${c.n.cardapio[0][0]}${price(c.n,c.n.cardapio[0])?" por "+price(c.n,c.n.cardapio[0]):""}`,c.n.id)}}
save();badge()}
function avisos(){const l=[...S.nt].sort((a,b)=>b.ts-a.ts),I={vid:"play",promo:"pin",sys:"check"};
$("vNot").innerHTML=`<div class="vh"><h2>Avisos</h2>${l.length?'<button class="pill" id="nClr">Limpar</button>':""}</div><div class="body">`+(l.length?l.map(x=>`<div class="nt ${x.r?"":"un"}" data-n="${esc(x.n)}">${ic(I[x.k]||"check",20)}<div><span>${esc(x.t)}</span><small>${ago(x.ts)}</small></div></div>`).join(""):vazio("Nenhum aviso ainda","Siga comércios para saber quando postarem.")+"")+`<div class="ns"><b>Receber avisos de</b><label class="tg"><input type="checkbox" id="nsV" ${S.ns.vid!==false?"checked":""}> Novos vídeos de quem eu sigo</label><label class="tg"><input type="checkbox" id="nsP" ${S.ns.promo!==false?"checked":""}> Ofertas perto de mim</label></div></div>`;
S.nt.forEach(x=>x.r=1);save();badge();
const c=$("nClr");if(c)c.onclick=()=>{S.nt=[];save();avisos()};
$("nsV").onchange=e=>{S.ns.vid=e.target.checked;save()};$("nsP").onchange=e=>{S.ns.promo=e.target.checked;save()};
$("vNot").querySelectorAll(".nt").forEach(x=>x.onclick=()=>{const n=N.find(q=>q.id===x.dataset.n);if(n)abre(n.id)})}
// perfil: curtidos, salvos, seguindo e meus comércios
const pid=id=>id.slice(0,id.lastIndexOf("-")),isF=id=>/-f\d$/.test(id);
const tile=(n,k,extra,at)=>{const c=cat(n.categoria);return `<div class="vt" ${at} style="background:linear-gradient(135deg,${c[2]},${c[3]})"><span class="em">${c[1]}</span><img src="${rm("img",n.categoria,k)||mu("img",n.categoria,k,"jpg")}" data-alt="${mu("img",n.categoria,k,"jpg")}" alt="" loading="lazy"><em>${extra}</em></div>`};
const vazio=(t,d)=>`<div class="vz"><b>${t}</b><p>${d}</p></div>`;
let armed=null;const arm=(el,txt,fn)=>{el.onclick=()=>{if(armed===el){armed=null;fn();return}armed=el;const o=el.textContent;el.textContent=txt;setTimeout(()=>{if(armed===el){armed=null;el.textContent=o}},3000)}};
const eu=()=>S.user?S.user.nome:(S.me&&S.me.nome)||"Visitante",hd=()=>"@"+(norm(eu()).replace(/\W+/g,"").slice(0,20)||"visitante");
function editar(){sh(`<b>Editar perfil</b><input type="text" id="eN" maxlength="30" placeholder="Seu nome" value="${esc(S.user?S.user.nome:(S.me&&S.me.nome)||"")}"><button class="btn" id="eS">Salvar</button>`);$("eS").onclick=()=>{const v=$("eN").value.trim();if(S.user)S.user.nome=v||S.user.nome;else S.me={nome:v};save();$("sh").classList.remove("on");perfil();toast("Perfil atualizado","ok")}}
function menu(){sh(`<b>Configurações</b>${S.user?`<button class="btn w" id="bO">Sair</button>`:`<button class="btn w" id="bG"><b style="color:#4285f4">G</b> Entrar com Google (demonstração)</button>`}<button class="btn w" id="bR">Apagar dados deste aparelho</button>`);
const g=$("bG");if(g)g.onclick=()=>API.google(u=>{S.user=u;save();$("sh").classList.remove("on");perfil();toast("Login feito","ok")});
const o=$("bO");if(o)o.onclick=()=>{S.user=null;save();$("sh").classList.remove("on");perfil()};
arm($("bR"),"Toque de novo para confirmar",async()=>{try{localStorage.clear();sessionStorage.clear()}catch(e){}await DB.wipe();try{if(window.caches)for(const k of await caches.keys())await caches.delete(k)}catch(e){}location.reload()})}
function perfil(){const st=$("vPer").scrollTop,tb=S.ptab||"lk",by=Object.fromEntries(posts(1).map(p=>[p.id,p])),D=p=>({...p,d:dist(POS,p.n)});
const ids=Object.keys(S.likes).filter(k=>S.likes[k]),lkP=ids.filter(k=>by[k]).map(k=>D(by[k])),lkF=ids.filter(k=>isF(k)&&N.some(n=>n.id===pid(k))),
sv=posts(1).filter(p=>S.save[p.id]).map(D),sg=N.filter(n=>S.seg[n.id]),me=N.filter(n=>/^u\d/.test(n.id));
if(tb==="me"&&!me.length)S.ptab="lk";const T=S.ptab,nl=lkP.length+lkF.length;
const TB=[["lk","heart","Curtidos"],["sv","bookmark","Salvos"],["sg","users","Seguindo"],...(me.length?[["me","store","Meus comércios"]]:[])];
$("vPer").innerHTML=`<div class="pt"><button id="bEd" aria-label="Editar perfil">${ic("pencil",22)}</button><span></span><button id="bShP" aria-label="Compartilhar perfil">${ic("share",22)}</button><button id="bMn" aria-label="Configurações">${ic("menu",24)}</button></div>
<div class="pb2"><div class="pn"><h2>${esc(eu())}</h2><p>${hd()}</p></div><div class="pav">${ic("user",46)}<button id="bAv" aria-label="Editar foto e nome">${ic("plus",16)}</button></div></div>
<div class="st2"><button data-pt="sg"><b>${sg.length}</b><span>Seguindo</span></button><button data-pt="lk"><b>${nl}</b><span>Curtidas</span></button><button data-pt="sv"><b>${sv.length}</b><span>Salvos</span></button></div>
<div class="pp"><button class="pill" id="bEd2">Editar perfil</button><button class="pill" id="bPost">+ Postar comércio</button></div>
<div class="tabs ptabs it">${TB.map(t=>`<button class="${t[0]===T?"on":""}" data-pt="${t[0]}" aria-label="${t[2]}">${ic(t[1],22)}</button>`).join("")}</div><div class="body" id="pb"></div>`;
const b=$("pb"),vw=id=>ic("play",12,"fill")+" "+fmt(baseL(id)*7);
if(T==="lk")b.innerHTML=nl?`<div class="vg pg">${lkP.map((p,i)=>tile(p.n,+p.id.slice(-1)+1,vw(p.id),`data-pv="${i}"`)).join("")}${lkF.map(id=>{const n=N.find(q=>q.id===pid(id));return tile(n,+id.slice(-1),"📷 Foto",`data-ph="${esc(n.id)}"`)}).join("")}</div>`:vazio("Nada curtido ainda","Toque no ❤ nos vídeos e nas fotos para guardar aqui.");
if(T==="sv")b.innerHTML=sv.length?`<div class="vg pg">${sv.map((p,i)=>tile(p.n,+p.id.slice(-1)+1,vw(p.id),`data-pv="${i}"`)).join("")}</div>`:vazio("Nada salvo ainda","Toque no marcador de um vídeo para ver depois.");
if(T==="sg")b.innerHTML=sg.length?sg.map(n=>`<div class="item"><span class="rw" data-n="${esc(n.id)}">${cat(n.categoria)[1]} <b>${esc(n.nome)}</b><small>${n.categoria} · ${fk(dist(POS,n))}</small></span><button class="pill on" data-u="${esc(n.id)}">Seguindo</button></div>`).join(""):vazio("Você não segue ninguém","Toque no + do avatar de um comércio no feed.");
if(T==="me")b.innerHTML=me.map(n=>`<div class="item"><span class="rw" data-n="${esc(n.id)}">${cat(n.categoria)[1]} <b>${esc(n.nome)}</b><small>${n.categoria} · publicado por você</small></span><button class="pill" data-d="${esc(n.id)}">Excluir</button></div>`).join("");
$("bEd").onclick=$("bEd2").onclick=$("bAv").onclick=editar;$("bMn").onclick=menu;$("bPost").onclick=()=>go("vAdd");
$("bShP").onclick=()=>{if(navigator.share)navigator.share({title:"Pertinho",text:eu()+" no Pertinho"}).catch(()=>{});else{copiar(location.href)}};
$("vPer").onclick=e=>{const t=e.target.closest("[data-pt]");if(t){S.ptab=t.dataset.pt;save();perfil()}};
b.querySelectorAll("[data-pv]").forEach(x=>x.onclick=()=>pvOpen(T==="lk"?lkP:sv,+x.dataset.pv));
b.querySelectorAll("[data-ph]").forEach(x=>x.onclick=()=>{cur=N.find(n=>n.id===x.dataset.ph);aba="Fotos";negPrev="vPer";neg();go("vNeg")});
b.querySelectorAll(".rw").forEach(x=>x.onclick=()=>abre(x.dataset.n));
b.querySelectorAll("[data-u]").forEach(x=>x.onclick=()=>{S.seg[x.dataset.u]=false;save();perfil();toast("Deixou de seguir")});
b.querySelectorAll("[data-d]").forEach(x=>arm(x,"Confirmar?",()=>{const id=x.dataset.d;N=N.filter(n=>n.id!==id);if(VURL[id])URL.revokeObjectURL(VURL[id]);delete VURL[id];DB.del(id).catch(()=>{});limpaRastro(id);save();feed(true);perfil();toast("Comércio excluído")}));
$("vPer").scrollTop=st}

// cadastro
$("fCat").innerHTML=GRP.map((g,i)=>`<optgroup label="${g[0]}">${CATS.filter(c=>c[4]===i).map(c=>`<option>${c[0]}</option>`).join("")}</optgroup>`).join("");
function fLbl(){const g=cat($("fCat").value)[4],T=[["Cardápio (um por linha: <code>Prato | 25,90</code>)","Margherita | 49,90"],["Catálogo (um por linha: <code>Produto | 59,90</code>)","Camiseta básica | 49,90"],["Serviços oferecidos (um por linha, sem preços)","Avaliação inicial"],["Serviços (um por linha: <code>Serviço | 80</code>)","Corte | 45"],["Serviços (um por linha: <code>Serviço | 80</code>)","Troca de óleo | 120"],["Produtos ou serviços (um por linha: <code>Item | 30</code>)","Item | 30"]][g]||[];$("fCl").innerHTML=T[0];$("fCard").placeholder=T[1]}
const bad=(id,m)=>{["fNome","fEnd"].forEach(i=>$(i).removeAttribute("aria-invalid"));const e=$(id);e.setAttribute("aria-invalid","true");e.setAttribute("aria-describedby","fErr");$("fErr").textContent=m;e.focus()};
let pub=0;const publicar=async()=>{const nome=$("fNome").value.trim(),end=$("fEnd").value.trim();
if(!nome)return bad("fNome","Informe o nome do comércio (ex.: Pizzaria do Zé).");if(!end)return bad("fEnd","Informe o endereço ou digite o CEP para preenchê-lo.");
const k=Math.max(.1,+$("fKm").value||1),a=Math.random()*6.28,cd=$("fCard").value.split("\n").map(l=>l.split("|")).filter(p=>p[0].trim()).map(p=>{const v=p.length>1?preco(p[1]):NaN;return[p[0].trim(),isNaN(v)?null:v]});
const nid="u"+Date.now();N.unshift(mk(nid,nome,$("fCat").value,"$$",$("fDesc").value.trim()||"Novo por aqui!",end,"",GEO?GEO.lat:POS.lat+Math.sin(a)*k/111,GEO?GEO.lng:POS.lng+Math.cos(a)*k/111,cd,[]));N[0].redes={ig:$("fIg").value.trim(),tt:$("fTt").value.trim(),wa:$("fWa").value.trim()};if(FV&&FV.blob){N[0].vid=true;try{await DB.put(nid,FV.blob);VURL[nid]=URL.createObjectURL(FV.blob)}catch(e){N[0].vid=false}}
save();["fNome","fDesc","fEnd","fCard","fIg","fTt","fWa"].forEach(i=>$(i).value="");$("fErr").textContent="";["fNome","fEnd"].forEach(i=>$(i).removeAttribute("aria-invalid"));GEO=null;FV=null;$("fVid").classList.remove("on");$("fVid").removeAttribute("src");$("fVn").textContent="";go("vFeed");toast("Vídeo publicado!","ok");notify("sys",nome+" foi publicado. Compartilhe com seus clientes!",nid);S.tab="perto";S.cat="Todos";S.q="";S.raio=Math.max(S.raio,Math.ceil(k));save();feed(true);setTimeout(()=>{const e=document.querySelector('#feed .p[data-n="'+nid+'"]');e&&e.scrollIntoView()},60)};
$("bSalva").onclick=async()=>{if(pub)return;pub=1;$("bSalva").disabled=true;$("bSalva").classList.add("is-loading");try{await publicar()}finally{pub=0;$("bSalva").disabled=false;$("bSalva").classList.remove("is-loading")}};
feed();
$("fEnd").oninput=()=>{GEO=null;$("fEnd").removeAttribute("aria-invalid")};$("fNome").oninput=()=>$("fNome").removeAttribute("aria-invalid");
$("fCep").onchange=async()=>{const e=await API.cep($("fCep").value);if(e){$("fEnd").value=e;toast("Endereço encontrado","ok")}else toast("CEP não encontrado. Confira os 8 números ou digite o endereço.","err")};
ptr($("feed"),async()=>{await API.recarregar();feed(true);toast("Feed atualizado")});
API.recarregar().then(()=>feed(true));
$("chips").onclick=e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;if("pl" in d)return lugar();if("plx" in d)return voltaLocal();if("x" in d)S.only=null;else if("r2" in d)S.raio=5;else if("q" in d)S.q="";else if(d.c)S.cat=d.c;save();feed()};
fLbl();
// cadastro: vídeo (arquivo real ou exemplo)
let FV=null;const pv=u=>{const v=$("fVid");v.src=u;v.classList.add("on");v.play().catch(()=>{})};
$("bFile").onclick=()=>$("fFile").click();
$("fFile").onchange=e=>{const f=e.target.files[0];if(!f)return;if(!/^video\//.test(f.type))return $("fErr").textContent="Esse arquivo não é um vídeo. Escolha um vídeo (MP4, MOV…) ou use o de exemplo.";if(f.size>40e6)return $("fErr").textContent="Vídeo grande demais (máx. 40 MB). Escolha um vídeo menor ou corte o trecho.";$("fErr").textContent="";FV={blob:f};pv(URL.createObjectURL(f));$("fVn").textContent=f.name.slice(0,28)};
$("bEx").onclick=()=>{const c=$("fCat").value,u=rm("video",c,1);FV={sample:true};if(u)pv(u);$("fVn").textContent="Exemplo: "+c};
$("fCat").onchange=()=>{fLbl();if(FV&&FV.sample)$("bEx").onclick()};
// teclado (PC): setas navegam como no TikTok
document.addEventListener("keydown",e=>{const f=$("feed");if(!$("vFeed").classList.contains("on")||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))return;if(e.key==="ArrowDown"){e.preventDefault();f.scrollBy({top:f.clientHeight,behavior:"smooth"})}if(e.key==="ArrowUp"){e.preventDefault();f.scrollBy({top:-f.clientHeight,behavior:"smooth"})}});
demoNot();vids().then(()=>feed(true));
// Esc fecha a gaveta; modo offline (service worker) só em http(s)
document.addEventListener("keydown",e=>{if(e.key!=="Escape")return;if($("sh").classList.contains("on"))return $("sh").classList.remove("on");if($("pv"))return pvClose();if($("vBus").classList.contains("on"))$("bsB").click()});
// foco: ao abrir a gaveta foca o primeiro campo/botão; ao fechar devolve o foco a quem a abriu
{let ret=null;new MutationObserver(()=>{const o=$("sh").classList.contains("on");if(o){ret=document.activeElement;const f=$("sh").querySelector("input,button");f&&f.focus({preventScroll:true})}else if(ret&&ret.isConnected){try{ret.focus({preventScroll:true})}catch(e){}ret=null}}).observe($("sh"),{attributes:true,attributeFilter:["class"]})}
document.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches&&e.target.matches('[role=button][data-act]')){e.preventDefault();e.target.click()}});
if("serviceWorker" in navigator&&/^https?:$/.test(location.protocol))navigator.serviceWorker.register("sw.js").catch(()=>{});
window.__pertinho=1;
