# Pertinho v5 — o que mudou e o que melhorar

## Novo nesta versão
- **Músicas reais** (`js/api.js`): iTunes Search (prévia de 30 s, capa e nome do artista) → Audius (faixa completa) → mp3 local. Cada categoria tem um gênero (pizza = tarantela, café = bossa nova, brasileira = samba…). O disco girando mostra a capa do álbum.
- **Puxar para atualizar**: no topo do feed, puxe para baixo (celular) ou role a roda para cima (PC). Recarrega a posição, os comércios, o clima e sorteia outras músicas.
- **Busca**: histórico, comércios e pratos locais na hora, e lugares do Brasil (Nominatim) com debounce. Escolher um lugar move o feed para lá.
- **APIs (todas sem chave)**: Geolocalização, OpenStreetMap/Overpass (comércios reais num raio de 2,5 km), Nominatim, Open-Meteo (clima), ViaCEP (CEP preenche endereço e coordenadas), Web Share, Google Identity (preencha `CFG.GOOGLE_CLIENT_ID`).
- **Segurança (a partir do AndroidRevEngineering)**: CSP restrita aos domínios usados, sem atributos inline, timeout e validação em toda resposta de API, dados externos sempre escapados, só HTTPS, comércios do OSM não são gravados no `localStorage`, nenhuma chave no código.

## Análise e melhorias recomendadas
1. **Backend próprio** (maior ganho): hoje tudo fica no `localStorage`. Posts, curtidas, comentários e login precisam de servidor, e o token do Google deve ser validado lá (decodificar o JWT no front não prova nada).
2. **Vídeo real por comércio**: hoje os vídeos são por categoria. Permitir upload (com limite de tamanho/duração e checagem do tipo no servidor), idealmente em HLS.
3. **Chaves de API**: qualquer chave no front é pública e extraível (é o primeiro item que o repositório AndroidRev manda procurar num APK). Use um proxy seu para Pexels/Jamendo/Google Places.
4. **Cache e offline**: service worker para o shell e cache das respostas de busca; hoje cada refresh refaz as consultas.
5. **Músicas**: prévias do iTunes têm 30 s e vêm de uso promocional; para produção, use Jamendo/Audius com licença clara.
6. **Overpass** é um serviço público com limite de uso: em produção, cacheie no servidor por região.
7. **Acessibilidade**: legendas nos vídeos, `aria-live` nos toasts, foco nas gavetas.
8. **Ao empacotar como app Android (Capacitor/TWA)**, confira no APK final (com o MobSF, como o repositório ensina): `allowBackup=false`, `usesCleartextTraffic=false`, `debuggable=false`, nenhum componente exportado sem necessidade, só permissão de localização aproximada/precisa, R8 ativado, e *certificate pinning* via `network_security_config` apenas para o SEU backend (não para APIs de terceiros, que trocam certificado).

## Como rodar
`python3 -m http.server` na pasta e abra `localhost:8000` (geolocalização exige localhost ou HTTPS).

## Correções da v5
- Filtros e raio: a gaveta de busca era redesenhada a cada toque e apagava o raio e o texto escolhidos. Agora tudo se aplica na hora e o botão mostra quantos resultados existem. Também há chips de categoria e de raio (📍) direto no feed.
- Com localização real, os comércios de exemplo (Rio) sumiam do feed; agora acompanham a sua posição.
- Postar: escolha ou grave um vídeo (até 40 MB, só tipo vídeo) ou use o vídeo de exemplo; o post vai para o topo do feed e o vídeo fica salvo no IndexedDB.
- Barra de progresso real, copiar link no "Enviar", setas ↑↓ no PC e login com retorno do nome.

## Novidades da v6
- **Perfil da loja**: abas Vídeos (grade 9:16 com visualizações; tocar abre o vídeo no feed só daquela loja, com o chip "✕ Só …" para voltar), Cardápio, Fotos, **Avaliações** e Local.
- **Estrelas**: nota média no cabeçalho e no feed, distribuição por estrela, sua nota (toque nas estrelas) e comentário.
- **Uso dos arquivos enviados**: do Loops, o desenho de rotas (`API-BACKEND.md`); ele usa ícones Feather, então a estrela segue o mesmo traço do app. Do Awesome-Design-Tools, referências para o próximo passo visual (Feather Icons, Coolors para paleta, unDraw/Blush para telas vazias). A lista de open source em português é material para iniciantes e não trouxe nada aplicável ao app.

## v7 — visual
- A nota saiu do feed: só aparece no perfil da loja, em uma linha discreta (★ 4,3 · 233 avaliações; tocar abre a aba Avaliações).
- O clima foi para a faixa de filtros e não cobre mais o "Seguindo".

## v9 — auditoria de UI/UX e responsividade
Feita com os dois pacotes enviados (ambos MIT): o `audit.js` do **ui-ux-audit** (contraste, alvos de toque, foco, animação) e a checagem de overflow do **mobile-responsive**, rodados em 320 a 1440 px em feed, loja, cadastro e perfil.
- Sem rolagem horizontal em nenhuma largura. A faixa de chips rola de lado de propósito, dentro do próprio contêiner.
- Alvos de toque: botões do topo, busca, som, chips, Voltar/Seguir passaram para pelo menos 40–44 px.
- Contraste: o cabeçalho da loja ganhou uma camada escura sutil e o tom âmbar da categoria Brasileira foi escurecido (branco sobre ele era 2,7:1; agora cerca de 5:1). Textos sobre vídeo ou gradiente não são medidos pelo `audit.js`, então ficam como "conferir no olho".
- Foco visível para teclado e `100dvh` para a barra do navegador do celular.
- Novo teste `tests/e2e_responsive.py` (larguras 320–1440, 4 telas).

## v13 — perfil do usuário e notificações
- **Perfil**: abas fixas Curtidos (vídeos + fotos), Salvos, Seguindo (com botão para deixar de seguir) e Meus (comércios que você publicou, com exclusão em dois toques). Tocar num vídeo abre o player dentro do perfil.
- **Notificações**: sino no perfil com contador, bolinha no ícone Perfil do rodapé, lista com "não lidas" destacadas, Limpar e liga/desliga por tipo (novos vídeos de quem sigo, ofertas perto).
- As notificações de "novo vídeo" e "oferta" são **geradas no aparelho para demonstração**; as de seguir/publicar são reais. Com backend (`API-BACKEND.md`) passam a vir de eventos de verdade + push.
- **Ainda falta (comparando com Instagram, TikTok, iFood, Google Maps)**: conta real e sincronização entre aparelhos; push no celular; comentários com resposta/curtida e denúncia/bloqueio; "aberto agora" e horário por dia; pedido/reserva/cupom; avaliações com foto e resposta do dono; painel do comércio (visualizações, cliques em WhatsApp/rota); selo de comércio verificado; mapa com pinos; compartilhar vídeo com link direto.

## v14 — estrutura estilo TikTok
- **Feed limpo**: sem faixa de filtros nem clima por cima do vídeo (foram para "Descobrir"); filtros ativos aparecem só como uma pílula "✕" quando existem. Legenda em 2 linhas com toque para expandir, ações só com número (sem rótulos), degradê e barra de progresso mais discretos.
- **Rodapé**: Início · Descobrir · ＋ · Avisos (com contador) · Perfil. Notificações viraram uma aba própria.
- **Perfil**: barra com editar / compartilhar / configurações; nome grande + @usuário + avatar; Seguindo · Curtidas · Salvos; botões Editar perfil / Postar comércio; abas só com ícone (curtidos, salvos, seguindo, meus comércios) e grade de 3 colunas sem espaços. Entrar/sair e apagar dados foram para o menu ≡.

## v15 — Filtro, busca e novas abas
- **Filtro**: o antigo "Descobrir" do rodapé agora se chama Filtro (raio + categoria, com contagem de resultados).
- **Busca (lupa)**: tela cheia estilo TikTok com histórico (remover item, "Ver mais"), "Você pode gostar" (muda com o que você curte/salva/segue, botão Atualizar) e "Populares perto de você". Digitando: lojas/pratos locais e lugares (Nominatim).
- **Abas do topo**: Seguindo · Perto (de você) · **Para você** (ranqueia por afinidade: categorias que você curtiu/salvou/seguiu, com distância e variação diária, raio mínimo de 25 km) · **Mapa** (OpenStreetMap com pins por categoria, arrastar, zoom, cartão da loja com Ver perfil / Ver vídeos / Como chegar). Em telas estreitas "Perto de você" vira "Perto".
- O botão de som saiu do topo e virou um ícone na coluna de ações de cada vídeo.

## v16 — mais tipos de comércio
- **19 categorias em 6 grupos**: Comer e beber, Compras (roupas, mercado, farmácia, pet shop), Saúde (odontologia, clínica), Fitness e beleza (academia, salão, barbearia), Serviços (oficina, lavanderia, assistência técnica) e Outros. 12 comércios de exemplo novos.
- **Filtro agrupado**: cada categoria mostra quantos comércios há no raio escolhido; as vazias ficam esmaecidas e avisam "Nenhum por aqui ainda". "Tudo · N" filtra o grupo inteiro.
- **OpenStreetMap ampliado**: a consulta agora traz também lojas, saúde, academias, beleza e serviços (3 km, até 150 resultados) e guarda o resultado por 3 h no aparelho.
- **Campos por grupo**: Comer = Cardápio; Compras = Catálogo; demais = Serviços. Em **Saúde** não há preços (aviso de publicidade). O cadastro aceita itens sem preço.
- Mídia (vídeo/foto/música) das categorias novas usa o conjunto de exemplo "Outros" até haver material próprio.
- Quem já tinha o app salvo recebe os comércios de exemplo novos automaticamente.

## v17 — auditoria completa (diagnóstico, correções e testes)
- **Service worker**: `sw.js` estava vazio (0 bytes), então não havia modo offline apesar do README. Agora guarda o casco do app (HTML/CSS/JS/ícones), usa rede primeiro para a página e cache primeiro para os arquivos locais; vídeo/áudio e APIs externas passam direto. Para renovar o cache após editar arquivos, aumente `VERSION` em `sw.js`.
- **Layout em telas ≥600 px**: `#app` não tinha largura e encolhia ao conteúdo dentro do grid; a Busca ficava em branco e o mapa vazava da moldura (tablet e celular em paisagem). Corrigido com `width:100%`.
- **Celular em paisagem** (altura <700 px): sem moldura de aparelho, coluna vertical em tela cheia, coluna de ações compacta.
- **Alvos de toque**: todos os botões com pelo menos 44 px (aba Mapa, avatar de edição, redes sociais sem link, botões do perfil e do cadastro).
- **Esc** agora sai da Busca e fecha o player do perfil; a gaveta devolve o foco a quem a abriu.
- **Seguindo** mostra todas as lojas seguidas, independente do raio (antes aparecia "você não segue ninguém" para lojas seguidas fora do raio).
- Toasts não se cancelam mais uns aos outros; imagens do feed com `loading="lazy"` (até 300 posts com dados do OSM); CEP: endereço digitado à mão descarta a geolocalização antiga.
- Segurança: id da faixa Audius codificado na URL; capa do álbum só aceita URL https sem caracteres de escape de CSS. Removido código morto (`API.sug`).
- PWA: `manifest` com `id`, `scope` e orientação; ícones separados; `interactive-widget=resizes-content` para o teclado virtual.
- Testes atualizados (seletores antigos) e ampliados: 9 resoluções incluindo paisagem e tablet, Busca e Mapa, largura do app.

## v18 — explorar outra cidade ou estado
- **Pílula de local** sempre visível no topo do feed ("📍 Perto de você ▾"). Tocar abre **Explorar um lugar**: escolha o **Estado** (27 UFs) e digite a **Cidade**; a lista mostra só cidades daquele estado (Nominatim/OpenStreetMap). Atalhos também no **Filtro** (seção Local) e na **Busca** ("Explorar outra cidade ou estado").
- Ao escolher, o feed, o mapa, o filtro e a busca passam a mostrar os comércios reais daquele local (OpenStreetMap, raio de 3 km do centro da cidade). Os comércios de exemplo (fictícios, do Rio) ficam ocultos enquanto você explora. O local fica salvo; o **✕** da pílula (ou "Voltar para minha localização") restaura sua posição.
- As distâncias mostradas são a partir do centro da cidade escolhida. Para ver outros bairros, arraste o mapa até lá e escolha a cidade de novo, ou use um lugar mais específico na Busca.
- Teste novo: `tests/e2e_lugar.py` (APIs simuladas).

## v19 — tela Explorar no botão central
- O botão "+" do centro da barra inferior (postar vídeo) foi substituído por **Explorar**, com ícone próprio (lupa com pino). Postar comércio continua em **Perfil → + Postar comércio**.
- **Tela Explorar** (inspirada em apps de corrida/entrega): saudação "Olá, nome!" e pílula de local no topo; **mapa com as lojas** (pinos por categoria, zoom, cartão com Ver perfil / Ver vídeos / Como chegar); cartão **"O que você procura?"** com as últimas pesquisas e o atalho **"Ver outra cidade ou estado"**; **Lojas recomendadas na região** (mais próximas, em carrossel).
- Voltar da Busca agora retorna à tela de onde ela foi aberta; o mapa se recentraliza ao trocar de cidade.
- Testes: smoke cobre Explorar (mapa, busca pelo cartão, loja recomendada); responsividade inclui a nova tela.

## v20 — filtro sem faixa no feed
- Removida a faixa com a pílula de local e os chips "✕" por cima do feed.
- O botão **Filtro** do rodapé fica **rosa, com um ponto**, enquanto houver filtro ativo (categoria, raio diferente de 5 km, busca, "só uma loja" ou outra cidade).
- Dentro do Filtro há **Limpar filtros** (também volta para a sua localização). O local continua acessível pela tela Explorar e pelo Filtro.

## v21 — auditoria completa (falhas, correções e testes)
Relatório completo em `RELATORIO-AUDITORIA.md`. Resumo: estado salvo inválido não derruba mais o app; preço no formato brasileiro (`1.234,50`); Publicar não duplica com duplo clique; excluir loja e "Apagar dados" removem também os vídeos do IndexedDB; busca aceita várias palavras em qualquer ordem; resposta de erro do Overpass não é cacheada; aviso quando a localização é negada; mapa recentraliza quando a posição chega; avatar, seguir e pinos do mapa funcionam por teclado; contador de comentários coerente; "Link copiado" só quando copiou. Novo teste: `tests/e2e_auditoria.py`. `sw.js` VERSION = pertinho-v21.
**Pendentes:** raio fixo de 3 km nos comércios reais, uso do Nominatim como autocomplete, login Google só de demonstração e tudo que depende de backend.

## v22 — busca no Explorar e duplo toque em Início
- **Duplo toque em Início** não recarrega mais a página: volta ao topo e atualiza o feed (posição, comércios e clima). O recarregamento forçado podia deixar a tela vazia quando os scripts não carregavam (servidor local instável).
- **Tela de recuperação** (`js/boot.js`): se um script falhar ao carregar ou o app não iniciar, aparece "Não foi possível carregar" com o botão "Tentar de novo" (limpa o cache e recarrega).
- **Explorar → "O que você procura?"**: a busca feita ali volta para o Explorar. O mapa mostra só as lojas encontradas (enquadradas na tela), a lista "Resultados" vira atalho para o perfil de cada loja, e o botão **Buscar feeds · N vídeos** abre o feed geral já filtrado (o raio sobe para 10 ou 25 km se for preciso para cobrir os resultados). ✕ limpa a busca. Essa busca só altera o feed quando você toca em "Buscar feeds".
- **Voltar** no perfil da loja volta para a tela de onde você veio (Explorar, busca, perfil), em vez de sempre ir ao feed.
- Teste novo: `tests/e2e_explorar.py`. `sw.js` VERSION = pertinho-v22.

## v23 — design system (Uber + TikTok) e correções de interface
Detalhes em `DESIGN-SYSTEM.md` e `RELATORIO-DESIGN-V23.md`. Resumo: tokens centralizados em `css/tokens.css`; botão primário sólido neutro (estilo Uber) e destaque de marca só onde importa (estilo TikTok); barra do topo do feed refeita (a aba **Mapa** ficava cortada sob a lupa em 390 px); Explorar com cabeçalho neutro, saudação e local sem corte; **Seguir** destacado no perfil da loja; contraste AA (texto rosa em fundo claro era 3,4:1; selo de aviso idem); foco visível nos dois temas; campo de WhatsApp (`type=tel`) estava sem estilo; cadastro com erro no campo certo (`aria-invalid`, foco e instrução); toast com tipo (ok/erro); indicador de carregamento acessível; abas da loja sem rótulo espremido; CSS conflitante removido (5 camadas da barra do topo e a faixa de chips, que nunca aparecia). O CSS total cresceu de 33,3 KB para 38,8 KB (com `tokens.css`) por causa dos novos componentes. Novo teste: `tests/e2e_design.py`. `sw.js` VERSION = pertinho-v23.
