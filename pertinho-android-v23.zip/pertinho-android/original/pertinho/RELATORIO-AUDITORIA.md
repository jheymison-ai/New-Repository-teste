# Relatório de auditoria — Pertinho v20 → v21

Data: 11/10/2026 · Ambiente: Linux, Python 3.12.3, Playwright 1.56.0 + Chromium 1194 (headless), Node 22 (só para checar sintaxe). **Sem acesso à internet**: todas as APIs externas foram bloqueadas ou simuladas nos testes.

## 1. Resumo

O Pertinho é um app 100% front-end (HTML/CSS/JS puro, PWA). Não há backend, banco de dados nem autenticação no servidor, então partes do roteiro de auditoria (autorização no servidor, SQL injection, CSRF, rate limiting, migrações) **não se aplicam** e não foram testadas.

Os 3 testes que já existiam passavam na v20 (smoke, lugar, responsivo), mas não cobriam estado salvo inválido, formatos de preço, duplo clique, exclusão/limpeza de dados, busca com várias palavras nem teclado. Foram encontradas **14 falhas confirmadas por reprodução** (nenhuma crítica), todas corrigidas e cobertas por teste novo (`tests/e2e_auditoria.py`): os 14 itens (AUD-01…14) falhavam na v20 e todos passam na v21. Há **itens pendentes** (seção 6) que exigem decisão sua ou backend.

## 2. Estrutura e tecnologias

`index.html` · `css/style.css` · `js/{icons,data,api,app}.js` · `sw.js` · `manifest.webmanifest` · `assets/` · `tests/`. Sem build e sem dependências npm. APIs públicas: iTunes Search, Audius, Overpass, Nominatim, Open-Meteo, ViaCEP, tiles do OpenStreetMap, Mixkit (vídeos), Google Identity (opcional, sem Client ID por padrão). Dados do usuário: `localStorage` (estado) e IndexedDB (vídeos postados).

## 3. O que foi examinado

Leitura completa de `app.js`, `api.js`, `data.js`, `icons.js`, `sw.js`, manifest, CSP e dos 3 testes. Checagem de sintaxe (`node --check`, `py_compile`, JSON do manifest). Execução dos testes existentes e de sondas de reprodução para cada suspeita. Conferência de que todos os arquivos de mídia referenciados existem (14 vídeos, 14 fotos, 7 músicas, ícones).

## 4. Falhas confirmadas e corrigidas

Gravidade segundo a escala do roteiro. "Reprodução" = como o teste prova o problema na v20.

| ID | Gravidade | Onde | Problema (v20) | Correção (v21) |
|---|---|---|---|---|
| AUD-01 | **Alta** | `app.js` carregamento do `localStorage` | Estado salvo com formato inesperado (ex.: `N` não-lista, `S.nt` não-lista) lançava exceção no carregamento e **o app ficava em branco**, sem caminho de recuperação a não ser limpar o armazenamento manualmente. Reprodução: `pertinho-v2={"N":5,"S":{}}` → 0 posts, `N.some is not a function`. | Validação e normalização de lojas (`limpaN`) e do estado (`lerS`); dados inválidos são descartados e o app abre com os padrões. |
| AUD-02 | Média | `app.js` cadastro | Preço no formato brasileiro errado: `1.234,50` virava R$ 1,23; `1,2,3` virava 1,2. | Função `preco()`: milhar com ponto, vírgula decimal, `R$`, inválido = sem preço. |
| AUD-04 | Média | `app.js` botão Publicar | Duplo clique (ou toque duplo) durante o salvamento do vídeo criava **2 lojas**. | Trava de reentrada e botão desabilitado enquanto publica. |
| AUD-05 | Média | `app.js` excluir loja | O vídeo continuava no IndexedDB e curtidas, salvos, follow, nota, comentários e avisos da loja ficavam órfãos. | `DB.del` + `limpaRastro()`. |
| AUD-06 | Média | `app.js` "Apagar dados deste aparelho" | Só limpava o `localStorage`; **vídeos ficavam no IndexedDB** (e o cache do service worker), contrariando o texto do botão. | Também apaga IndexedDB, `sessionStorage` e caches; conexão IndexedDB agora é única e reutilizada (antes abria uma nova a cada operação e nunca fechava). |
| AUD-08 | Média | `api.js` Overpass | Resposta HTTP 200 com erro/timeout (`remark: runtime error…`) e lista vazia era **cacheada por 3 h**, escondendo os comércios reais da região. | Respostas com erro não entram no cache; resultado vazio tem cache de 5 min; cache lido passa por validação. |
| AUD-10 | Média | `api.js`/`app.js` mapa | Se o mapa já estava aberto quando a localização real chegava (ex.: usuário abre Explorar com o pedido de permissão pendente), ele continuava centrado no Rio. | Mapa recentraliza quando a posição muda mais de ~50 m. |
| AUD-07 | Baixa | `app.js` busca | A busca exigia a frase inteira: `pizza margherita` e `margherita pizza` retornavam 0 resultados. Feed, mapa e sugestões usavam campos diferentes. | `bate()`: todas as palavras, em qualquer ordem, sem acento/caixa; mesmos campos nos três lugares. |
| AUD-03 | Baixa | `app.js` comentários | O número no ícone de comentários divergia da lista (ex.: ícone "7", lista "3 comentários") em 6 de 8 posts testados. | Contador = comentários exibidos. |
| AUD-09 | Baixa | `api.js` geolocalização | Com a localização negada/indisponível o app mostrava o Rio sem explicar. | Aviso único: "Sem acesso à localização: mostrando o centro do Rio de Janeiro". |
| AUD-11 | Baixa | `app.js` acessibilidade | Avatar da loja, "+" de seguir, @usuário e pinos do mapa não eram acionáveis por teclado. | `tabindex`, Enter/Espaço e clique de teclado nos pinos. |
| AUD-12 | Informativa | `app.js` | Dados adulterados no `localStorage` eram inseridos como HTML (`categoria`, `faixa`, `fotos` sem escape). **A execução é bloqueada pela CSP** (confirmado: "Refused to execute inline event handler"), então não é explorável hoje; é defesa em profundidade. | Saneamento na carga. |
| AUD-13 | Baixa | `app.js` Enviar/compartilhar | Mostrava "Link copiado" mesmo sem Clipboard API ou com a cópia negada. | `copiar()` só confirma quando copiou. |
| AUD-14 | Baixa | `app.js` | Histórico de busca inválido derrubava a tela de busca; campo de comentário sem limite (crescimento do `localStorage`); falha de gravação (cota) era silenciosa. | Validação do histórico, `maxlength=200`, aviso único de "sem espaço". |

Também: `sw.js` `VERSION` passou a `pertinho-v21` (necessário para renovar o cache dos arquivos alterados).

## 5. Testes executados (resultados reais)

| Teste | v20 original | v21 corrigida |
|---|---|---|
| `tests/e2e_smoke.py` (fluxos, offline, CSP, 404) | TUDO OK | TUDO OK |
| `tests/e2e_lugar.py` (estado/cidade, APIs simuladas) | TUDO OK | TUDO OK |
| `tests/e2e_responsive.py` (9 resoluções) | TUDO OK | TUDO OK |
| `tests/e2e_auditoria.py` (**novo**, 23 verificações AUD-01…14) | 21 falham, 2 controles passam | **TUDO OK** |

Observação sobre AUD-07: o sub-caso "espaços extras" só falha no original quando o teste grava `S.q` diretamente; pela interface a busca já faz `trim`. A falha real e alcançável é a das várias palavras.

## 6. Pendências, riscos e itens não verificados

**Pendentes que exigem decisão ou mudança estrutural (não aplicados):**

1. **Raio × dados reais (Média, confirmado pelo código).** A consulta ao Overpass usa raio fixo de 3 km (`around:3000`), mas o filtro oferece 5/10/25 km. Para comércios reais, subir o raio não traz mais resultados. Corrigir exige decidir o raio de busca e lidar com o limite de 150 elementos e a carga no Overpass público.
2. **Nominatim com autocomplete (Baixa/Média, suspeita fundamentada).** Busca de lugares e de cidades consulta o Nominatim a cada digitação (com debounce). A política de uso do serviço público, até onde sei, proíbe autocomplete no cliente e limita a 1 req/s; há risco de bloqueio de IP. Não pude conferir a política vigente sem rede. Recomendação: busca explícita (botão/Enter) ou um geocodificador com autocomplete.
3. **Login Google (Informativa).** O token é decodificado no navegador sem validar assinatura/`aud`/`exp`; `S.user` fica editável no `localStorage`. Aceitável só como demonstração; para uso real é preciso backend. Também não testado: com Client ID real, só `google.accounts.id.prompt()` é chamado (sem `renderButton`), então o One Tap pode não aparecer se o usuário já o dispensou; e a CSP não lista `https://accounts.google.com/gsi/style` em `style-src` (suspeita; precisa de Client ID e rede para confirmar).
3b. **Sem backend (limitação conhecida):** curtidas, comentários, avaliações, follows e posts são locais. Qualquer pessoa pode editar o próprio armazenamento. Dados de demonstração (lojas do Rio, notas, contadores de curtidas/comentários) são fictícios e aparecem como se fossem reais perto de qualquer localização; recomendo um selo "exemplo".
4. **Service worker (Informativa):** cache primeiro para JS/CSS exige lembrar de subir `VERSION` a cada mudança (feito na v21).
5. **Manifest:** `orientation: portrait-primary` trava o app instalado em retrato, apesar de o layout ter suporte a paisagem/tablet.
6. **Acessibilidade restante:** a gaveta (`role=dialog`) não prende o foco; após selecionar um pino pelo teclado o foco se perde porque o mapa redesenha.
7. A "ordenação diária" de "Para você" usa a data em UTC (muda às 21h no Brasil).

**Não executado:** testes de carga/desempenho (nenhuma medição de CPU, memória ou rede foi feita); validação real das APIs externas (sem internet); Safari/Firefox (só Chromium); login Google real; autorização/injeção/CSRF em servidor (não existe servidor). Nenhuma garantia de "livre de erros" é dada: só foi verificado o que está listado acima.

## 7. Dependências

Nenhuma dependência de runtime. Para testes: `playwright` (testado com 1.56.0) e Chromium. Serviços externos públicos listados na seção 2 (sem chave; sujeitos a limites de uso).

## 8. Como executar e testar

```
python3 -m http.server          # na pasta do projeto; abra http://localhost:8000
pip install -r tests/requirements.txt && playwright install chromium
python3 tests/e2e_smoke.py
python3 tests/e2e_lugar.py
python3 tests/e2e_responsive.py
python3 tests/e2e_auditoria.py   # regressão desta auditoria
PERTINHO_ROOT=/caminho/da/v20 python3 tests/e2e_auditoria.py   # compara com outra versão
```

## 8b. Atualização v22 (pedidos posteriores)

- **Duplo toque em Início:** não consegui reproduzir a tela vazia no Chromium de teste (o recarregamento funcionou 3 de 3 vezes). Pelo print enviado, HTML e CSS carregaram mas os scripts não (sem ícones nem feed), o que aponta para falha de carregamento no servidor local do celular durante o reload. Em vez de recarregar, o duplo toque agora só atualiza o feed; e `js/boot.js` mostra "Tentar de novo" se algum script falhar. A causa exata no aparelho **não foi confirmada**.
- **Busca no Explorar:** resultados no mapa, atalho ao perfil da loja e botão "Buscar feeds". Coberto por `tests/e2e_explorar.py` (19 verificações, todas OK). Todos os 5 testes passam na v22.

## 9. Avaliação final

Com base nas evidências: o app abre e funciona nos fluxos testados em Chromium (feed, busca, filtros, mapa, perfil, cadastro, offline), e as falhas confirmadas que afetavam robustez, integridade e privacidade dos dados locais foram corrigidas e cobertas por teste. Continuam em aberto o raio dos comércios reais, o uso do Nominatim e tudo que depende de backend. O original (v20) está preservado em `pertinho-v20-original.zip`, entregue à parte.
