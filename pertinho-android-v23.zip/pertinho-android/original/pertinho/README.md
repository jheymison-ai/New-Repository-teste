# Pertinho

Feed de vídeos curtos (estilo TikTok), tela Explorar com mapa e busca de comércios perto de você, ou em outra cidade/estado que você escolher: curtir, comentar, salvar, seguir, perfil da loja com vídeos/cardápio/fotos/avaliações/local, postar vídeo, busca, filtros por categoria e raio, puxar para atualizar e músicas reais.

## Tecnologias
HTML + CSS + JavaScript puro (sem build e sem dependências npm). PWA com service worker. APIs públicas sem chave: iTunes Search e Audius (músicas), OpenStreetMap Overpass e Nominatim (comércios e lugares), Open-Meteo (clima), ViaCEP (CEP). Login Google opcional (Google Identity).

## Pré-requisitos e execução
Python 3 (ou qualquer servidor estático) e um navegador. Na pasta do projeto: `python3 -m http.server` e abra `http://localhost:8000`. Geolocalização e service worker exigem `localhost` ou HTTPS (abrir o arquivo direto funciona, mas sem localização real nem modo offline).

## Configuração
- Login Google: preencha `CFG.GOOGLE_CLIENT_ID` em `js/api.js` (ID público; sem ele o login é de demonstração). O token deve ser validado em um servidor próprio antes de qualquer uso real.
- Nenhuma chave secreta é necessária. Não coloque chaves privadas no front-end.

## Testes
`pip install -r tests/requirements.txt && playwright install chromium`, depois `python3 tests/e2e_smoke.py` (fluxos) e `python3 tests/e2e_lugar.py` (escolher estado e cidade, com APIs simuladas) e `python3 tests/e2e_responsive.py` (9 resoluções 320×568 a 1440×900, inclusive paisagem e tablet; sem rolagem horizontal, largura do app e alvos de toque ≥ 40 px) `python3 tests/e2e_explorar.py` (busca no Explorar, duplo toque em Início, tela de recuperação) `python3 tests/e2e_design.py` (design system v23: tokens, barra do topo, contraste AA claro/escuro, foco, validação, carregamento, movimento reduzido) e `python3 tests/e2e_auditoria.py` (regressão da auditoria v21: estado salvo inválido, preços, duplo clique, exclusão e limpeza de dados, busca, Overpass, localização, teclado; sem rede)
Abre o app, clica em todos os botões principais (curtir, comentar, busca, filtro, loja, perfil, login de demonstração, cadastro), valida formulário, Esc, modo offline e confere que não há erro de JavaScript, 404 local ou violação de CSP. Sai com código 1 se algo falhar.

## Mídia
`assets/media/{video,img,music}/<categoria>[-N].<ext>` (categorias: pizza, japonesa, brasileira, hamburguer, cafe, doces, outros). Os arquivos incluídos são de exemplo; vídeos e fotos também vêm por link (Mixkit, em `js/data.js`) e a música vem das APIs, caindo para o mp3 local se falhar. Para preparar vídeos: `ffmpeg -i entrada.mp4 -t 10 -vf "scale=540:960:force_original_aspect_ratio=increase,crop=540:960" -c:v libx264 -crf 28 -pix_fmt yuv420p -movflags +faststart -an pizza-1.mp4`.

## Estrutura
`index.html` · `css/{tokens,style}.css` · `js/{boot,data,icons,api,app}.js` · `sw.js` · `manifest.webmanifest` · `assets/` · `tests/` · `DESIGN-SYSTEM.md` (tokens e componentes) · `MELHORIAS.md` (análise e roadmap) · `API-BACKEND.md` (contrato de API sugerido) · `RELATORIO-AUDITORIA.md` (auditoria v21: falhas, correções, testes e pendências)

## Limitações conhecidas
- Curtidas, comentários, avaliações, follows e login ficam só no navegador (`localStorage`/IndexedDB); falta um backend.
- Vídeos de exemplo são por categoria, não por comércio; notas das lojas de exemplo são fictícias.
- Prévias do iTunes têm 30 s e servem para demonstração.
- Comércios reais (OpenStreetMap) são buscados num raio fixo de 3 km, mesmo com o filtro em 5, 10 ou 25 km (ver pendências no `RELATORIO-AUDITORIA.md`).
