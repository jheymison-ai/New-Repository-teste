"""v22: duplo toque em Início sem recarregar, busca dentro do Explorar (resultados no mapa, perfil da loja, botão
'Buscar feeds') e tela de recuperação quando um script não carrega. Sem rede (tudo externo é bloqueado).
Roda: python3 tests/e2e_explorar.py"""
import asyncio,subprocess,time,sys,os
from playwright.async_api import async_playwright
ROOT=os.environ.get("PERTINHO_ROOT") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT=8197;URL=f"http://localhost:{PORT}/index.html"
async def main():
    srv=subprocess.Popen(["python3","-m","http.server",str(PORT),"--directory",ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1);fails=[]
    def ck(nome,ok,det=""):
        print(("OK    " if ok else "FALHA ")+nome+((" -> "+str(det)) if det!="" else ""))
        if not ok: fails.append(nome)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch()
            async def novo(bloqueia=()):
                c=await b.new_context(viewport={"width":390,"height":800},has_touch=True,is_mobile=True);pg=await c.new_page();errs=[];pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
                async def rota(r):
                    u=r.request.url
                    if not u.startswith(f"http://localhost:{PORT}") or any(u.endswith(x) for x in bloqueia): return await r.abort()
                    await r.continue_()
                await pg.route("**/*",rota);return c,pg,errs
            vis=lambda pg,id:pg.evaluate(f"document.getElementById('{id}').classList.contains('on')")
            # 1) duplo toque em Início: sem recarregar a página
            c,pg,errs=await novo();await pg.goto(URL);await pg.wait_for_timeout(1500)
            await pg.evaluate("window.__marca=1;S.only='d1';")
            await pg.tap('nav [data-go="vFeed"]');await pg.tap('nav [data-go="vFeed"]');await pg.wait_for_timeout(800)
            r=await pg.evaluate("[window.__marca,document.querySelectorAll('#feed .p').length,document.querySelectorAll('nav svg').length,S.only]")
            ck("duplo toque em Início atualiza sem recarregar a página",r[0]==1 and r[1]>3 and r[2]==5 and r[3] is None and not errs,r);await c.close()
            # 2) busca no Explorar
            c,pg,errs=await novo();await pg.goto(URL);await pg.wait_for_timeout(1200)
            await pg.tap('nav .plus');await pg.wait_for_selector('#xMap .pin',state='attached')
            antes=await pg.evaluate("document.querySelectorAll('#xMap .pin').length")
            await pg.tap('#xQ');await pg.fill('#qI','pizza');await pg.keyboard.press('Enter');await pg.wait_for_timeout(700)
            ck("busca feita no Explorar volta para o Explorar (não vai ao feed)",await vis(pg,'vExp') and not await vis(pg,'vFeed'))
            ck("campo mostra o que foi procurado",(await pg.inner_text('#xQ')).strip()=="pizza")
            info=await pg.evaluate("""(()=>{const pins=[...document.querySelectorAll('#xMap .pin')].map(b=>N.find(n=>n.id===b.dataset.id));const cards=[...document.querySelectorAll('#vExp .xk')].map(b=>N.find(n=>n.id===b.dataset.n));return{pins:pins.length,pizza:pins.every(n=>n.categoria==='Pizza'),cards:cards.length,cardsPizza:cards.every(n=>n.categoria==='Pizza'),sq:S.q,titulo:document.querySelector('#vExp .xt b').textContent}})()""")
            ck("mapa mostra só as lojas da busca",0<info["pins"]<antes and info["pizza"],f"{antes} -> {info['pins']}")
            ck("lista 'Resultados' só com lojas da busca",info["cards"]>0 and info["cardsPizza"],info["titulo"])
            ck("a busca do Explorar não altera o filtro do feed",info["sq"]=="")
            ck("botão 'Buscar feeds' aparece com a contagem",await pg.is_visible('#xFeed') and "Buscar feeds" in await pg.inner_text('#xFeed'),await pg.inner_text('#xFeed'))
            # clicar numa loja -> perfil; Voltar -> Explorar com a busca
            nome=await pg.evaluate("document.querySelector('#vExp .xk b').textContent")
            await pg.tap('#vExp .xk');await pg.wait_for_timeout(300)
            ck("tocar numa loja abre o perfil dela",await vis(pg,'vNeg') and nome in await pg.inner_text('#vNeg h1'),nome)
            await pg.tap('#vNeg .back');await pg.wait_for_timeout(500)
            ck("Voltar do perfil retorna ao Explorar com a busca",await vis(pg,'vExp') and (await pg.inner_text('#xQ')).strip()=="pizza")
            # pino -> cartão -> perfil
            await pg.evaluate("document.querySelector('#xMap .pin').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,clientX:1,clientY:1}));document.querySelector('#map').dispatchEvent(new PointerEvent('pointerup',{bubbles:true}))")
            await pg.focus('#xMap .pin');await pg.keyboard.press('Enter');await pg.wait_for_timeout(300)
            ck("pino do mapa abre o cartão com 'Ver perfil'",await pg.is_visible('#mcP'))
            # Buscar feeds -> feed geral filtrado
            await pg.tap('#xFeed');await pg.wait_for_timeout(700)
            f=await pg.evaluate("({sq:S.q,on:document.getElementById('vFeed').classList.contains('on'),cats:[...new Set(posts().filter(p=>lista().some(l=>l.id===p.id)).map(p=>p.n.categoria))],n:document.querySelectorAll('#feed .p').length})")
            ck("'Buscar feeds' abre o feed geral já filtrado",f["on"] and f["sq"]=="pizza" and f["n"]>0 and f["cats"]==["Pizza"],f)
            # limpar
            await pg.tap('nav .plus');await pg.wait_for_timeout(500)
            ck("sair e voltar ao Explorar começa sem busca",(await pg.inner_text('#xQ')).strip()=="O que você procura?")
            await pg.tap('#xQ');await pg.fill('#qI','sushi');await pg.keyboard.press('Enter');await pg.wait_for_timeout(600)
            await pg.tap('#xClr');await pg.wait_for_timeout(500)
            ck("✕ limpa a busca e o mapa volta a mostrar tudo",(await pg.inner_text('#xQ')).strip()=="O que você procura?" and await pg.evaluate("document.querySelectorAll('#xMap .pin').length")==antes)
            # sem resultado
            await pg.tap('#xQ');await pg.fill('#qI','zzzqqq');await pg.keyboard.press('Enter');await pg.wait_for_timeout(600)
            ck("busca sem resultado: mensagem e sem botão de feeds",not await pg.is_visible('#xFeed') and "Nenhuma loja encontrada" in await pg.inner_text('#vExp .xz'))
            # histórico dentro do Explorar permanece no Explorar
            await pg.tap('#vExp .xr[data-q]');await pg.wait_for_timeout(500)
            ck("tocar numa pesquisa recente permanece no Explorar",await vis(pg,'vExp'))
            # palavras em qualquer ordem
            await pg.tap('#xQ');await pg.fill('#qI','margherita pizza');await pg.keyboard.press('Enter');await pg.wait_for_timeout(500)
            ck("busca com 2 palavras também funciona no Explorar",await pg.evaluate("document.querySelectorAll('#vExp .xk').length")>0)
            ck("sem erros de JavaScript",not errs,errs);await c.close()
            # 3) recuperação quando um script não carrega
            c,pg,errs=await novo(bloqueia=("js/icons.js",));await pg.goto(URL);await pg.wait_for_timeout(1200)
            ck("script que falha mostra tela de recuperação com 'Tentar de novo'",await pg.is_visible('#bootErr button'));await c.close()
            c,pg,errs=await novo();await pg.goto(URL);await pg.wait_for_timeout(1200)
            ck("carregamento normal não mostra a tela de recuperação",await pg.locator('#bootErr').count()==0);await c.close()
            await b.close()
    finally: srv.terminate()
    print("\nRESULTADO:","FALHAS "+str(fails) if fails else "TUDO OK");sys.exit(1 if fails else 0)
asyncio.run(main())
