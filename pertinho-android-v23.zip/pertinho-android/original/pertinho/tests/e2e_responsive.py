"""Responsividade: em 8 larguras (320 a 1440) e em 4 telas, a página não pode ter rolagem horizontal
e nenhum botão de ação pode ter alvo de toque menor que 40 px. Roda: python3 tests/e2e_responsive.py"""
import asyncio,subprocess,time,sys,os
from playwright.async_api import async_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VIEWS={"feed":"go('vFeed')","explorar":"go('vExp')","busca":"buscaOpen()","mapa":"go('vFeed');S.tab='map';feed()","loja":"abre('d1')","cadastro":"go('vAdd')","perfil":"go('vPer')"}
async def main():
    srv=subprocess.Popen(["python3","-m","http.server","8141"],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1);fails=[]
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch();pg=await b.new_page()
            for w,h in ((320,568),(360,740),(375,667),(414,896),(740,360),(768,1024),(1024,768),(1280,800),(1440,900)):
                await pg.set_viewport_size({"width":w,"height":h});await pg.goto("http://localhost:8141/index.html");await pg.wait_for_timeout(700)
                for v,js in VIEWS.items():
                    await pg.evaluate(js);await pg.wait_for_timeout(250)
                    cw=await pg.evaluate("document.getElementById('app').getBoundingClientRect().width")
                    if cw<min(w,480)-2: fails.append(f"{w}x{h} {v}: app estreito ({cw:.0f}px)")
                    ov=await pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
                    if ov>0: fails.append(f"{w}px {v}: rolagem horizontal +{ov}px")
                    if w<=414 and w<h:
                        small=await pg.evaluate("[...document.querySelectorAll('.v.on button, nav button, #top button, #chips button')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&(r.height<40||r.width<40)&&!e.closest('#feed .rail')}).map(e=>(e.id||e.className||e.textContent).toString().slice(0,18)+' '+Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height))")
                        for s in small: fails.append(f"{w}px {v}: alvo pequeno {s}")
            await b.close()
    finally: srv.terminate()
    print("RESULTADO:","FALHAS\n  "+"\n  ".join(sorted(set(fails))[:15]) if fails else "TUDO OK");sys.exit(1 if fails else 0)
asyncio.run(main())
