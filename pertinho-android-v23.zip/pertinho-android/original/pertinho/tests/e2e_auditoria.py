"""Regressão da auditoria v21: cada verificação corresponde a uma falha encontrada (ID AUD-xx no RELATORIO-AUDITORIA.md).
Todas as APIs externas são bloqueadas ou simuladas: nenhum teste depende de rede.
Roda: python3 tests/e2e_auditoria.py            (testa o projeto desta pasta)
      PERTINHO_ROOT=/caminho/outra/versao python3 tests/e2e_auditoria.py   (compara com outra versão)
Sai com código 1 se algum item falhar."""
import asyncio,subprocess,time,sys,os,json
from playwright.async_api import async_playwright
ROOT=os.environ.get("PERTINHO_ROOT") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT=8195
URL=f"http://localhost:{PORT}/index.html"
OBS="new MutationObserver(()=>{const e=document.getElementById('toast');if(e&&e.textContent)(window.__t=window.__t||[]).push(e.textContent)}).observe(document,{subtree:true,childList:true,characterData:true})"
IDB_KEYS="new Promise(r=>{const q=indexedDB.open('pertinho',1);q.onupgradeneeded=()=>q.result.createObjectStore('v');q.onsuccess=()=>{const k=q.result.transaction('v').objectStore('v').getAllKeys();k.onsuccess=()=>{q.result.close();r(k.result)}}})"

async def main():
    srv=subprocess.Popen(["python3","-m","http.server",str(PORT),"--directory",ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1);fails=[]
    def ck(id_,nome,ok,det=""):
        print(("OK    " if ok else "FALHA ")+id_+" "+nome+((" -> "+str(det)) if det!="" else ""))
        if not ok: fails.append(id_)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch()
            async def novo(init=None,overpass=None,geo=False):
                c=await b.new_context(viewport={"width":390,"height":800},**({"geolocation":{"latitude":-23.55,"longitude":-46.63},"permissions":["geolocation"]} if geo else {}))
                pg=await c.new_page();errs=[];pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
                async def rota(r):
                    u=r.request.url
                    if u.startswith(f"http://localhost:{PORT}"): return await r.continue_()
                    if overpass is not None and "overpass-api.de" in u: return await r.fulfill(json=overpass,headers={"access-control-allow-origin":"*"})
                    await r.abort()
                await pg.route("**/*",rota)
                if init: await pg.add_init_script(init)
                return c,pg,errs
            async def abre(**k):
                c,pg,errs=await novo(**k);await pg.goto(URL);await pg.wait_for_timeout(1000);return c,pg,errs

            # AUD-01 estado salvo corrompido/antigo não pode derrubar o app
            for nome,estado in (("N não é lista",'{"N":5,"S":{}}'),("S.nt inválido",'{"N":[],"S":{"nt":5,"likes":"x","raio":-3}}'),("JSON quebrado","{nao-json")):
                c,pg,errs=await abre(init="localStorage.setItem('pertinho-v2',"+json.dumps(estado)+")")
                n=await pg.evaluate("document.querySelectorAll('#feed .p').length")
                ck("AUD-01","app abre com estado salvo corrompido ("+nome+")",n>0 and not errs,f"posts={n} erros={errs[:1]}");await c.close()

            c,pg,errs=await abre()
            # AUD-02 preço no formato brasileiro
            casos={"1.234,50":1234.5,"R$ 12,90":12.9,"7,5":7.5,"12.90":12.9,"1.234":1234,"0":0,"abc":None,"1,2,3":None,"":None}
            res=await pg.evaluate("c=>Object.fromEntries(Object.keys(c).map(k=>[k,Number.isNaN(preco(k))?null:preco(k)]))",casos) if await pg.evaluate("typeof preco")=="function" else None
            if res is None:
                # versão antiga: reproduz a lógica embutida no cadastro
                res=await pg.evaluate("c=>Object.fromEntries(Object.keys(c).map(k=>{const v=parseFloat(k.replace(/[^\\d,.-]/g,'').replace(',','.'));return[k,isNaN(v)?null:v]}))",casos)
            ck("AUD-02","preços '1.234,50' / 'R$ 12,90' / '7,5' / inválidos",res==casos,res if res!=casos else "")
            # cadastro de ponta a ponta com preço de milhar
            await pg.evaluate("go('vAdd')");await pg.fill('#fNome','Loja Preco');await pg.fill('#fEnd','Rua A, 1');await pg.fill('#fCard','Notebook | 1.234,50');await pg.click('#bSalva');await pg.wait_for_timeout(300)
            ck("AUD-02","cadastro grava 1234.5 para '1.234,50'",await pg.evaluate("N.find(n=>n.nome==='Loja Preco').cardapio[0][1]")==1234.5)

            # AUD-03 contador de comentários do ícone = lista
            await pg.evaluate("go('vFeed');S.tab='perto';S.raio=25;S.q='';S.cat='Todos';feed(true)");await pg.wait_for_timeout(300)
            div=0
            for i in range(0,8):
                r=await pg.evaluate(f"""(()=>{{const s=document.querySelectorAll('#feed .p')[{i}];if(!s)return null;const ic=+s.querySelector('[data-act=com] small').textContent;const id=s.dataset.p;const h=hash(id);const lista=3+(S.com[id]||[]).length;return [ic,lista]}})()""")
                if r and r[0]!=r[1]: div+=1
            ck("AUD-03","contador de comentários igual ao da lista (8 primeiros posts)",div==0,f"divergentes={div}")

            # AUD-04 duplo clique em Publicar não duplica a loja
            await pg.evaluate("go('vAdd')");await pg.set_input_files('#fFile',files=[{"name":"v.mp4","mimeType":"video/mp4","buffer":b"\x00"*200000}])
            await pg.fill('#fNome','Dup Loja');await pg.fill('#fEnd','Rua B, 2')
            await pg.evaluate("document.getElementById('bSalva').click();document.getElementById('bSalva').click()");await pg.wait_for_timeout(800)
            ck("AUD-04","duplo clique em Publicar cria uma só loja",await pg.evaluate("N.filter(n=>n.nome==='Dup Loja').length")==1)

            # AUD-05 excluir loja apaga vídeo (IndexedDB) e rastros
            did=await pg.evaluate("N.find(n=>n.nome==='Dup Loja').id")
            await pg.evaluate(f"S.likes['{did}-0']=true;S.save['{did}-1']=true;S.seg['{did}']=true;S.rate['{did}']=4;S.com['{did}-0']=['oi'];save()")
            await pg.evaluate("go('vPer');S.ptab='me';perfil()");await pg.wait_for_timeout(200)
            btn=f'#pb [data-d="{did}"]';await pg.click(btn);await pg.click(btn);await pg.wait_for_timeout(500)
            keys=await pg.evaluate(IDB_KEYS)
            ck("AUD-05","excluir loja remove o vídeo do IndexedDB",did not in keys,keys)
            resto=await pg.evaluate(f"[Object.keys(S.likes),Object.keys(S.save),Object.keys(S.seg),Object.keys(S.rate),Object.keys(S.com)].flat().filter(k=>k.startsWith('{did}'))")
            ck("AUD-05","excluir loja remove curtidas, salvos, follow, nota e comentários",resto==[],resto)

            # AUD-06 "Apagar dados" apaga também o IndexedDB
            await pg.evaluate("go('vAdd')");await pg.set_input_files('#fFile',files=[{"name":"v.mp4","mimeType":"video/mp4","buffer":b"\x00"*100000}])
            await pg.fill('#fNome','Loja Apagar');await pg.fill('#fEnd','Rua C, 3');await pg.click('#bSalva');await pg.wait_for_timeout(600)
            antes=len(await pg.evaluate(IDB_KEYS))
            await pg.evaluate("go('vPer');menu()");await pg.click('#bR');await pg.click('#bR')
            await pg.wait_for_load_state("load");await pg.wait_for_timeout(1500)
            depois=await pg.evaluate(IDB_KEYS);nomes=await pg.evaluate("N.map(n=>n.nome)")
            ck("AUD-06","'Apagar dados' remove vídeos do IndexedDB e as lojas criadas",antes>=1 and depois==[] and "Loja Apagar" not in nomes,f"antes={antes} depois={depois}");await c.close()

            # AUD-07 busca com várias palavras
            c,pg,errs=await abre()
            r=await pg.evaluate("""(()=>{const t=q=>{S.q=q;S.raio=25;const n=lista().length;S.q='';return n};return{a:t('pizza margherita'),b:t('margherita pizza'),c:t('PIZZÀ'),d:t('pizza   '),e:t('xyzabc'),f:t('forno bravo')}})()""")
            ck("AUD-07","'pizza margherita' e 'margherita pizza' encontram a loja",r["a"]>0 and r["b"]>0,r)
            ck("AUD-07","acento/maiúscula/espaços extras e consulta sem resultado",r["c"]>0 and r["d"]>0 and r["e"]==0 and r["f"]>0)
            r=await pg.evaluate("S.q='pizza  margherita';S.raio=25;feed(true);document.querySelectorAll('#feed .p').length")
            ck("AUD-07","feed mostra os resultados da busca com 2 palavras",r>0,r);await c.close()

            # AUD-08 Overpass com erro/timeout não pode gravar cache vazio por 3 h
            c,pg,errs=await abre(overpass={"elements":[],"remark":'runtime error: Query timed out in "query" at line 1 after 26 seconds.'})
            ck("AUD-08","resposta de erro do Overpass não é guardada em cache",await pg.evaluate("localStorage.getItem('pertinho-osm')")is None);await c.close()
            ok={"elements":[{"type":"node","id":7,"lat":-22.9068,"lon":-43.1729,"tags":{"name":"Padaria Teste","shop":"bakery"}}]}
            c,pg,errs=await abre(overpass=ok)
            ck("AUD-08","resposta válida do Overpass entra no feed e no cache",await pg.evaluate("N.some(n=>n.nome==='Padaria Teste')") and await pg.evaluate("!!localStorage.getItem('pertinho-osm')"));await c.close()

            # AUD-09 localização negada avisa; AUD-10 mapa recentra quando a posição chega
            c,pg,errs=await abre(init=OBS)
            ts=await pg.evaluate("window.__t||[]")
            ck("AUD-09","sem localização: avisa que está mostrando o Rio",any("Rio" in t for t in ts),ts[:3])
            await pg.evaluate("go('vExp')");await pg.wait_for_selector('#xMap .pin',state='attached')
            await c.grant_permissions(["geolocation"]);await c.set_geolocation({"latitude":-23.55,"longitude":-46.63})
            await pg.evaluate("API.recarregar()");await pg.wait_for_timeout(1200)
            pos=await pg.evaluate("[POS.lat,POS.lng]");ini=await pg.evaluate("MP.init")
            ck("AUD-10","mapa já aberto volta a centralizar quando a posição real chega",abs(pos[0]+23.55)<0.01 and ini==0,f"POS={pos} MP.init={ini}");await c.close()

            # AUD-11 teclado: avatar (seguir) e pino do mapa
            c,pg,errs=await abre()
            ti=await pg.evaluate("document.querySelector('#feed .av').tabIndex")
            await pg.evaluate("document.querySelector('#feed .av b').focus()");await pg.keyboard.press("Enter");await pg.wait_for_timeout(200)
            seg=await pg.evaluate("Object.values(S.seg).some(Boolean)")
            ck("AUD-11","avatar e '+' do feed focáveis e acionáveis por teclado",ti==0 and seg,f"tabIndex={ti} seguiu={seg}")
            await pg.evaluate("go('vExp')");await pg.wait_for_selector('#xMap .pin',state='attached')
            await pg.focus('#xMap .pin');await pg.keyboard.press('Enter');await pg.wait_for_timeout(300)
            ck("AUD-11","Enter em pino do mapa abre o cartão da loja",await pg.evaluate("!!document.querySelector('#mc .mcc')"));await c.close()

            # AUD-12 HTML/atributos adulterados no localStorage são saneados (defesa em profundidade; a CSP já bloqueia a execução)
            c,pg,errs=await abre(init="""localStorage.setItem('pertinho-v2',JSON.stringify({N:[{id:'u1',nome:'<b>x</b>',categoria:'Pizza<img src=x onerror=window.__x=1>',faixa:'<i>',descricao:'d',endereco:'e',horario:'',lat:-22.9,lng:-43.17,cardapio:[['a',1]],fotos:['<u>f</u>']}],S:{}}))""")
            n=await pg.evaluate("N.find(x=>x.id==='u1')")
            ck("AUD-12","categoria/faixa/fotos adulteradas são saneadas ao carregar",n["categoria"]=="Outros" and n["faixa"]=="" and "<" not in "".join(n["fotos"]),n);await c.close()

            # AUD-13 copiar link só diz "copiado" quando copiou
            c,pg,errs=await abre(init="Object.defineProperty(navigator,'clipboard',{value:undefined});Object.defineProperty(navigator,'share',{value:undefined})")
            await pg.click('#feed .p:first-child [data-act="sha"]');await pg.wait_for_timeout(200)
            t=await pg.evaluate("document.getElementById('toast').textContent")
            ck("AUD-13","sem Clipboard API não mostra 'Link copiado'",t!="Link copiado",t);await c.close()

            # AUD-14 limites de entrada e histórico inválido
            c,pg,errs=await abre(init="localStorage.setItem('pertinho-h','{\"x\":1}')")
            await pg.click('#bBusca');await pg.wait_for_timeout(300)
            ck("AUD-14","histórico de busca inválido não quebra a tela de busca",not errs,errs[:1])
            await pg.evaluate("go('vFeed')");await pg.click('#feed .p:first-child [data-act="com"]')
            ck("AUD-14","campo de comentário tem limite de tamanho",await pg.get_attribute('#cI','maxlength')=="200");await c.close()
            await b.close()
    finally: srv.terminate()
    print("\nRESULTADO:","FALHAS "+str(sorted(set(fails))) if fails else "TUDO OK");sys.exit(1 if fails else 0)
asyncio.run(main())
