"""Explorar outro lugar (estado + cidade). Nominatim e Overpass são simulados (sem rede), no formato real das respostas.
Roda: python3 tests/e2e_lugar.py"""
import asyncio,subprocess,time,sys,os,json
from playwright.async_api import async_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOM=[{"lat":"-25.4284","lon":"-49.2733","display_name":"Curitiba, Paraná, Brasil","address":{"city":"Curitiba","state":"Paraná","ISO3166-2-lvl4":"BR-PR"}},
     {"lat":"-22.0","lon":"-47.0","display_name":"Curitiba, São Paulo, Brasil","address":{"town":"Curitiba","state":"São Paulo","ISO3166-2-lvl4":"BR-SP"}}]
OVP={"elements":[{"type":"node","id":1,"lat":-25.429,"lon":-49.272,"tags":{"name":"Pizzaria do Batel","amenity":"restaurant","cuisine":"pizza"}},
                 {"type":"node","id":2,"lat":-25.43,"lon":-49.274,"tags":{"name":"Farmácia Central","amenity":"pharmacy"}}]}
async def main():
    srv=subprocess.Popen(["python3","-m","http.server","8170","--directory",ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1);fails=[]
    def ck(nome,ok,det=""):
        print(("OK   " if ok else "FALHA")+" "+nome,det)
        if not ok: fails.append(nome)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch();c=await b.new_context(viewport={"width":390,"height":800},permissions=[]);pg=await c.new_page()
            errs=[];pg.on("pageerror",lambda e:errs.append(str(e)))
            async def nom(r):await r.fulfill(json=NOM,headers={"access-control-allow-origin":"*"})
            async def ovp(r):await r.fulfill(json=OVP,headers={"access-control-allow-origin":"*"})
            await pg.route("**/nominatim.openstreetmap.org/**",nom);await pg.route("**/overpass-api.de/**",ovp)
            await pg.goto("http://localhost:8170/index.html");await pg.wait_for_timeout(1500)
            ck("sem faixa de chips no feed",await pg.evaluate("document.getElementById('chips').children.length===0"))
            ck("Filtro sem cor quando não há filtro",not await pg.evaluate("document.getElementById('nDesc').classList.contains('fa')"))
            await pg.click('nav .plus');ck("Explorar mostra o local",(await pg.inner_text('#xPl')).strip().startswith("Perto de você"))
            await pg.click('#xPl');await pg.select_option('#plU','PR');await pg.fill('#plC','Curitiba');await pg.wait_for_selector('#plR [data-k]')
            ops=await pg.eval_on_selector_all('#plR [data-k]',"e=>e.map(x=>x.textContent.trim())")
            ck("filtra pelo estado escolhido (só Curitiba, PR)",len(ops)==1 and "PR" in ops[0],str(ops))
            await pg.click('#plR [data-k="0"]');await pg.wait_for_timeout(1200)
            ck("Filtro muda de cor com outra cidade",await pg.evaluate("document.getElementById('nDesc').classList.contains('fa')"))
            nomes=await pg.evaluate("[...new Set(posts().map(p=>p.n.nome))]")
            ck("mostra comércios do local",any("Batel" in n for n in nomes),str(nomes))
            ck("oculta comércios de exemplo do Rio",not any(n["id"].startswith("d") for n in await pg.evaluate("posts().map(p=>({id:p.n.id}))")))
            await pg.reload();await pg.wait_for_timeout(1500)
            ck("lembra o local e a cor após recarregar",await pg.evaluate("S.place&&S.place.n==='Curitiba, PR'&&document.getElementById('nDesc').classList.contains('fa')"))
            await pg.click('#nDesc');ck("Filtro mostra o local",'Curitiba' in await pg.inner_text('#sh'))
            await pg.click('#fLimpa');await pg.wait_for_timeout(1200)
            ck("Limpar filtros volta para minha localização",await pg.evaluate("!S.place&&!document.getElementById('nDesc').classList.contains('fa')"))
            ck("comércios de exemplo voltam",await pg.evaluate("posts().some(p=>p.n.id[0]==='d')"))
            await pg.click('#nDesc');await pg.click('#cP [data-c="Pizza"]');await pg.keyboard.press("Escape")
            ck("Filtro muda de cor com categoria",await pg.evaluate("document.getElementById('nDesc').classList.contains('fa')"))
            cor=await pg.evaluate("getComputedStyle(document.getElementById('nDesc')).color");ck("cor diferente das outras abas",cor!=await pg.evaluate("getComputedStyle(document.querySelector('nav [data-go=vPer]')).color"),cor)
            await pg.click('#nDesc');await pg.click('#fLimpa');await pg.keyboard.press("Escape")
            ck("limpar categoria remove a cor",not await pg.evaluate("document.getElementById('nDesc').classList.contains('fa')"))
            await pg.evaluate("S.raio=25;feed()");ck("raio diferente também colore",await pg.evaluate("document.getElementById('nDesc').classList.contains('fa')"))
            await pg.click('#bBusca');ck("Busca tem atalho 'Explorar cidade'",await pg.is_visible('#bsC .plc'))
            ck("sem erros JS",not errs,str(errs));await b.close()
    finally: srv.terminate()
    print("\nRESULTADO:","FALHAS "+str(fails) if fails else "TUDO OK");sys.exit(1 if fails else 0)
asyncio.run(main())
