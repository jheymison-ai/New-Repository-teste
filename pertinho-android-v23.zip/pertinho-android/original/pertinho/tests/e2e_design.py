"""v23: design system. Confere tokens, barra do topo sem corte/sobreposição, abas da loja, contraste (WCAG AA) dos botões e
selos nos temas claro e escuro, anel de foco, campo tel estilizado, validação do cadastro (aria-invalid + foco), estado de
carregamento, toast com tipo, Explorar sem texto cortado e movimento reduzido. Sem rede (tudo externo é bloqueado).
Roda: python3 tests/e2e_design.py"""
import asyncio,subprocess,time,os
from playwright.async_api import async_playwright
ROOT=os.environ.get("PERTINHO_ROOT") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT=8198;URL=f"http://localhost:{PORT}/index.html"
# razão de contraste WCAG a partir de duas cores "rgb(...)"/"rgba(...)" (alfa ignorado: usamos só superfícies opacas)
JS_CR="""(a,b)=>{const p=c=>c.match(/[\\d.]+/g).slice(0,3).map(Number),L=c=>{const[r,g,b]=p(c).map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4});return .2126*r+.7152*g+.0722*b};
const x=L(a),y=L(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)}"""
async def main():
    srv=subprocess.Popen(["python3","-m","http.server",str(PORT),"--directory",ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1);fails=[]
    def ck(nome,ok,det=""):
        print(("OK    " if ok else "FALHA ")+nome+((" -> "+str(det)) if det!="" else ""))
        if not ok: fails.append(nome)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch()
            async def novo(w=390,h=800,scheme="dark",motion="no-preference",delay=0):
                c=await b.new_context(viewport={"width":w,"height":h},color_scheme=scheme,reduced_motion=motion);pg=await c.new_page();errs=[];pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
                async def rota(r):
                    u=r.request.url
                    if not u.startswith(f"http://localhost:{PORT}"):
                        if delay and "nominatim" in u:
                            await asyncio.sleep(delay)
                            return await r.fulfill(status=200,content_type="application/json",body="[]")
                        return await r.abort()
                    await r.continue_()
                await pg.route("**/*",rota);await pg.goto(URL);await pg.wait_for_timeout(1300);return c,pg,errs
            cr=lambda pg,a,b:pg.evaluate(f"({JS_CR})('{a}','{b}')")

            # 1) tokens centralizados e carregados
            c,pg,errs=await novo()
            tk=await pg.evaluate("['--sp-4','--rad-md','--brand-strong','--tap','--focus','--ink','--font'].map(k=>getComputedStyle(document.documentElement).getPropertyValue(k).trim())")
            ck("tokens.css carregado (espaçamento, raio, marca, alvo de toque, foco, tinta, fonte)",all(tk),tk)
            ck("--tap = 44px",tk[3]=="44px")

            # 2) barra do topo: nenhuma aba cortada nem sob o botão de busca (>=360 px); em 320 rola de lado, sem estourar a tela
            for w in (320,360,375,390,414,480):
                c2,pg2,_=await novo(w)
                r=await pg2.evaluate("""(()=>{const tb=document.querySelector('#top .tb'),bs=document.getElementById('bBusca').getBoundingClientRect(),bt=[...document.querySelectorAll('#top [data-t]')],
                  last=bt[bt.length-1].getBoundingClientRect(),cut=bt.some(x=>x.getBoundingClientRect().right>tb.getBoundingClientRect().right+1);
                  return{overlap:tb.getBoundingClientRect().right>bs.left+1,cut,scroll:tb.scrollWidth>tb.clientWidth+1,page:document.documentElement.scrollWidth>innerWidth}})()""")
                ok=(not r["page"]) and (w<360 and (not r["overlap"]) or (not r["overlap"] and not r["cut"]))
                ck(f"barra do topo em {w}px: sem sobreposição com a busca e sem rolagem da página"+("" if w>=360 else " (rola de lado se preciso)"),ok,r);await c2.close()

            # 3) abas da loja: as 5 cabem em 390 px
            await pg.evaluate("abre('d1')");await pg.wait_for_timeout(400)
            r=await pg.evaluate("[...document.querySelectorAll('#vNeg .tabs button')].map(x=>{const q=x.getBoundingClientRect();return[Math.round(q.left),Math.round(q.right)]})")
            ck("abas da loja: as 5 visíveis dentro de 390 px",len(r)==5 and all(a>=0 and bb<=390 for a,bb in r),r)
            ck("Seguir é a ação principal (destacada) e vira secundária ao seguir",await pg.evaluate("document.getElementById('bS').classList.contains('cta')") and (await pg.click('#bS') or True) and not await pg.evaluate("document.getElementById('bS').classList.contains('cta')"))
            ck("botão Seguir expõe aria-pressed",await pg.evaluate("document.getElementById('bS').getAttribute('aria-pressed')")=="true")

            # 4) contraste AA nos dois temas
            for sch in ("dark","light"):
                c3,pg3,_=await novo(scheme=sch)
                await pg3.evaluate("go('vAdd')");await pg3.wait_for_timeout(300)
                bt=await pg3.evaluate("(()=>{const s=getComputedStyle(document.getElementById('bSalva'));return[s.backgroundColor,s.color]})()")
                ck(f"[{sch}] botão primário: contraste >= 4,5",await cr(pg3,bt[0],bt[1])>=4.5,round(await cr(pg3,bt[0],bt[1]),2))
                bd=await pg3.evaluate("(()=>{const e=document.createElement('i');e.className='nd';e.textContent='2';document.body.appendChild(e);const s=getComputedStyle(e);return[s.backgroundColor,s.color]})()")
                ck(f"[{sch}] selo de aviso (branco sobre marca): >= 4,5",await cr(pg3,bd[0],bd[1])>=4.5,round(await cr(pg3,bd[0],bd[1]),2))
                tx=await pg3.evaluate("(()=>{const r=getComputedStyle(document.documentElement),e=document.createElement('p');e.className='bgo';e.style.cssText='position:absolute';document.getElementById('vAdd').appendChild(e);return[getComputedStyle(e).color,r.getPropertyValue('--bg').trim(),getComputedStyle(e).backgroundColor]})()")
                bgc=await pg3.evaluate("getComputedStyle(document.querySelector('#vAdd .body')).backgroundColor")
                ck(f"[{sch}] texto de marca sobre o fundo: >= 4,5",await cr(pg3,tx[0],bgc)>=4.5,round(await cr(pg3,tx[0],bgc),2))
                mu=await pg3.evaluate("(()=>{const e=document.querySelector('#vAdd label');return getComputedStyle(e).color})()")
                ck(f"[{sch}] texto secundário (rótulos): >= 4,5",await cr(pg3,mu,bgc)>=4.5,round(await cr(pg3,mu,bgc),2))
                er=await pg3.evaluate("getComputedStyle(document.getElementById('fErr')).color")
                ck(f"[{sch}] cor de erro: >= 4,5",await cr(pg3,er,bgc)>=4.5,round(await cr(pg3,er,bgc),2))
                await c3.close()

            # 5) foco visível (anel azul de 2 px) em botões, e campo tel igual aos outros
            await pg.evaluate("go('vAdd')");await pg.wait_for_timeout(300)
            await pg.focus('#bSalva');await pg.keyboard.press('Shift+Tab');await pg.keyboard.press('Tab')
            f=await pg.evaluate("(()=>{const s=getComputedStyle(document.activeElement);return[document.activeElement.id,s.outlineWidth,s.outlineStyle,s.outlineColor]})()")
            fc=await pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--focus').trim()")
            ck("anel de foco de 2 px visível ao navegar por teclado",f[1]=="2px" and f[2]=="solid",f)
            t=await pg.evaluate("(()=>{const a=getComputedStyle(document.getElementById('fWa')),n=getComputedStyle(document.getElementById('fNome'));return[a.borderRadius===n.borderRadius,a.borderTopWidth===n.borderTopWidth,a.paddingLeft===n.paddingLeft,parseFloat(a.height)>=44]})()")
            ck("campo de WhatsApp (type=tel) tem o mesmo estilo e altura >= 44 px",all(t),t)

            # 6) validação do cadastro: erro no campo certo, foco nele, mensagem com orientação e leitura por leitor de tela
            await pg.click('#bSalva');await pg.wait_for_timeout(200)
            v=await pg.evaluate("[document.getElementById('fNome').getAttribute('aria-invalid'),document.activeElement.id,document.getElementById('fErr').textContent,document.getElementById('fErr').getAttribute('role')]")
            ck("nome vazio: campo marcado inválido, foco nele e mensagem com exemplo",v[0]=="true" and v[1]=="fNome" and "ex.:" in v[2] and v[3]=="alert",v)
            await pg.fill('#fNome','Loja Design');await pg.click('#bSalva');await pg.wait_for_timeout(200)
            v=await pg.evaluate("[document.getElementById('fNome').getAttribute('aria-invalid'),document.getElementById('fEnd').getAttribute('aria-invalid'),document.activeElement.id,document.getElementById('fErr').textContent]")
            ck("endereço vazio: só o endereço fica inválido, com foco e orientação (CEP)",v[0] is None and v[1]=="true" and v[2]=="fEnd" and "CEP" in v[3],v)
            await pg.type('#fEnd','R');ck("digitar limpa o estado inválido",await pg.evaluate("document.getElementById('fEnd').getAttribute('aria-invalid')") is None)
            await pg.fill('#fEnd','Rua A, 1');await pg.click('#bSalva');await pg.wait_for_timeout(900)
            ck("publicar com sucesso: botão volta ao normal (sem carregando nem desabilitado)",await pg.evaluate("(()=>{const x=document.getElementById('bSalva');return!x.disabled&&!x.classList.contains('is-loading')})()"))
            ck("sem aria-invalid residual após publicar",await pg.evaluate("document.querySelectorAll('[aria-invalid]').length")==0)

            # 7) toast com tipo e dentro da tela, mesmo com texto longo
            await pg.evaluate("toast('Sem espaço para salvar neste aparelho. Exclua comércios em Perfil › Meus comércios.','err')");await pg.wait_for_timeout(400)
            tt=await pg.evaluate("(()=>{const e=document.getElementById('toast'),r=e.getBoundingClientRect(),a=document.getElementById('app').getBoundingClientRect();return[e.dataset.k,r.left>=a.left,r.right<=a.right,getComputedStyle(e,'::before').backgroundColor]})()")
            ck("toast de erro tem tipo, ponto colorido e não sai da tela",tt[0]=="err" and tt[1] and tt[2] and tt[3]!="rgba(0, 0, 0, 0)",tt)

            # 8) Explorar: saudação e local sem corte
            await pg.evaluate("go('vExp')");await pg.wait_for_timeout(500)
            x=await pg.evaluate("(()=>{const s=document.querySelector('#xPl span'),h=document.querySelector('.xh h2');return[s.scrollWidth<=s.clientWidth,h.scrollWidth<=h.clientWidth,document.getElementById('xPl').getBoundingClientRect().width>300]})()")
            ck("Explorar: saudação e local aparecem inteiros (pílula em linha própria)",all(x),x)
            await c.close()

            # 9) carregamento: busca de cidade mostra indicador com role=status enquanto espera
            c4,pg4,_=await novo(delay=1.2)
            await pg4.evaluate("lugar()");await pg4.fill('#plC','Niterói');await pg4.wait_for_timeout(700)
            ld=await pg4.evaluate("(()=>{const e=document.querySelector('#plR .ld');return e?[e.getAttribute('role'),getComputedStyle(e,'::before').animationName]:null})()")
            ck("busca de cidade: indicador de carregamento acessível (role=status, animado)",bool(ld) and ld[0]=="status" and ld[1]!="none",ld)
            await pg4.wait_for_timeout(1500)
            ck("sem resultado: mensagem explica o que fazer",await pg4.evaluate("document.querySelector('#plR .note')?.textContent.includes('conexão')"))
            await c4.close()

            # 10) movimento reduzido: fundos animados parados
            c5,pg5,_=await novo(motion="reduce")
            an=await pg5.evaluate("getComputedStyle(document.querySelector('#feed .sc')).animationName")
            ck("prefers-reduced-motion: fundo animado do feed parado",an=="none",an);await c5.close()

            # 11) sem erros JS
            ck("sem erros de JavaScript",not errs,errs)
            await b.close()
    finally: srv.terminate()
    print("\nRESULTADO:","TUDO OK" if not fails else "FALHAS: "+", ".join(fails));raise SystemExit(1 if fails else 0)
asyncio.run(main())
