# Pertinho v23 — relatório de design (Uber + TikTok)

## 1. Diagnóstico inicial
App em HTML/CSS/JS puro (sem build, sem npm), PWA, 6 telas principais (feed, Explorar, busca, loja, perfil/avisos, cadastro) + gavetas. Identidade: feed de vídeos curto estilo TikTok, rosa→laranja sobre fundo escuro, com tema claro automático. Regras de negócio, APIs, armazenamento local, login e rotas **não foram alteradas**: as mudanças são de CSS, marcação e mensagens/estados de interface. Linha de base: os 5 testes da v22 passavam (smoke, lugar, responsive, explorar, auditoria).

## 2. Problemas encontrados (todos verificados em captura ou medição)
1. **Barra do topo do feed (390 px):** a aba "Mapa" ficava cortada e coberta pelo botão de busca. Havia 5 camadas de CSS sobrepostas para a mesma barra.
2. **Contraste:** texto rosa sobre fundo claro 3,39:1 e selo de aviso (branco sobre rosa) 3,39:1, ambos abaixo de 4,5:1 (AA).
3. **Foco:** o anel de foco era branco, invisível no tema claro.
4. **Campo de WhatsApp** (`type=tel`) sem nenhum estilo de campo.
5. **Explorar:** "Olá, Visitante!" e "Perto de você" cortados com reticências; cabeçalho muito saturado competindo com o mapa.
6. **Loja:** "Seguir" (ação principal) parecia igual a "Voltar"; rótulos das abas espremidos.
7. **Cadastro:** erro genérico em texto solto, sem marcar o campo nem levar o foco; botão sem estado de carregamento.
8. **Toasts** de uma linha só, sem tipo, podiam sair da tela com texto longo.
9. **Consistência:** cores e espaços repetidos como valores literais; 23 estilos inline no JS; CSS de chips/clima que nunca aparece.

## 3. Melhorias de design
- **Uber:** botão primário sólido e neutro (preto no claro, branco no escuro); secundário em superfície; uma ação principal por tela; "Seguir" destacado e vira secundário ao seguir; Explorar com cabeçalho neutro, local em linha própria como "campo de origem"; erros que dizem como resolver ("…ou digite o CEP para preenchê-lo").
- **TikTok:** destaque rosa/laranja só onde importa (curtir, aba/filtro ativo, botão central, avatar); ciano de apoio no botão de editar avatar; barra do topo com abas e lupa; feedback imediato (toast tipado, spinner em botão e em busca).
- Identidade própria preservada (rosa→laranja do Pertinho); nenhum logotipo ou tela de terceiros copiado.

## 4. Sistema de cores
Tokens centralizados em `css/tokens.css` (veja `DESIGN-SYSTEM.md`). Novos: `--ink/--on-ink`, `--brand-strong`, `--brand-text`, `--focus`, semânticas `--ok/--warn/--err/--info`, escalas `--sp-*`, `--rad-*`, `--sh-*`, `--fs-*`, `--tap`. Contrastes medidos nos dois temas (todos ≥ 4,5:1): botão primário 19,6 / 19,0; selo 5,2; texto de marca 6,7 / 5,2; texto secundário 7,1 / 5,3; erro 7,2 / 5,6 (escuro / claro).

## 5. Posicionamento e responsividade
Barra do topo = abas rolantes + lupa fixa (sem sobreposição); "de você" some abaixo de 430 px e a fonte/espaço diminuem abaixo de 400/380/340 px. Abas da loja cabem em 390 px e rolam de lado quando faltar espaço. Explorar reorganizado em duas linhas. Alvos ≥ 44 px, `--sat/--sab` mantidos. Os 9 tamanhos do teste de responsividade (320×568 a 1440×900, paisagem e tablet) seguem sem rolagem horizontal.

## 6. Componentes criados/reaproveitados
Em HTML/CSS/JS puro, "componentes" são classes e funções: `.btn` (+`.w`, `.is-loading`), `.back.cta`, `.ld`, `.lbl`, `.note`, `.sub`, `toast(texto, tipo)`, `bad()` (erro de campo), `topOn()` (abas do feed com `aria-pressed`). Inline: 23 → 12 (os restantes são valores dinâmicos: degradê por categoria, posição de pino, largura de barra). Usos de `var(--…)`: 144 → 235; cores literais: 142 → 113 (a maioria é branco/preto sobre vídeo e sombras, que não mudam com o tema).

## 7. Funcionalidades preservadas e testadas
Curtir, salvar, seguir, comentar, compartilhar, duplo toque, pausar, som, abas do feed, busca, filtro (raio/categoria), mapa e pinos, Explorar, escolher estado/cidade, perfil da loja (vídeos, cardápio, fotos, avaliações, local), perfil do usuário, avisos, cadastro/publicação, exclusão, offline, CSP, tela de recuperação, estado salvo inválido.

## 8. Testes executados (Chromium 141 via Playwright, sem rede; resultados reais)
| Teste | Resultado |
|---|---|
| `e2e_smoke.py` | TUDO OK |
| `e2e_lugar.py` | TUDO OK |
| `e2e_responsive.py` (9 resoluções) | TUDO OK |
| `e2e_explorar.py` | TUDO OK |
| `e2e_auditoria.py` | TUDO OK |
| `e2e_design.py` (**novo**, 34 verificações: tokens; topo em 320–480 px; abas da loja; contraste AA em claro e escuro; foco; campo tel; validação; carregamento; toast; Explorar; movimento reduzido; erros JS) | TUDO OK |

Durante o desenvolvimento o teste novo apontou 2 falhas reais (abas cortadas em 360 e 375 px), corrigidas. Contra a v22 original ele falha na verificação de tokens e aborta na barra do topo (a estrutura nova não existe lá), então confirma só parte das correções; as demais foram vistas nas capturas antes/depois.

## 9. Pendências e limitações (não declaro "perfeito")
- **Só Chromium**, fonte de teste mais larga que Inter/SF; Safari, Firefox e aparelhos reais **não testados**. Em 320 px a barra do topo rola de lado (aba "Mapa" fora da vista até rolar).
- Contraste de **texto sobre vídeo/foto** (legenda, ações) não foi medido (depende do conteúdo); o degradê escuro existente foi mantido.
- No desktop o app continua como moldura de celular (decisão anterior mantida); não há layout em colunas.
- O toast aparece sempre sob a barra do topo e pode cobrir conteúdo por ~2 s em outras telas.
- Mensagens de erro de rede: a API devolve lista vazia tanto para "sem resultado" quanto para falha, então a mensagem cobre os dois casos ("…ou verifique sua conexão").
- Pendências da v21/v22 **inalteradas**: raio fixo de 3 km nos comércios reais, Nominatim com autocomplete, login Google só de demonstração, tudo que depende de backend. Sem medição de desempenho (CPU/memória/rede).
- `sw.js` VERSION = `pertinho-v23` (e `css/tokens.css` entrou no cache do shell); usuários com a v22 instalada recebem a nova versão na próxima abertura online.

## 10. Como executar
```
python3 -m http.server          # na pasta pertinho/ ; abra http://localhost:8000
pip install -r tests/requirements.txt && playwright install chromium
python3 tests/e2e_smoke.py && python3 tests/e2e_lugar.py && python3 tests/e2e_responsive.py \
 && python3 tests/e2e_explorar.py && python3 tests/e2e_auditoria.py && python3 tests/e2e_design.py
```
Não há build nem dependências npm. Nenhuma credencial é necessária (login Google segue opcional via `CFG.GOOGLE_CLIENT_ID`).
