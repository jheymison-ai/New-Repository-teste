# Pertinho v23 — aplicativo Android (APK)

Conversão do **Pertinho v23** (HTML/CSS/JS puro) em app Android nativo: uma `Activity` Kotlin com `WebView` que carrega
os arquivos originais **empacotados no APK** (`app/src/main/assets/www`). Não é PWA (sem manifest e sem service worker no app),
não abre navegador para as telas internas e não depende de site hospedado.

## Estrutura
- `original/pertinho/` — projeto v23 **intacto** (fonte da verdade; inclui testes e documentos originais).
- `scripts/prepare_web.py` — gera `app/src/main/assets/www` a partir do original. Só 3 mudanças (verificadas por diff):
  remove `<link rel="manifest">`, remove o registro do service worker em `js/app.js` e adiciona `js/android-bridge.js`.
- `scripts/android-bridge.js` — botão Voltar do Android e "Compartilhar" (sem `addJavascriptInterface`).
- `app/` — projeto Android (Kotlin, Gradle). `UrlPolicy.kt` (regras de navegação, testadas), `MainActivity.kt` (WebView, arquivos, localização, Voltar, ciclo de vida).
- `.github/workflows/android.yml` — compila na nuvem, testa e publica o APK.
- `docs/` — relatório, resultados dos testes e capturas.

Identificador de pacote: **`br.com.pertinho.app`** (o projeto original não tinha um). Versão: 23.0.0 (código 2300). minSdk 24, targetSdk 35.

## Compilar sem Android SDK (pelo celular): GitHub Actions
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (a raiz do repositório deve conter `app/`, `scripts/`, `original/`, `.github/`).
2. Aba **Actions** → workflow **Pertinho Android** (roda a cada envio; ou **Run workflow**).
3. Ao terminar, abra a execução → **Artifacts** → baixe **pertinho-debug-apk** (`app-debug.apk`) e os **relatorios-de-teste**.
4. No Android: abra o APK baixado e permita "instalar apps desconhecidos" para o navegador/gerenciador de arquivos.

## Compilar no computador
`./build.sh` (JDK 17 + Android SDK 35 + Gradle 8.9+). Não há `gradlew` no pacote (não foi possível baixar o wrapper sem rede);
para criar: `gradle wrapper --gradle-version 8.9`.

## Atualizar o app
Instale o novo APK por cima do antigo. Os dados (curtidas, lojas, vídeos postados) ficam no armazenamento do WebView e são mantidos
**se a nova versão for assinada com a mesma chave** e tiver o mesmo `applicationId`. APK de depuração e de lançamento têm chaves diferentes:
não misture (desinstale um antes de instalar o outro, perdendo os dados locais).
Para novas versões, aumente `versionCode`/`versionName` em `app/build.gradle.kts`.

## APK assinado de lançamento
1. Gere uma chave (guarde o arquivo e as senhas fora do repositório):
   `keytool -genkeypair -v -keystore pertinho.jks -alias pertinho -keyalg RSA -keysize 2048 -validity 10000`
2. `base64 -w0 pertinho.jks` e cadastre em *Settings → Secrets and variables → Actions*:
   `PERTINHO_KEYSTORE_B64` (o texto base64), `PERTINHO_KEYSTORE_PASSWORD`, `PERTINHO_KEY_ALIAS`, `PERTINHO_KEY_PASSWORD`.
3. Rode o workflow: com os segredos presentes ele gera também o artefato **pertinho-release-apk**.
   Localmente: exporte `PERTINHO_KEYSTORE_PATH`, `PERTINHO_KEYSTORE_PASSWORD`, `PERTINHO_KEY_ALIAS`, `PERTINHO_KEY_PASSWORD` e rode `gradle :app:assembleRelease`.
4. Para a Play Store é preciso AAB (`:app:bundleRelease`) e conta de desenvolvedor.

## Testes
- Web: `bash scripts/run_web_tests.sh` (6 e2e originais sobre o pacote) e `python3 scripts/e2e_apk_origin.py` (origem real do APK, offline, Voltar, compartilhar, comparação visual). Requer `pip install playwright pillow` e `playwright install chromium`.
- Android: `gradle :app:testDebugUnitTest` (regras de URL/Range) e `gradle :app:connectedDebugAndroidTest` (emulador/dispositivo; o workflow roda num emulador API 34).
