#!/usr/bin/env bash
# Roda os 6 testes e2e originais do Pertinho v23 (Playwright) contra o www empacotado no APK
# (já sem service worker/manifest e com a ponte Android). Sai com código != 0 se algum falhar.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$ROOT/tmp/webtest"; mkdir -p "$ROOT/tmp"; LOG="$ROOT/tmp/web-tests.log"; : > "$LOG"
rm -rf "$TMP"; mkdir -p "$TMP"
python3 "$ROOT/scripts/prepare_web.py" "$TMP/pertinho" >/dev/null
cp -r "$ROOT/original/pertinho/tests" "$TMP/pertinho/tests"
pip install -q -r "$TMP/pertinho/tests/requirements.txt" >/dev/null 2>&1
python3 -m playwright install --with-deps chromium >/dev/null 2>&1 || python3 -m playwright install chromium >/dev/null 2>&1
fail=0
for t in smoke lugar responsive explorar design auditoria; do
  echo "=== e2e_$t ===" | tee -a "$LOG"
  python3 "$TMP/pertinho/tests/e2e_$t.py" 2>&1 | tee -a "$LOG"; rc=${PIPESTATUS[0]}
  echo "--- e2e_$t: código de saída $rc" | tee -a "$LOG"
  [ "$rc" -ne 0 ] && fail=1
done
exit $fail
