#!/usr/bin/env python3
"""Gera app/src/main/assets/www a partir de original/pertinho (que nunca é alterado).
Mudanças aplicadas (todas verificadas; o script falha se algum padrão não for encontrado):
  1. não copia sw.js, manifest.webmanifest, tests/ e *.md  (sem PWA no APK)
  2. index.html: remove <link rel="manifest"> e adiciona js/android-bridge.js depois de js/app.js
  3. js/app.js: remove o registro do service worker
Uso: python3 scripts/prepare_web.py [destino]"""
import os, re, shutil, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "original", "pertinho")
DST = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "app", "src", "main", "assets", "www")
SKIP_FILES = {"sw.js", "manifest.webmanifest"}
SKIP_DIRS = {"tests"}

if os.path.isdir(DST): shutil.rmtree(DST)
for d, ds, fs in os.walk(SRC):
    ds[:] = [x for x in ds if not (d == SRC and x in SKIP_DIRS)]
    for f in fs:
        if (d == SRC and (f in SKIP_FILES or f.endswith(".md"))): continue
        s = os.path.join(d, f); t = os.path.join(DST, os.path.relpath(s, SRC))
        os.makedirs(os.path.dirname(t), exist_ok=True); shutil.copy2(s, t)

def patch(path, fn):
    p = os.path.join(DST, path); a = open(p, encoding="utf-8").read(); b = fn(a)
    if a == b: sys.exit(f"ERRO: nenhuma mudança aplicada em {path}")
    open(p, "w", encoding="utf-8").write(b)

patch("index.html", lambda t: re.sub(r'<link rel="manifest" href="manifest.webmanifest">\n', "", t))
patch("index.html", lambda t: t.replace('<script src="js/app.js"></script>', '<script src="js/app.js"></script>\n<script src="js/android-bridge.js"></script>'))
patch("js/app.js", lambda t: re.sub(r'if\("serviceWorker" in navigator&&/\^https\?:\$/\.test\(location\.protocol\)\)navigator\.serviceWorker\.register\("sw\.js"\)\.catch\(\(\)=>\{\}\);\n?', "", t))
shutil.copy2(os.path.join(ROOT, "scripts", "android-bridge.js"), os.path.join(DST, "js", "android-bridge.js"))

html = open(os.path.join(DST, "index.html"), encoding="utf-8").read(); app = open(os.path.join(DST, "js", "app.js"), encoding="utf-8").read()
assert "manifest" not in html and "serviceWorker" not in app and "android-bridge.js" in html
print("www gerado em", DST, "-", sum(len(f) for _, _, f in os.walk(DST)), "arquivos")
