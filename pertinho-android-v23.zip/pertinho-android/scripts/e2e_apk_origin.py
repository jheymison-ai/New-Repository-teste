#!/usr/bin/env python3
"""Teste do pacote do APK na ORIGEM REAL do app (https://appassets.androidplatform.net/assets/www/),
simulando o WebViewAssetLoader: os arquivos de app/src/main/assets/www são servidos por page.route,
SEM rede externa (todo o resto é bloqueado). Cobre: abertura offline, ausência de PWA/service worker,
CSP, navegação, botão Voltar (ponte), compartilhar (ponte), persistência após recarregar e rolagem horizontal.
Também gera capturas lado a lado (original via http.server x APK) e a diferença de pixels."""
import json, mimetypes, os, subprocess, sys, time
from PIL import Image, ImageChops
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WWW = os.path.join(ROOT, "app", "src", "main", "assets", "www")
ORIG = os.path.join(ROOT, "original", "pertinho")
OUT = os.path.join(ROOT, "docs", "capturas"); os.makedirs(OUT, exist_ok=True)
H = "https://appassets.androidplatform.net"; BASE = H + "/assets/www/"
mimetypes.add_type("image/svg+xml", ".svg"); mimetypes.add_type("text/javascript", ".js")
res = []
def ok(name, cond, extra=""):
    res.append((name, bool(cond), str(extra)[:150])); print(("OK   " if cond else "FALHA"), name, str(extra)[:150])

def serve(route):
    p = route.request.url.split("?")[0]
    if not p.startswith(BASE): return route.abort()
    f = os.path.join(WWW, p[len(BASE):] or "index.html")
    if not os.path.isfile(f): return route.fulfill(status=404, body="")
    route.fulfill(status=200, body=open(f, "rb").read(), headers={"Content-Type": mimetypes.guess_type(f)[0] or "application/octet-stream", "Accept-Ranges": "bytes"})

def mkctx(b, w=390, h=844):
    c = b.new_context(viewport={"width": w, "height": h}, has_touch=False)
    c.route("**/*", lambda r: serve(r) if r.request.url.startswith(H) else r.abort())   # só o pacote local; rede externa indisponível
    return c

with sync_playwright() as p:
    b = p.chromium.launch()
    c = mkctx(b); pg = c.new_page()
    errs, csp, failed, shared = [], [], [], []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("console", lambda m: csp.append(m.text[:140]) if ("Content Security" in m.text or "Refused" in m.text) else None)
    pg.on("requestfailed", lambda r: shared.append(r.url) if r.url.startswith("pertinho-share:") else (failed.append(r.url[-60:]+" "+str(r.failure)) if (r.url.startswith(H) and "ERR_ABORTED" not in str(r.failure)) else None))
    pg.goto(BASE + "index.html"); pg.wait_for_timeout(2500)

    ok("abre pela origem do APK sem rede", pg.evaluate("!!window.__pertinho"))
    ok("barra inferior com 5 botões", pg.evaluate("document.querySelectorAll('nav button').length") == 5)
    ok("feed com vídeos (dados de exemplo)", pg.evaluate("document.querySelectorAll('#feed .p').length") > 0, pg.evaluate("document.querySelectorAll('#feed .p').length"))
    ok("sem <link rel=manifest> (não é PWA)", pg.evaluate("document.querySelector('link[rel=manifest]')===null"))
    ok("sem service worker registrado", pg.evaluate("navigator.serviceWorker.getRegistrations().then(r=>r.length)") == 0)
    ok("sem erros JS", not errs, errs)
    ok("sem violação de CSP", not csp, csp)
    ok("nenhum arquivo local faltando (404)", not failed, failed)

    # navegação entre telas
    for nome, sel, vid in [("Explorar", "nav [data-go=vExp]", "vExp"), ("Avisos", "nav [data-go=vNot]", "vNot"), ("Perfil", "nav [data-go=vPer]", "vPer"), ("Início", "nav [data-go=vFeed]", "vFeed")]:
        pg.click(sel); pg.wait_for_timeout(300)
        ok(f"navega: {nome}", pg.evaluate(f"document.getElementById('{vid}').classList.contains('on')"))

    # botão Voltar do Android (window.__pertinhoBack)
    ok("Voltar no Início => false (app sai)", pg.evaluate("window.__pertinhoBack()") is False)
    pg.click("nav [data-go=vPer]"); pg.wait_for_timeout(200)
    ok("Voltar em Perfil => volta ao Início", pg.evaluate("window.__pertinhoBack()") is True and pg.evaluate("document.getElementById('vFeed').classList.contains('on')"))
    pg.click("#nDesc"); pg.wait_for_timeout(300)
    ok("Voltar fecha o painel de filtro", pg.evaluate("document.getElementById('sh').classList.contains('on')") and pg.evaluate("window.__pertinhoBack()") is True and not pg.evaluate("document.getElementById('sh').classList.contains('on')"))
    pg.click("#feed .p:first-child [data-act=avatar], #feed .p:first-child .av"); pg.wait_for_timeout(500)
    em_loja = pg.evaluate("document.getElementById('vNeg').classList.contains('on')")
    ok("avatar abre a loja", em_loja)
    if em_loja:
        ok("Voltar da loja volta ao feed", pg.evaluate("window.__pertinhoBack()") is True and pg.evaluate("document.getElementById('vFeed').classList.contains('on')"))
    pg.click("#bBusca"); pg.wait_for_timeout(300)
    ok("busca abre", pg.evaluate("document.getElementById('vBus').classList.contains('on')"))
    ok("Voltar sai da busca", pg.evaluate("window.__pertinhoBack()") is True and not pg.evaluate("document.getElementById('vBus').classList.contains('on')"))

    # compartilhar (ponte): deve gerar navegação pertinho-share://, nunca copiar o endereço interno
    pg.evaluate("navigator.share({title:'Pizzaria Forno Bravo',text:'Olha esse lugar no Pertinho'})"); pg.wait_for_timeout(500)
    ok("navigator.share gera pertinho-share://", len(shared) >= 1 and "Pizzaria" in (shared[0] if shared else "") or any("Pizzaria" in __import__("urllib.parse").parse.unquote(s) for s in shared), shared[:1])

    # persistência e recarga offline
    pg.click("#feed .p:first-child [data-act=like]"); pg.wait_for_timeout(200)
    antes = pg.evaluate("localStorage.getItem('pertinho-v2')")
    c.set_offline(True); pg.reload(); pg.wait_for_timeout(2000)
    ok("recarrega offline a partir do pacote local", pg.evaluate("document.querySelectorAll('#feed .p').length") > 0)
    ok("dados locais persistem após recarregar", pg.evaluate("localStorage.getItem('pertinho-v2')") == antes and antes is not None)
    c.set_offline(False)

    # sem rolagem horizontal em vários tamanhos (inclui tablet e paisagem)
    for w, h in [(320, 568), (360, 640), (390, 844), (412, 915), (844, 390), (768, 1024)]:
        pg.set_viewport_size({"width": w, "height": h}); pg.wait_for_timeout(300)
        ok(f"sem rolagem horizontal {w}x{h}", pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    c.close()

    # ---- comparação visual: original (http.server) x APK (origem local), mesmas condições ----
    srv = subprocess.Popen([sys.executable, "-m", "http.server", "8131"], cwd=ORIG, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1)
    visual = []
    try:
        def shots(ctx, url, tag):
            pg = ctx.new_page(); pg.goto(url); pg.wait_for_timeout(2500)
            pg.add_style_tag(content="*{animation:none!important;transition:none!important}")
            pg.evaluate("document.querySelectorAll('video,audio').forEach(v=>{v.pause();try{v.currentTime=0}catch(e){}})")
            tel = [("feed", None), ("explorar", "nav [data-go=vExp]"), ("avisos", "nav [data-go=vNot]"), ("perfil", "nav [data-go=vPer]")]
            for nome, sel in tel:
                if sel: pg.click(sel); pg.wait_for_timeout(500)
                pg.evaluate("document.querySelectorAll('video,audio').forEach(v=>{v.pause();try{v.currentTime=0}catch(e){}})")
                pg.screenshot(path=f"{OUT}/{tag}-{nome}.png")
            pg.close()
        co = b.new_context(viewport={"width": 390, "height": 844}); co.route("https://**", lambda r: r.abort()); shots(co, "http://localhost:8131/index.html", "original"); co.close()
        ca = mkctx(b); shots(ca, BASE + "index.html", "apk"); ca.close()
        for nome in ["feed", "explorar", "avisos", "perfil"]:
            a = Image.open(f"{OUT}/original-{nome}.png").convert("RGB"); z = Image.open(f"{OUT}/apk-{nome}.png").convert("RGB")
            d = ImageChops.difference(a, z).convert("L").point(lambda v: 255 if v > 24 else 0)
            pct = 100 * sum(1 for v in d.getdata() if v) / (a.width * a.height)
            visual.append((nome, round(pct, 3))); d.save(f"{OUT}/diff-{nome}.png")
            ok(f"visual {nome}: diferença de pixels <= 1%", pct <= 1.0, f"{pct:.3f}%")
    finally:
        srv.terminate()
    b.close()

json.dump({"testes": res, "visual": visual}, open(os.path.join(ROOT, "docs", "resultado-apk-origin.json"), "w"), ensure_ascii=False, indent=1)
falhas = [r for r in res if not r[1]]
print("\nRESULTADO:", "TUDO OK" if not falhas else f"{len(falhas)} FALHA(S)"); sys.exit(1 if falhas else 0)
