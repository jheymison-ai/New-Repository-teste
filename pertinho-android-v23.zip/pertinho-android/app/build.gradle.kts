plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.pertinho.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.pertinho.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 2300
        versionName = "23.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Assinatura de lançamento: só existe se as variáveis de ambiente forem fornecidas (nada de segredo no repositório).
    val ksPath = System.getenv("PERTINHO_KEYSTORE_PATH")
    signingConfigs {
        if (!ksPath.isNullOrBlank()) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("PERTINHO_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("PERTINHO_KEY_ALIAS")
                keyPassword = System.getenv("PERTINHO_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug { }
        release {
            isMinifyEnabled = false
            if (!ksPath.isNullOrBlank()) signingConfig = signingConfigs.getByName("release")
        }
    }

    // mp4/mp3 sem compressão: necessário para servir pedidos Range (seek de vídeo) direto do APK.
    androidResources { noCompress += listOf("mp4", "mp3") }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}
