package br.com.pertinho.app

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Roda em emulador/dispositivo (./gradlew connectedDebugAndroidTest). */
@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    private fun js(sc: ActivityScenario<MainActivity>, code: String): String {
        var out = ""
        val latch = CountDownLatch(1)
        sc.onActivity { a -> a.webView().evaluateJavascript(code) { out = it ?: ""; latch.countDown() } }
        latch.await(5, TimeUnit.SECONDS)
        return out
    }

    private fun waitFor(sc: ActivityScenario<MainActivity>, code: String, ms: Long = 20000): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (js(sc, code) == "true") return true
            Thread.sleep(500)
        }
        return false
    }

    @Test fun carregaInterfaceLocalDoPertinho() {
        ActivityScenario.launch(MainActivity::class.java).use { sc ->
            assertTrue("app não iniciou", waitFor(sc, "!!window.__pertinho"))
            assertTrue("barra inferior ausente", waitFor(sc, "document.querySelectorAll('nav button').length===5"))
            assertTrue("não deve ser PWA", js(sc, "document.querySelector('link[rel=manifest]')===null") == "true")
        }
    }

    @Test fun botaoVoltarNavegaDentroDoApp() {
        ActivityScenario.launch(MainActivity::class.java).use { sc ->
            assertTrue(waitFor(sc, "!!window.__pertinho"))
            js(sc, "document.querySelector('nav [data-go=vPer]').click();true")
            assertTrue(waitFor(sc, "document.getElementById('vPer').classList.contains('on')"))
            assertTrue(js(sc, "window.__pertinhoBack()") == "true")
            assertTrue(waitFor(sc, "document.getElementById('vFeed').classList.contains('on')"))
        }
    }
}
