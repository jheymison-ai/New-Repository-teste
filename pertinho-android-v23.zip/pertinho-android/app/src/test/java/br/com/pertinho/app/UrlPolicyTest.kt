package br.com.pertinho.app

import br.com.pertinho.app.UrlPolicy.Action
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UrlPolicyTest {
    @Test fun urlInicialEhInterna() = assertEquals(Action.LOAD_IN_APP, UrlPolicy.classify(UrlPolicy.START_URL))

    @Test fun linksExternosHttpsAbremFora() {
        assertEquals(Action.OPEN_EXTERNAL, UrlPolicy.classify("https://wa.me/5521999999999"))
        assertEquals(Action.OPEN_EXTERNAL, UrlPolicy.classify("https://www.google.com/maps/search/?api=1&query=-22.9,-43.1"))
        assertEquals(Action.OPEN_EXTERNAL, UrlPolicy.classify("https://www.instagram.com/pertinho"))
    }

    @Test fun esquemasPerigososSaoBloqueados() {
        for (u in listOf("http://example.com", "file:///sdcard/x.html", "content://x/y", "intent://x#Intent;end",
            "javascript:alert(1)", "data:text/html,<b>x</b>", "ftp://x"))
            assertEquals(u, Action.BLOCK, UrlPolicy.classify(u))
    }

    @Test fun dominioParecidoNaoEhInterno() {
        assertEquals(Action.OPEN_EXTERNAL, UrlPolicy.classify("https://appassets.androidplatform.net.evil.com/a"))
        assertEquals(Action.OPEN_EXTERNAL, UrlPolicy.classify("https://evil.com/appassets.androidplatform.net"))
    }

    @Test fun compartilharUsaEsquemaProprio() =
        assertEquals(Action.SHARE, UrlPolicy.classify("pertinho-share://s?text=Ol%C3%A1"))

    @Test fun assetPathSoAceitaWww() {
        assertEquals("www/index.html", UrlPolicy.assetPath("/assets/www/index.html"))
        assertEquals("www/assets/media/video/pizza-1.mp4", UrlPolicy.assetPath("/assets/www/assets/media/video/pizza-1.mp4"))
        assertNull(UrlPolicy.assetPath("/assets/www/../secret"))
        assertNull(UrlPolicy.assetPath("/assets/other/x"))
        assertNull(UrlPolicy.assetPath("/index.html"))
        assertNull(UrlPolicy.assetPath(null))
    }

    @Test fun rangeValido() {
        assertEquals(0L to 99L, UrlPolicy.parseRange("bytes=0-99", 1000))
        assertEquals(500L to 999L, UrlPolicy.parseRange("bytes=500-", 1000))
        assertEquals(900L to 999L, UrlPolicy.parseRange("bytes=-100", 1000))
        assertEquals(0L to 999L, UrlPolicy.parseRange("bytes=0-5000", 1000))
    }

    @Test fun rangeInvalido() {
        assertNull(UrlPolicy.parseRange(null, 1000))
        assertNull(UrlPolicy.parseRange("bytes=2000-3000", 1000))
        assertNull(UrlPolicy.parseRange("bytes=5-2", 1000))
        assertNull(UrlPolicy.parseRange("bytes=0-1,5-9", 1000))
        assertNull(UrlPolicy.parseRange("items=0-1", 1000))
        assertNull(UrlPolicy.parseRange("bytes=0-1", 0))
    }

    @Test fun mime() {
        assertEquals("video/mp4", UrlPolicy.mimeForMedia("www/a.MP4"))
        assertEquals("audio/mpeg", UrlPolicy.mimeForMedia("www/a.mp3"))
        assertNull(UrlPolicy.mimeForMedia("www/a.js"))
    }
}
