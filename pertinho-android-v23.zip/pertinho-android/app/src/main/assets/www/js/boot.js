/* Pertinho — recuperação de falha de carregamento: se um script não chegar (rede ou servidor local instável)
   ou o app não terminar de iniciar, mostra uma tela com "Tentar de novo" em vez de uma tela vazia. */
(function(){const show=()=>{if(window.__pertinho||document.getElementById("bootErr")||!document.body)return;
const d=document.createElement("div"),b=document.createElement("b"),p=document.createElement("p"),k=document.createElement("button");d.id="bootErr";d.setAttribute("role","alert");
b.textContent="Não foi possível carregar o Pertinho";p.textContent="Verifique a conexão e tente de novo.";k.type="button";k.textContent="Tentar de novo";
k.onclick=()=>{const r=()=>location.reload();try{(window.caches?caches.keys().then(x=>Promise.all(x.map(y=>caches.delete(y)))):Promise.resolve()).then(r,r)}catch(e){r()}};
d.append(b,p,k);document.body.appendChild(d)};
window.addEventListener("error",e=>{if(e.target&&e.target.tagName==="SCRIPT")show()},true);
window.addEventListener("load",()=>setTimeout(show,300))})();
