/* Pertinho — camada de APIs. Todas gratuitas, sem chave, só HTTPS, com timeout e validação do que chega. */
const CFG={GOOGLE_CLIENT_ID:""}; // ID público do Google (console.cloud.google.com). Vazio = login de demonstração.
let WX="",GEO=null,OFF=0;const RIO={lat:-22.9068,lng:-43.1729},VURL={};
const J=async(u,o={})=>{const c=new AbortController(),t=setTimeout(()=>c.abort(),9000);try{const r=await fetch(u,{...o,signal:c.signal});if(!r.ok)throw 0;return await r.json()}finally{clearTimeout(t)}};
const UFS_N={AC:"Acre",AL:"Alagoas",AP:"Amapá",AM:"Amazonas",BA:"Bahia",CE:"Ceará",DF:"Distrito Federal",ES:"Espírito Santo",GO:"Goiás",MA:"Maranhão",MT:"Mato Grosso",MS:"Mato Grosso do Sul",MG:"Minas Gerais",PA:"Pará",PB:"Paraíba",PR:"Paraná",PE:"Pernambuco",PI:"Piauí",RJ:"Rio de Janeiro",RN:"Rio Grande do Norte",RS:"Rio Grande do Sul",RO:"Rondônia",RR:"Roraima",SC:"Santa Catarina",SP:"São Paulo",SE:"Sergipe",TO:"Tocantins"};
const TERMOS={pizza:"tarantella italiana",japonesa:"japanese city pop",brasileira:"samba",hamburguer:"rock classico",cafe:"bossa nova",doces:"pop brasil",outros:"mpb",roupas:"pop dance",mercado:"sertanejo",farmacia:"mpb",petshop:"pop",odontologia:"jazz suave",clinica:"lofi",academia:"treino eletronica",salao:"pop brasil",barbearia:"rock",oficina:"rock classico",lavanderia:"mpb",assistenciatecnica:"eletronica"},MC={};
const API={
// músicas reais: iTunes Search (prévias de 30 s) → Audius (faixas completas) → mp3 local
async musica(c,id){const k=slug(c),q=encodeURIComponent(TERMOS[k]||"mpb");if(!MC[k])MC[k]=(async()=>{
try{const d=await J("https://itunes.apple.com/search?media=music&entity=song&country=BR&limit=30&term="+q);const l=d.results.filter(x=>/^https:\/\//.test(x.previewUrl||"")).map(x=>({t:x.trackName,a:x.artistName,u:x.previewUrl,img:(x.artworkUrl100||"").replace("100x100","200x200")}));if(l.length)return l}catch(e){}
try{const d=await J("https://api.audius.co/v1/tracks/search?app_name=pertinho&limit=20&query="+q);return d.data.map(x=>({t:x.title,a:x.user.name,u:"https://api.audius.co/v1/tracks/"+encodeURIComponent(x.id)+"/stream?app_name=pertinho",img:x.artwork&&x.artwork["150x150"]}))}catch(e){}return[]})();
const l=await MC[k];return l.length?l[(hash(id)+OFF)%l.length]:null},
// comércios reais ao redor (OpenStreetMap / Overpass)
async perto(){const p=await new Promise(r=>navigator.geolocation?navigator.geolocation.getCurrentPosition(x=>r({lat:x.coords.latitude,lng:x.coords.longitude}),()=>r(null),{timeout:7000,maximumAge:6e5}):r(null));if(p)API.home=p;if(!S.place){if(p){const m=Math.abs(POS.lat-p.lat)+Math.abs(POS.lng-p.lng)>5e-4;POS.lat=p.lat;POS.lng=p.lng;if(m)MP.init=0}else if(!API.sem){API.sem=1;toast("Sem acesso à localização: mostrando o centro do Rio de Janeiro")}}return API.osm()},
rec(){for(const n of N)if(/^d\d/.test(n.id)){if(n.l0==null){n.l0=n.lat;n.g0=n.lng}n.lat=n.l0+POS.lat-RIO.lat;n.lng=n.g0+POS.lng-RIO.lng}},
async osm(){API.rec();try{const ck=POS.lat.toFixed(2)+","+POS.lng.toFixed(2);let nv=null;try{const c=JSON.parse(localStorage.getItem("pertinho-osm")||"null");if(c&&c.k===ck&&Array.isArray(c.d)&&Date.now()-c.t<(c.d.length?108e5:3e5))nv=c.d.map(limpaN).filter(Boolean)}catch(e){}
if(!nv){const R=`(around:3000,${POS.lat},${POS.lng})`,q=`[out:json][timeout:25];(nwr["name"]["amenity"~"^(restaurant|cafe|fast_food|ice_cream|dentist|clinic|doctors|pharmacy|veterinary)$"]${R};nwr["name"]["shop"~"^(clothes|shoes|boutique|fashion|supermarket|convenience|greengrocer|bakery|confectionery|pet|hairdresser|beauty|barber|car_repair|laundry|dry_cleaning|mobile_phone|computer|electronics)$"]${R};nwr["name"]["leisure"~"^(fitness_centre|sports_centre)$"]${R};);out center 150;`;
const d=await J("https://overpass-api.de/api/interpreter",{method:"POST",body:"data="+encodeURIComponent(q),headers:{"Content-Type":"application/x-www-form-urlencoded"}});
if(!Array.isArray(d.elements)||/error/i.test(String(d.remark||"")))throw 0;
nv=d.elements.map(e=>{const t=e.tags||{},la=e.lat??e.center?.lat,lo=e.lon??e.center?.lon;if(typeof la!=="number"||typeof lo!=="number")return null;const z=String(t.cuisine||"").toLowerCase(),nm=String(t.name),a=t.amenity,s=t.shop;
const c=a==="dentist"?"Odontologia":(a==="clinic"||a==="doctors")?"Clínica":a==="pharmacy"?"Farmácia":a==="veterinary"?"Pet shop":t.leisure?"Academia":s?(/clothes|shoes|boutique|fashion/.test(s)?"Roupas":/supermarket|convenience|greengrocer/.test(s)?"Mercado":/bakery|confectionery/.test(s)?"Doces":s==="pet"?"Pet shop":(s==="barber"||/barbear|barber/i.test(nm))?"Barbearia":/hairdresser|beauty/.test(s)?"Salão":s==="car_repair"?"Oficina":/laundry|dry_cleaning/.test(s)?"Lavanderia":"Assistência técnica"):a==="cafe"?"Café":a==="ice_cream"?"Doces":/pizza/.test(z)?"Pizza":/japan|sushi/.test(z)?"Japonesa":/brazil/.test(z)?"Brasileira":/burger/.test(z)?"Hambúrguer":"Outros";
return mk("osm"+e.id,nm.slice(0,60),c,"$$",(z?z.replace(/[_;]/g," "):c).slice(0,80),[t["addr:street"],t["addr:housenumber"]].filter(Boolean).join(", ")||"Endereço no mapa",String(t.opening_hours||"").slice(0,60),la,lo,[],[])}).filter(Boolean);
try{localStorage.setItem("pertinho-osm",JSON.stringify({k:ck,t:Date.now(),d:nv}))}catch(e){}}
N=N.filter(n=>!/^osm/.test(n.id)).concat(nv);return nv.length}catch(e){return 0}},
// busca de lugares (Nominatim), clima (Open-Meteo), CEP (ViaCEP)
async lugares(q){try{return(await J("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=br&q="+encodeURIComponent(q))).map(x=>({n:String(x.display_name),lat:+x.lat,lng:+x.lon}))}catch(e){return[]}},
async cidades(q,uf){try{const nm=uf?", "+UFS_N[uf]:"",d=await J("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&addressdetails=1&countrycodes=br&accept-language=pt-BR&q="+encodeURIComponent(q+nm));const seen=new Set();
return d.filter(x=>{const a=x.address||{},c=String(a["ISO3166-2-lvl4"]||"").slice(3);return(!uf||c===uf)&&Number.isFinite(+x.lat)&&Number.isFinite(+x.lon)}).map(x=>{const a=x.address||{},c=String(a["ISO3166-2-lvl4"]||"").slice(3),nome=a.city||a.town||a.village||a.municipality||a.suburb||a.state||String(x.display_name).split(",")[0];return{n:nome+(c?", "+c:""),lat:+x.lat,lng:+x.lon}}).filter(x=>!seen.has(x.n)&&seen.add(x.n)).slice(0,6)}catch(e){return[]}},
async clima(){try{const c=(await J(`https://api.open-meteo.com/v1/forecast?latitude=${POS.lat}&longitude=${POS.lng}&current=temperature_2m,weather_code`)).current,w=c.weather_code;return Math.round(c.temperature_2m)+"° "+(w>=95?"⛈️":w>=61?"🌧️":w>=45?"🌫️":w>=3?"☁️":w>0?"⛅":"☀️")}catch(e){return""}},
async cep(v){v=String(v).replace(/\D/g,"");if(v.length!==8)return null;try{const d=await J("https://viacep.com.br/ws/"+v+"/json/");if(d.erro)return null;GEO=(await API.lugares(`${d.logradouro}, ${d.localidade}, ${d.uf}`))[0]||null;return`${d.logradouro}, ${d.bairro}, ${d.localidade}-${d.uf}`}catch(e){return null}},
google(cb){const demo=()=>cb({nome:"Visitante Google",email:"visitante@gmail.com"});if(!CFG.GOOGLE_CLIENT_ID)return demo();const s=document.createElement("script");s.src="https://accounts.google.com/gsi/client";
s.onload=()=>{google.accounts.id.initialize({client_id:CFG.GOOGLE_CLIENT_ID,callback:r=>{try{const p=JSON.parse(atob(r.credential.split(".")[1].replace(/-/g,"+").replace(/_/g,"/")));cb({nome:String(p.name),email:String(p.email)})}catch(e){demo()}}});google.accounts.id.prompt()};s.onerror=demo;document.head.appendChild(s)},
async recarregar(){OFF=Math.floor(Math.random()*50);for(const k in MC)delete MC[k];await API.perto();API.clima().then(t=>{WX=t;chips()})}
};
// puxar para atualizar (toque no celular, roda do mouse no PC)
function ptr(f,fn){let y0=null,d=0,busy=false;const el=$("ptr"),set=(v,t)=>{el.style.opacity=Math.min(v/60,1);el.style.transform=`translateY(${v-30}px)`;el.style.transition=t?".25s":"none"};
const run=async()=>{if(busy)return;busy=true;el.classList.add("spin");set(70,1);try{await fn()}catch(e){}el.classList.remove("spin");set(0,1);busy=false};
f.addEventListener("touchstart",e=>{y0=f.scrollTop<=0?e.touches[0].clientY:null;d=0},{passive:true});
f.addEventListener("touchmove",e=>{if(y0==null||busy)return;d=e.touches[0].clientY-y0;if(d>0){e.preventDefault();set(Math.min(d*.5,90))}else{y0=null;set(0)}},{passive:false});
f.addEventListener("touchend",()=>{if(y0!=null&&d*.5>60)run();else set(0,1);y0=null;d=0});
let w=0;f.addEventListener("wheel",e=>{if(f.scrollTop<=0&&e.deltaY<0){w-=e.deltaY;if(w>240){w=0;run()}}else w=0},{passive:true})}
// handlers de imagem sem atributos inline (permite CSP sem 'unsafe-inline' em scripts)
document.addEventListener("error",e=>{if(e.target.tagName==="IMG")fb(e.target)},true);
document.addEventListener("load",e=>{if(e.target.tagName==="IMG")e.target.classList.add("ok")},true);
// vídeos postados pelo usuário ficam no IndexedDB (sobrevivem ao recarregar)
const DB={c:null,o(){return DB.c||(DB.c=new Promise((r,j)=>{const q=indexedDB.open("pertinho",1);q.onupgradeneeded=()=>q.result.createObjectStore("v");q.onsuccess=()=>{const d=q.result;d.onversionchange=()=>{d.close();DB.c=null};r(d)};q.onerror=()=>{DB.c=null;j(q.error)}}))},
async del(k){const d=await DB.o();return new Promise((r,j)=>{const t=d.transaction("v","readwrite");t.objectStore("v").delete(k);t.oncomplete=()=>r(1);t.onerror=()=>j(t.error)})},
async wipe(){try{if(DB.c){(await DB.c).close();DB.c=null}}catch(e){}return new Promise(r=>{try{const q=indexedDB.deleteDatabase("pertinho");q.onsuccess=q.onerror=q.onblocked=()=>r(1)}catch(e){r(1)}})},
async put(k,b){const d=await DB.o();return new Promise((r,j)=>{const t=d.transaction("v","readwrite");t.objectStore("v").put(b,k);t.oncomplete=()=>r(1);t.onerror=()=>j()})},
async get(k){const d=await DB.o();return new Promise(r=>{const q=d.transaction("v").objectStore("v").get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>r(null)})}};
async function vids(){for(const n of N)if(n.vid&&!VURL[n.id])try{const b=await DB.get(n.id);if(b)VURL[n.id]=URL.createObjectURL(b)}catch(e){}}
