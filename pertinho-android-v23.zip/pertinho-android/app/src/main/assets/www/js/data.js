/* Dados de demonstração: categorias, comércios e posição. Troque por uma API depois. */
const GRP=[["Comer e beber","🍽️"],["Compras","🛍️"],["Saúde","🩺"],["Fitness e beleza","💪"],["Serviços","🔧"],["Outros","📍"]];
/* [nome, emoji, cor A, cor B, índice do grupo em GRP] */
const CATS=[["Pizza","🍕","#E63B2E","#7A1C12",0],["Japonesa","🍣","#2B6CB0","#12294A",0],["Brasileira","🍛","#BF7A00","#6B3A00",0],["Hambúrguer","🍔","#8E44AD","#3B1550",0],["Café","☕","#7B5B3A","#2E2012",0],["Doces","🧁","#D81B7A","#5C0B3A",0],
["Roupas","👗","#C2185B","#4A0E2B",1],["Mercado","🛒","#2E7D32","#0F3314",1],["Farmácia","💊","#00897B","#05302B",1],["Pet shop","🐾","#E65100","#5C2400",1],
["Odontologia","🦷","#0277BD","#073B57",2],["Clínica","🩺","#5E35B1","#21104A",2],
["Academia","🏋️","#C62828","#4A0F0F",3],["Salão","💇","#9C27B0","#3E1450",3],["Barbearia","💈","#455A64","#141C20",3],
["Oficina","🔧","#546E7A","#1A2327",4],["Lavanderia","🧺","#00897B","#0B3B36",4],["Assistência técnica","📱","#3949AB","#121A4D",4],
["Outros","🛍️","#3B7A6B","#10302A",5]];
const cat=n=>CATS.find(c=>c[0]===n)||CATS[CATS.length-1],grp=n=>GRP[cat(n)[4]][0];let POS={lat:-22.9068,lng:-43.1729};
const mk=(id,nome,categoria,faixa,descricao,endereco,horario,lat,lng,cardapio,fotos)=>({id,nome,categoria,faixa,descricao,endereco,horario,lat,lng,cardapio,fotos});
let N=[
mk("d1","Pizzaria Forno Bravo","Pizza","$$","Massa de fermentação natural, assada em forno a lenha.","Rua do Ouvidor, 120 – Centro, Rio de Janeiro","Ter–Dom, 18h às 23h30",-22.9035,-43.1745,[["Margherita",49.9],["Calabresa com cebola",54],["Quatro queijos",62.5]],["🍕","🧀"]),
mk("d2","Sushi da Praça","Japonesa","$$$","Combinados frescos e temaki feito na hora.","Av. Rio Branco, 45 – Centro, Rio de Janeiro","Seg–Sáb, 11h às 22h",-22.9010,-43.1790,[["Combinado 20 peças",89.9],["Temaki salmão",32],["Hot roll (8 un.)",38.5]],["🍣","🥢"]),
mk("d3","Bar do Zé","Brasileira","$","Prato feito do dia e feijoada aos sábados.","Rua da Quitanda, 78 – Centro, Rio de Janeiro","Seg–Sex, 11h às 16h",-22.9050,-43.1760,[["PF do dia",24.9],["Feijoada completa",39.9],["Pastel de carne",9]],["🍛"]),
mk("d4","Burger Lapa","Hambúrguer","$$","Smash burgers com pão brioche e molho da casa.","Rua Joaquim Silva, 30 – Lapa, Rio de Janeiro","Todos os dias, 12h às 00h",-22.9133,-43.1810,[["Smash simples",28],["Smash duplo bacon",38],["Batata rústica",18]],["🍔","🍟"]),
mk("d5","Café Colombo","Café","$$","Café especial, pão de queijo quentinho e bolos caseiros.","Rua Gonçalves Dias, 32 – Centro, Rio de Janeiro","Seg–Sáb, 8h às 19h",-22.9040,-43.1780,[["Espresso",7],["Cappuccino",13.5],["Pão de queijo (4 un.)",12]],["☕"]),
mk("d6","Doce Tentação","Doces","$","Brigadeiros gourmet, bolos no pote e tortas.","Rua Sete de Setembro, 99 – Centro, Rio de Janeiro","Seg–Sáb, 9h às 18h",-22.9075,-43.1740,[["Brigadeiro gourmet",5],["Bolo no pote",14],["Fatia de torta de limão",16]],["🧁","🍰"]),
mk("d7","Pizza Longe Demais","Pizza","$$","Fica a ~14 km: só aparece com o raio de 25 km.","Barra da Tijuca, Rio de Janeiro","Todos os dias, 18h às 23h",-23.0004,-43.3659,[["Mussarela",45]],[]),
mk("d8","Moda Carioca","Roupas","$$","Looks de verão, jeans e acessórios. Troca em até 7 dias.","Rua Uruguaiana, 60 – Centro, Rio de Janeiro","Seg–Sáb, 9h às 19h",-22.9038,-43.1788,[["Vestido midi floral",129.9],["Camiseta básica",49.9],["Calça jeans",159.9]],["👗","👟"]),
mk("d9","Mercadinho Bom Preço","Mercado","$","Hortifruti fresquinho, açougue e padaria no mesmo lugar.","Rua da Assembleia, 40 – Centro, Rio de Janeiro","Todos os dias, 7h às 21h",-22.9060,-43.1765,[["Cesta de frutas da semana",29.9],["Pão francês (kg)",16.9],["Café 500 g",21.9]],["🛒","🥬"]),
mk("d10","Farma Centro","Farmácia","$$","Medicamentos, perfumaria e entrega rápida no bairro.","Rua do Rosário, 15 – Centro, Rio de Janeiro","Todos os dias, 8h às 22h",-22.9028,-43.1752,[["Protetor solar FPS 50",39.9],["Kit higiene bucal",24.9],["Vitamina C (30 cáps.)",19.9]],["💊"]),
mk("d11","Pet Amigo","Pet shop","$$","Banho e tosa, rações e acessórios para seu melhor amigo.","Rua Buenos Aires, 80 – Centro, Rio de Janeiro","Seg–Sáb, 9h às 18h",-22.9055,-43.1795,[["Banho (porte pequeno)",55],["Tosa higiênica",40],["Ração premium 1 kg",32.9]],["🐾","🐶"]),
mk("d12","Sorriso Odontologia","Odontologia","","Avaliação, limpeza e tratamentos com horário marcado.","Av. Rio Branco, 156 – Centro, Rio de Janeiro","Seg–Sex, 8h às 18h",-22.9020,-43.1770,[["Avaliação inicial",null],["Limpeza e profilaxia",null],["Clareamento",null]],["🦷"]),
mk("d13","Clínica Vida","Clínica","","Clínica geral e check-up com atendimento por agendamento.","Rua da Assembleia, 100 – Centro, Rio de Janeiro","Seg–Sex, 7h às 19h",-22.9048,-43.1735,[["Consulta clínica geral",null],["Check-up completo",null],["Acompanhamento nutricional",null]],["🩺"]),
mk("d14","Academia Força Total","Academia","$$","Musculação, funcional e aulas coletivas para todos os níveis.","Rua do Carmo, 22 – Centro, Rio de Janeiro","Seg–Sex, 6h às 22h",-22.9072,-43.1752,[["Plano mensal",99.9],["Aula experimental",0],["Personal (sessão)",90]],["🏋️","💪"]),
mk("d15","Studio Bela","Salão","$$","Corte, escova, coloração e unhas com hora marcada.","Rua Sete de Setembro, 150 – Centro, Rio de Janeiro","Ter–Sáb, 9h às 19h",-22.9082,-43.1745,[["Corte feminino",80],["Escova modelada",60],["Manicure e pedicure",70]],["💇","💅"]),
mk("d16","Barbearia do Zeca","Barbearia","$","Corte na régua, barba na toalha quente e cerveja gelada.","Rua Miguel Couto, 18 – Centro, Rio de Janeiro","Seg–Sáb, 10h às 20h",-22.9058,-43.1722,[["Corte",45],["Barba",35],["Corte + barba",70]],["💈"]),
mk("d17","Auto Center Rio","Oficina","$$","Revisão, freios, suspensão e troca de óleo com garantia.","Rua Acre, 70 – Centro, Rio de Janeiro","Seg–Sex, 8h às 18h",-22.8998,-43.1790,[["Troca de óleo",120],["Alinhamento e balanceamento",140],["Revisão completa",350]],["🔧","🚗"]),
mk("d18","Lavanderia Expressa","Lavanderia","$","Lavagem e passadoria em 24h, com retirada e entrega.","Rua do Ouvidor, 200 – Centro, Rio de Janeiro","Seg–Sáb, 8h às 18h",-22.9042,-43.1710,[["Lavagem (kg)",18],["Edredom casal",65],["Terno completo",55]],["🧺"]),
mk("d19","Tech Fix Celulares","Assistência técnica","$$","Troca de tela e bateria na hora, com garantia de 90 dias.","Rua da Carioca, 45 – Centro, Rio de Janeiro","Seg–Sáb, 9h às 19h",-22.9065,-43.1782,[["Troca de tela",220],["Troca de bateria",120],["Película + capinha",45]],["📱","🔋"])];

/* Mídia remota (Mixkit, licença gratuita): o app toca direto dos links, sem baixar nada.
   v = 2 vídeos, i = 2 fotos (quadros dos vídeos), m = música (opcional).
   Se um link falhar, cai sozinho para o arquivo local em assets/media. */
const MX="https://assets.mixkit.co/videos/";
const mv=id=>MX+id+"/"+id+"-360.mp4",mi=(id,n=0)=>MX+id+"/"+id+"-thumb-360-"+n+".jpg";
const MEDIA={
pizza:{v:[mv(44001),mv(42475)],i:[mi(44001),mi(42475)],m:null},
japonesa:{v:[mv(32522),mv(15281)],i:[mi(32522),mi(15281)],m:null},
brasileira:{v:[mv(14343),mv(14345)],i:[mi(14343),mi(14345)],m:null},
hamburguer:{v:[mv(3538),mv(14010)],i:[mi(3538),mi(14010)],m:null},
cafe:{v:[mv(41859),mv(810)],i:[mi(41859),mi(810,4)],m:null},
doces:{v:[mv(41110),mv(49431)],i:[mi(41110),mi(49431,4)],m:null},
outros:{v:[mv(4385),mv(22746)],i:[mi(4385),mi(22746)],m:null}};

