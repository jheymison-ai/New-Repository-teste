/* Pertinho — ponte mínima para o APK Android. Carregada só no app Android (adicionada por scripts/prepare_web.py).
   NÃO usa addJavascriptInterface: nada do JavaScript consegue chamar código nativo, só navegar para URLs
   que o MainActivity valida (UrlPolicy). Mantém o app original intacto. */
(function(){
"use strict";
/* Botão Voltar do Android: devolve true se o app tratou (fechou painel/prévia/busca ou voltou), false para sair. */
window.__pertinhoBack=function(){
  try{
    var sh=document.getElementById("sh");
    if(sh&&sh.classList.contains("on")){sh.classList.remove("on");return true}
    if(typeof pvClose==="function"&&document.getElementById("pv")){pvClose();return true}
    var bus=document.getElementById("vBus");
    if(bus&&bus.classList.contains("on")){var b=document.getElementById("bsB");if(b){b.click();return true}}
    var on=document.querySelector(".v.on");
    if(!on||on.id==="vFeed")return false;
    if(on.id==="vNeg"){var bk=on.querySelector(".back[data-go]");if(bk){bk.click();return true}}
    if(typeof go==="function"){go("vFeed");return true}
    return false;
  }catch(e){return false}
};
/* Web Share não existe no WebView: sem isso o app copiaria o endereço interno do APK. */
var share=function(d){
  var t=[d&&d.title,d&&d.text].filter(Boolean).join(" — ").slice(0,500);
  if(t)location.href="pertinho-share://s?text="+encodeURIComponent(t);
  return Promise.resolve();
};
try{Object.defineProperty(navigator,"share",{value:share,configurable:true})}catch(e){try{navigator.share=share}catch(e2){}}
})();
