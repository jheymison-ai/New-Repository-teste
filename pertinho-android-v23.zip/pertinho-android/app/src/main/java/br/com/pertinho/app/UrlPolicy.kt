package br.com.pertinho.app

import java.net.URI

/** Regras puras (testáveis na JVM) de navegação e de acesso aos arquivos empacotados. */
object UrlPolicy {
    const val HOST = "appassets.androidplatform.net"
    const val BASE_PATH = "/assets/www/"
    const val START_URL = "https://$HOST${BASE_PATH}index.html"
    const val SHARE_SCHEME = "pertinho-share"

    enum class Action { LOAD_IN_APP, OPEN_EXTERNAL, SHARE, BLOCK }

    fun classify(raw: String): Action {
        val u = try { URI(raw) } catch (e: Exception) { return Action.BLOCK }
        return when (u.scheme?.lowercase()) {
            "https" -> if (u.host.equals(HOST, ignoreCase = true)) Action.LOAD_IN_APP else Action.OPEN_EXTERNAL
            "mailto", "tel", "geo" -> Action.OPEN_EXTERNAL
            SHARE_SCHEME -> Action.SHARE
            else -> Action.BLOCK   // http, file, content, intent, javascript, etc.
        }
    }

    /** Converte o caminho da URL em caminho dentro de assets/, ou null se for inseguro/fora de www. */
    fun assetPath(urlPath: String?): String? {
        if (urlPath == null || !urlPath.startsWith(BASE_PATH)) return null
        if (urlPath.contains("..") || urlPath.contains('\\') || urlPath.contains('\u0000') || urlPath.contains("//")) return null
        return urlPath.removePrefix("/assets/")
    }

    /** Interpreta "Range: bytes=a-b" (também "a-" e "-n"). Retorna [início, fim] inclusivo ou null se inválido. */
    fun parseRange(header: String?, length: Long): Pair<Long, Long>? {
        if (header == null || length <= 0 || !header.startsWith("bytes=") || header.contains(',')) return null
        val parts = header.removePrefix("bytes=").trim().split("-", limit = 2)
        if (parts.size != 2) return null
        val a = parts[0].toLongOrNull()
        val b = parts[1].toLongOrNull()
        val start: Long
        val end: Long
        when {
            a != null && b != null -> { start = a; end = minOf(b, length - 1) }
            a != null -> { start = a; end = length - 1 }
            b != null && b > 0 -> { start = maxOf(0, length - b); end = length - 1 }
            else -> return null
        }
        return if (start in 0..end) start to end else null
    }

    fun mimeForMedia(path: String): String? = when {
        path.endsWith(".mp4", true) -> "video/mp4"
        path.endsWith(".mp3", true) -> "audio/mpeg"
        else -> null
    }
}
