package br.com.pertinho.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import java.io.FilterInputStream
import java.io.InputStream

/**
 * Única Activity. Hospeda o WebView que carrega os arquivos originais do Pertinho v23 empacotados
 * em assets/www (servidos por https://appassets.androidplatform.net/assets/www/ via WebViewAssetLoader,
 * sem site remoto, sem file:// e sem ponte JavaScript nativa).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(
                if (r.resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data) else null
            )
        }

    private val locationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val granted = res.values.any { it }
            geoCallback?.invoke(geoOrigin, granted, false)
            geoCallback = null
            geoOrigin = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tela inteira com áreas seguras tratadas aqui (barra de status, recorte, navegação e teclado).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = WebView.OVER_SCROLL_NEVER
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(UrlPolicy.HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        configureWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Primeiro o app: fecha painel/prévia/busca ou volta ao Início; só então sai.
                web.evaluateJavascript("(window.__pertinhoBack?window.__pertinhoBack():false)") { r ->
                    if (r != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState != null && web.restoreState(savedInstanceState) != null) {
            // estado do WebView restaurado
        } else {
            web.loadUrl(UrlPolicy.START_URL)
        }
    }

    /** Usado pelos testes instrumentados. */
    fun webView(): WebView = web

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage + IndexedDB (dados do app)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            setGeolocationEnabled(true)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            // O CSS original já trata claro/escuro; não deixar o Android escurecer por conta própria.
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, false)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                rangeResponse(request) ?: assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handleNavigation(request.url)

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // O processo do WebView caiu: recria a tela em vez de encerrar o app. Os dados locais permanecem.
                Log.w(TAG, "WebView render process gone (crash=${detail.didCrash()})")
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
                recreate()
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val chooser = Intent.createChooser(params.createIntent(), "Escolher ou gravar vídeo")
                val wantsVideo = params.acceptTypes.any { it.startsWith("video") }
                if (wantsVideo) {
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(Intent(MediaStore.ACTION_VIDEO_CAPTURE)))
                }
                return try {
                    fileLauncher.launch(chooser)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    true
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (origin != "https://${UrlPolicy.HOST}") { callback.invoke(origin, false, false); return }
                if (hasLocationPermission()) { callback.invoke(origin, true, false); return }
                geoCallback?.invoke(geoOrigin, false, false)
                geoCallback = callback
                geoOrigin = origin
                locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }

            override fun onGeolocationPermissionsHidePrompt() { geoCallback = null; geoOrigin = null }

            // Câmera/microfone via getUserMedia não são usados pelo app: negar por padrão.
            override fun onPermissionRequest(request: PermissionRequest) { request.deny() }

            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                Log.d(TAG, "${m.messageLevel()} ${m.sourceId()}:${m.lineNumber()} ${m.message()}")
                return true
            }
        }
    }

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** true = a navegação foi tratada aqui (não carregar no WebView). */
    private fun handleNavigation(uri: Uri): Boolean = when (UrlPolicy.classify(uri.toString())) {
        UrlPolicy.Action.LOAD_IN_APP -> false
        UrlPolicy.Action.OPEN_EXTERNAL -> { openExternal(uri); true }
        UrlPolicy.Action.SHARE -> { share(uri.getQueryParameter("text")); true }
        UrlPolicy.Action.BLOCK -> true
    }

    private fun openExternal(uri: Uri) {
        val action = if (uri.scheme == "mailto") Intent.ACTION_SENDTO else Intent.ACTION_VIEW
        try { startActivity(Intent(action, uri)) } catch (e: ActivityNotFoundException) { Log.w(TAG, "Sem app para $uri") }
    }

    private fun share(text: String?) {
        val t = text?.take(500).orEmpty()
        if (t.isBlank()) return
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
        try { startActivity(Intent.createChooser(send, "Compartilhar")) } catch (e: ActivityNotFoundException) { }
    }

    /** Atende pedidos Range de vídeo/áudio direto do APK (o AssetsPathHandler padrão não faz 206). */
    private fun rangeResponse(req: WebResourceRequest): WebResourceResponse? {
        val header = req.requestHeaders["Range"] ?: req.requestHeaders["range"] ?: return null
        if (req.method != "GET" || !req.url.host.equals(UrlPolicy.HOST, true)) return null
        val path = UrlPolicy.assetPath(req.url.path) ?: return null
        val mime = UrlPolicy.mimeForMedia(path) ?: return null
        var stream: InputStream? = null
        return try {
            val afd = assets.openFd(path)        // falha (e cai no 200 completo) se o arquivo estiver comprimido
            val len = afd.length
            val range = UrlPolicy.parseRange(header, len)
            if (range == null) { afd.close(); return null }
            val (start, end) = range
            stream = afd.createInputStream()
            var skipped = 0L
            while (skipped < start) {
                val n = stream.skip(start - skipped)
                if (n <= 0) throw java.io.IOException("skip")
                skipped += n
            }
            val size = end - start + 1
            WebResourceResponse(
                mime, null, 206, "Partial Content",
                mapOf(
                    "Content-Range" to "bytes $start-$end/$len",
                    "Accept-Ranges" to "bytes",
                    "Content-Length" to size.toString(),
                ),
                LimitedInputStream(stream, size)
            )
        } catch (e: Exception) {
            try { stream?.close() } catch (_: Exception) { }
            null
        }
    }

    override fun onResume() { super.onResume(); web.onResume() }

    override fun onPause() {
        // Pausa vídeo/áudio ao sair do app (ciclo de vida de mídia).
        web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})", null)
        web.onPause()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null); fileCallback = null
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private class LimitedInputStream(i: InputStream, private var left: Long) : FilterInputStream(i) {
        override fun read(): Int = if (left <= 0) -1 else super.read().also { if (it >= 0) left-- }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
    }

    companion object { private const val TAG = "Pertinho" }
}
